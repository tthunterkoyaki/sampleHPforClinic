﻿"""
time_series.py - 時系列分析モジュール

月次ポートフォリオデータの時系列分析を行う。
トレンド検出、異常値検知、移動平均、前月/前年比較を提供。

すべての分析結果にはevidence（根拠）を含め、
なぜそのような結論に至ったかを説明する（xAI対応）。
"""
import pandas as pd
import numpy as np
from typing import Dict, List, Any, Optional, Tuple


class TimeSeriesAnalyzer:
    """時系列分析エンジン"""

    def compute_period_totals(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        月次の全体集計値を計算する。

        計算ロジック:
          各月のポートフォリオ全体を集計:
          - 総簿価 = Σ(資産クラス別簿価)
          - 総時価 = Σ(資産クラス別時価)
          - 総インカム = Σ(資産クラス別インカム)
          - 総キャピタル = Σ(資産クラス別キャピタル)
          - トータルリターン = インカム + キャピタル
          - リターン率 = トータルリターン / 簿価
        """
        totals = df.groupby('date').agg({
            'book_value': 'sum',
            'market_value': 'sum',
            'income': 'sum',
            'capital': 'sum',
            'unrealized_gl': 'sum',
        }).reset_index().sort_values('date')

        totals['total_return'] = totals['income'] + totals['capital']
        totals['return_rate'] = np.where(
            totals['book_value'] != 0,
            totals['total_return'] / totals['book_value'], 0)
        totals['gl_ratio'] = np.where(
            totals['book_value'] != 0,
            totals['unrealized_gl'] / totals['book_value'], 0)
        return totals

    def compute_monthly_changes(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        前月比の変化を計算する。

        計算ロジック:
          変化額 = 当月値 - 前月値
          変化率(%) = (当月値 - 前月値) / 前月値 × 100

        注意: 最初の月は比較対象がないためNaN
        """
        totals = self.compute_period_totals(df)
        for col in ['market_value', 'book_value', 'unrealized_gl', 'income', 'total_return']:
            if col in totals.columns:
                totals[f'{col}_change'] = totals[col].diff()
                totals[f'{col}_change_pct'] = totals[col].pct_change() * 100
        return totals

    def compute_yoy_changes(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        前年同月比を計算する。

        計算ロジック:
          YoY変化額 = 当月値 - 前年同月値
          YoY変化率(%) = (当月値 - 前年同月値) / 前年同月値 × 100

        注意: 12ヶ月未満のデータではNaN
        """
        totals = self.compute_period_totals(df)
        if len(totals) < 13:
            return totals

        for col in ['market_value', 'book_value', 'unrealized_gl']:
            if col in totals.columns:
                totals[f'{col}_yoy'] = totals[col].diff(12)
                shifted = totals[col].shift(12)
                totals[f'{col}_yoy_pct'] = np.where(
                    shifted != 0, (totals[col] - shifted) / shifted * 100, 0)
        return totals

    def compute_moving_averages(self, series: pd.Series,
                                 windows: List[int] = [3, 6, 12]) -> Dict[int, pd.Series]:
        """
        移動平均を計算する。

        計算ロジック:
          MA(n) = 直近n期間の単純平均
          3ヶ月MA: 短期トレンド把握
          6ヶ月MA: 中期トレンド把握
          12ヶ月MA: 長期トレンド・季節調整
        """
        result = {}
        for w in windows:
            if len(series) >= w:
                result[w] = series.rolling(window=w).mean()
        return result

    def detect_trends(self, df: pd.DataFrame) -> List[Dict[str, Any]]:
        """
        主要指標のトレンドを検出する。

        検出ロジック:
          1. 各指標の時系列に対し線形回帰（最小二乗法）を適用
          2. 回帰係数（傾き）の符号と大きさからトレンド方向・強度を判定
          3. 傾きの統計的有意性（決定係数R^2）も考慮

          判定基準:
            - R^2 > 0.3 かつ 傾き正 → 上昇トレンド
            - R^2 > 0.3 かつ 傾き負 → 下降トレンド
            - R^2 <= 0.3 → 明確なトレンドなし

        Returns:
            トレンド情報のリスト。各要素は:
              metric: 指標名
              direction: 'up' / 'down' / 'flat'
              strength: 傾きの絶対値（正規化済み）
              r_squared: 決定係数
              description: 日本語説明
              evidence: 根拠データ（xAI用）
        """
        totals = self.compute_period_totals(df)
        if len(totals) < 4:
            return []

        trends = []
        metrics = {
            'market_value': '総時価',
            'unrealized_gl': '評価損益',
            'income': 'インカム収益',
            'total_return': 'トータルリターン',
            'gl_ratio': '評価損益率',
        }

        for col, label in metrics.items():
            if col not in totals.columns:
                continue
            series = totals[col].dropna()
            if len(series) < 4:
                continue

            x = np.arange(len(series))
            y = series.values.astype(float)

            # 線形回帰
            if np.std(y) == 0:
                continue
            coeffs = np.polyfit(x, y, 1)
            slope = coeffs[0]
            y_pred = np.polyval(coeffs, x)
            ss_res = np.sum((y - y_pred) ** 2)
            ss_tot = np.sum((y - np.mean(y)) ** 2)
            r_squared = 1 - ss_res / ss_tot if ss_tot != 0 else 0

            # 傾きを正規化（平均値に対する相対変化）
            mean_val = np.mean(np.abs(y)) if np.mean(np.abs(y)) != 0 else 1
            norm_slope = slope / mean_val

            if r_squared > 0.3:
                if slope > 0:
                    direction = 'up'
                    desc = f'{label}は上昇トレンドにあります（月あたり約{abs(slope):,.0f}の増加、決定係数R²={r_squared:.2f}）'
                else:
                    direction = 'down'
                    desc = f'{label}は下降トレンドにあります（月あたり約{abs(slope):,.0f}の減少、決定係数R²={r_squared:.2f}）'
            else:
                direction = 'flat'
                desc = f'{label}には明確なトレンドが見られません（R²={r_squared:.2f}）'

            trends.append({
                'metric': col,
                'label': label,
                'direction': direction,
                'strength': abs(norm_slope),
                'slope': slope,
                'r_squared': r_squared,
                'description': desc,
                'evidence': {
                    'method': '最小二乗法による線形回帰',
                    'data_points': len(series),
                    'start_value': float(y[0]),
                    'end_value': float(y[-1]),
                    'slope_per_month': float(slope),
                    'r_squared': float(r_squared),
                }
            })

        # 強いトレンドから順にソート
        trends.sort(key=lambda x: x['strength'], reverse=True)
        return trends

    def compute_composition_changes(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        資産クラス構成比の時系列推移を計算する。

        計算ロジック:
          各月の構成比(%) = 資産クラス時価 / 当月総時価 × 100
        """
        result_rows = []
        for date in sorted(df['date'].unique()):
            period = df[df['date'] == date]
            total_mv = period['market_value'].sum()
            for _, row in period.iterrows():
                pct = row['market_value'] / total_mv * 100 if total_mv != 0 else 0
                result_rows.append({
                    'date': date,
                    'asset_class': row['asset_class'],
                    'market_value': row['market_value'],
                    'composition_pct': pct,
                })
        return pd.DataFrame(result_rows)

    def compute_cumulative_returns(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        累積リターンを計算する。

        計算ロジック:
          累積インカム = Σ(各月インカム) [期初からの累計]
          累積キャピタル = Σ(各月キャピタル) [期初からの累計]
          累積トータル = 累積インカム + 累積キャピタル
          指数化(base=100) = 100 × (1 + 累積リターン率)
        """
        totals = self.compute_period_totals(df)
        totals['cum_income'] = totals['income'].cumsum()
        totals['cum_capital'] = totals['capital'].cumsum()
        totals['cum_total'] = totals['cum_income'] + totals['cum_capital']

        # 指数化
        initial_bv = totals['book_value'].iloc[0]
        if initial_bv != 0:
            totals['index_income'] = 100 * (1 + totals['cum_income'] / initial_bv)
            totals['index_capital'] = 100 * (1 + totals['cum_capital'] / initial_bv)
            totals['index_total'] = 100 * (1 + totals['cum_total'] / initial_bv)
        else:
            totals['index_income'] = 100
            totals['index_capital'] = 100
            totals['index_total'] = 100

        return totals

    def find_anomalies(self, df: pd.DataFrame, threshold: float = 2.0) -> List[Dict]:
        """
        月次変化における異常値を検出する。

        検出ロジック:
          1. 各指標の月次変化率を計算
          2. 変化率のZスコアを計算: Z = (x - μ) / σ
          3. |Z| > threshold の月を異常値として検出

          Zスコアの解釈:
            |Z| > 2: 約95%信頼区間外 → 通常の変動範囲を超える
            |Z| > 3: 約99.7%信頼区間外 → 極めて異常

        Returns:
            異常値情報のリスト（日本語説明・根拠付き）
        """
        changes = self.compute_monthly_changes(df)
        anomalies = []

        metrics = {
            'market_value_change_pct': 'ポートフォリオ全体の時価変化率',
            'unrealized_gl_change': 'ポートフォリオ全体の評価損益変化額',
            'income_change_pct': 'ポートフォリオ全体のインカム収益変化率',
        }

        for col, label in metrics.items():
            if col not in changes.columns:
                continue
            series = changes[col].dropna()
            if len(series) < 5:
                continue

            mean = series.mean()
            std = series.std()
            if std == 0:
                continue

            z_scores = (series - mean) / std
            for idx in z_scores.index:
                z = z_scores[idx]
                if abs(z) > threshold:
                    date = changes.loc[idx, 'date']
                    value = series[idx]
                    direction = '急増' if z > 0 else '急減'

                    # Format date as YYYY年MM月
                    try:
                        _d = pd.Timestamp(date)
                        _fmt_date = f'{_d.year}年{_d.month}月'
                    except Exception:
                        _fmt_date = str(date)
                    anomalies.append({
                        'date': date,
                        'metric': col,
                        'label': label,
                        'value': float(value),
                        'z_score': float(z),
                        'description': f'{_fmt_date}: {label}が{direction}しました（Z={z:.1f}σ、値={value:+.2f}）',
                        'severity': 'high' if abs(z) > 3 else 'medium',
                        'evidence': {
                            'method': 'Zスコアによる異常値検出',
                            'threshold': threshold,
                            'z_score': float(z),
                            'value': float(value),
                            'mean': float(mean),
                            'std': float(std),
                            'interpretation': f'平均{mean:.2f}、標準偏差{std:.2f}に対し、{abs(z):.1f}σの乖離',
                        }
                    })

        anomalies.sort(key=lambda x: abs(x['z_score']), reverse=True)
        return anomalies
