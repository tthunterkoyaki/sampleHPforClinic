﻿"""
risk_analytics.py - リスク分析モジュール

Level 2（銘柄レベル）データに対応するリスク分析を提供。
金利リスク、為替リスク、信用リスク、集中リスクを網羅的に分析する。

各分析関数は計算ロジックをdocstringで明示し、
結果にはevidence（根拠）を含めてxAI対応とする。

主な計算手法:
  - BPV: 金利1bp変動時のポートフォリオ価値変化（線形近似）
  - HHI: ハーフィンダール・ハーシュマン指数（集中度指標）
  - VaR: Value at Risk（保有期間別の最大予想損失）
"""
import pandas as pd
import numpy as np
from typing import Dict, List, Any, Optional


class RiskAnalyzer:
    """リスク分析エンジン"""

    def analyze_duration(self, df: pd.DataFrame) -> Dict[str, Any]:
        """
        デュレーション（残存年限）分析。

        計算ロジック:
          加重平均残存年限 = Σ(銘柄i残存年限 × 銘柄i時価) / Σ(銘柄i時価)
          ※ デュレーションは金利感応度の近似指標
            残存年限が長いほど金利変動の影響が大きい

          バケット分類:
            超短期: 0-1年, 短期: 1-3年, 中期: 3-5年,
            長期: 5-10年, 超長期: 10年超
        """
        result = {'available': False}
        if 'avg_remaining' not in df.columns or 'market_value' not in df.columns:
            return result

        valid = df[df['avg_remaining'].notna() & df['market_value'].notna()].copy()
        if len(valid) == 0:
            return result

        result['available'] = True
        total_mv = valid['market_value'].sum()

        # 加重平均残存年限
        result['weighted_avg'] = (valid['avg_remaining'] * valid['market_value']).sum() / total_mv if total_mv else 0

        # バケット分類
        buckets = [
            ('超短期(0-1年)', 0, 1),
            ('短期(1-3年)', 1, 3),
            ('中期(3-5年)', 3, 5),
            ('長期(5-10年)', 5, 10),
            ('超長期(10年超)', 10, 100),
        ]
        bucket_data = []
        for name, low, high in buckets:
            mask = (valid['avg_remaining'] >= low) & (valid['avg_remaining'] < high)
            subset = valid[mask]
            mv = subset['market_value'].sum()
            bucket_data.append({
                'bucket': name,
                'count': len(subset),
                'market_value': mv,
                'pct': mv / total_mv * 100 if total_mv else 0,
            })
        result['buckets'] = pd.DataFrame(bucket_data)

        # BPV集計
        bpv_cols = {'jpy_bpv_10': '円金利10BPV', 'fc_bpv_10': '外貨金利10BPV'}
        bpv_data = {}
        for col, label in bpv_cols.items():
            if col in df.columns:
                bpv_data[label] = df[col].sum()
        result['bpv_summary'] = bpv_data

        result['evidence'] = {
            'method': '時価加重平均',
            'n_securities': len(valid),
            'total_market_value': float(total_mv),
        }
        return result

    def analyze_yield(self, df: pd.DataFrame) -> Dict[str, Any]:
        """
        利回り分析。

        計算ロジック:
          簿価利回り = 年間インカム / 簿価（取得原価ベースの利回り）
          時価利回り = 年間インカム / 時価（現在価格ベースの利回り）

          加重平均利回り = Σ(銘柄i利回り × 銘柄i時価) / Σ(銘柄i時価)
          ※ 簿価利回り > 時価利回り の場合、
            含み益がある（市場金利低下による価格上昇）
        """
        result = {'available': False}

        has_by = 'book_yield' in df.columns
        has_my = 'market_yield' in df.columns
        has_mv = 'market_value' in df.columns

        if not (has_by or has_my) or not has_mv:
            return result

        result['available'] = True
        valid = df[df['market_value'].notna()].copy()
        total_mv = valid['market_value'].sum()

        if has_by:
            by_valid = valid[valid['book_yield'].notna()]
            if len(by_valid) > 0 and total_mv > 0:
                result['weighted_book_yield'] = (by_valid['book_yield'] * by_valid['market_value']).sum() / by_valid['market_value'].sum()
                result['book_yield_stats'] = {
                    'mean': float(by_valid['book_yield'].mean()),
                    'median': float(by_valid['book_yield'].median()),
                    'min': float(by_valid['book_yield'].min()),
                    'max': float(by_valid['book_yield'].max()),
                    'std': float(by_valid['book_yield'].std()),
                }

        if has_my:
            my_valid = valid[valid['market_yield'].notna()]
            if len(my_valid) > 0 and total_mv > 0:
                result['weighted_market_yield'] = (my_valid['market_yield'] * my_valid['market_value']).sum() / my_valid['market_value'].sum()
                result['market_yield_stats'] = {
                    'mean': float(my_valid['market_yield'].mean()),
                    'median': float(my_valid['market_yield'].median()),
                    'min': float(my_valid['market_yield'].min()),
                    'max': float(my_valid['market_yield'].max()),
                }

        if has_by and has_my:
            spread = result.get('weighted_book_yield', 0) - result.get('weighted_market_yield', 0)
            result['yield_spread'] = spread
            if spread > 0:
                result['yield_spread_interpretation'] = '簿価利回り > 時価利回り: 全体として含み益状態（金利低下恩恵）'
            else:
                result['yield_spread_interpretation'] = '簿価利回り < 時価利回り: 全体として含み損状態（金利上昇影響）'

        return result

    def analyze_concentration(self, df: pd.DataFrame) -> Dict[str, Any]:
        """
        集中リスク分析。

        計算ロジック:
          HHI (ハーフィンダール・ハーシュマン指数):
            HHI = Σ(シェアi)^2  （シェアは0-1の割合）
            HHI解釈:
              < 0.15: 分散されている
              0.15-0.25: やや集中
              > 0.25: 高度に集中

          上位集中度:
            Top-N集中度 = 上位N件の合計シェア
            Top-1 > 30%: 特定銘柄への依存リスク
            Top-5 > 70%: ポートフォリオが偏っている
        """
        result = {'available': False}
        if 'market_value' not in df.columns:
            return result

        result['available'] = True
        total_mv = df['market_value'].sum()
        if total_mv == 0:
            return result

        # 発行体別集中度
        if 'issuer_name' in df.columns:
            issuer_conc = self._compute_concentration(
                df, 'issuer_name', 'market_value', '発行体')
            result['issuer'] = issuer_conc

        # 業種別
        if 'industry' in df.columns:
            industry_conc = self._compute_concentration(
                df, 'industry', 'market_value', '業種')
            result['industry'] = industry_conc

        # 通貨別
        if 'issue_currency' in df.columns:
            currency_conc = self._compute_concentration(
                df, 'issue_currency', 'market_value', '通貨')
            result['currency'] = currency_conc

        # 種別
        if 'category' in df.columns:
            cat_conc = self._compute_concentration(
                df, 'category', 'market_value', '種別')
            result['category'] = cat_conc

        return result

    def _compute_concentration(self, df, group_col, value_col, label) -> Dict:
        """集中度の共通計算ロジック"""
        grouped = df.groupby(group_col)[value_col].sum().sort_values(ascending=False)
        total = grouped.sum()
        if total == 0:
            return {}

        shares = grouped / total
        hhi = (shares ** 2).sum()

        top_n = {}
        for n in [1, 3, 5, 10]:
            if len(shares) >= n:
                top_n[n] = float(shares.head(n).sum() * 100)

        # HHI判定
        if hhi < 0.15:
            hhi_level = '分散'
            hhi_desc = f'{label}別の分散は良好です（HHI={hhi:.3f}）'
        elif hhi < 0.25:
            hhi_level = 'やや集中'
            hhi_desc = f'{label}別にやや集中が見られます（HHI={hhi:.3f}）'
        else:
            hhi_level = '高集中'
            hhi_desc = f'{label}別に高い集中度が検出されました（HHI={hhi:.3f}）。分散の検討を推奨します。'

        distribution = grouped.reset_index()
        distribution.columns = [label, '時価']
        distribution['構成比(%)'] = distribution['時価'] / total * 100

        return {
            'hhi': float(hhi),
            'hhi_level': hhi_level,
            'hhi_description': hhi_desc,
            'top_n': top_n,
            'distribution': distribution,
            'n_groups': len(grouped),
            'evidence': {
                'method': f'HHI = Σ(シェア^2), {label}数={len(grouped)}',
                'top_1': f'{grouped.index[0]}: {shares.iloc[0]*100:.1f}%' if len(grouped) > 0 else 'N/A',
            }
        }

    def analyze_interest_rate_risk(self, df: pd.DataFrame) -> Dict[str, Any]:
        """
        金利リスク分析。

        計算ロジック:
          BPV (Basis Point Value):
            金利が1bp(=0.01%)変動した場合のポートフォリオ価値変化額
            BPV = -修正デュレーション × 時価 × 0.0001
            ※ 本分析では個別銘柄のBPVを合算

          ΔEVE (Economic Value of Equity の変化):
            銀行勘定の金利リスク（IRRBB）指標
            パラレル上昇: 全年限の金利が一律上昇した場合の影響
            パラレル低下: 全年限の金利が一律低下した場合の影響
            スティープ化: 長期金利上昇・短期金利低下

          ΔNII (Net Interest Income の変化):
            金利変動が今後1年間の純利息収益に与える影響
        """
        result = {'available': False}

        bpv_cols = ['jpy_bpv_10', 'jpy_bpv_100', 'fc_bpv_10', 'fc_bpv_100']
        eve_cols = ['eve_parallel_up', 'eve_parallel_down', 'eve_steepening']
        nii_cols = ['nii_1y', 'nii_parallel_up', 'nii_parallel_down']

        has_any = any(col in df.columns for col in bpv_cols + eve_cols + nii_cols)
        if not has_any:
            return result

        result['available'] = True

        # BPV集計
        bpv_summary = {}
        for col in bpv_cols:
            if col in df.columns:
                bpv_summary[col] = {
                    'total': float(df[col].sum()),
                    'mean': float(df[col].mean()),
                    'min': float(df[col].min()),
                    'max': float(df[col].max()),
                }
        result['bpv'] = bpv_summary

        # ΔEVE集計
        eve_summary = {}
        for col in eve_cols:
            if col in df.columns:
                eve_summary[col] = float(df[col].sum())
        result['eve'] = eve_summary

        # ΔNII集計
        nii_summary = {}
        for col in nii_cols:
            if col in df.columns:
                nii_summary[col] = float(df[col].sum())
        result['nii'] = nii_summary

        result['evidence'] = {
            'method': 'BPVは線形近似（1次テイラー展開）。EVE/NIIはシナリオベース。',
            'assumption': '個別銘柄のリスク指標を合算（分散効果は未考慮）',
        }
        return result

    def analyze_fx_risk(self, df: pd.DataFrame) -> Dict[str, Any]:
        """
        為替リスク分析。

        計算ロジック:
          通貨別エクスポージャー = 通貨別外貨建て時価合計
          為替デルタ = 為替レート1%変動時の損益変化
          ヘッジ有/無の区分による実効為替リスク把握
        """
        result = {'available': False}

        if 'issue_currency' not in df.columns:
            return result

        result['available'] = True

        # 通貨別エクスポージャー
        currency_exp = df.groupby('issue_currency').agg({
            'market_value': 'sum',
        }).reset_index()
        total_mv = currency_exp['market_value'].sum()
        currency_exp['pct'] = currency_exp['market_value'] / total_mv * 100 if total_mv else 0
        currency_exp = currency_exp.sort_values('market_value', ascending=False)
        result['currency_exposure'] = currency_exp

        # 外貨比率
        jpy_mv = df[df['issue_currency'].str.contains('JPY|円|日本', na=False)]['market_value'].sum()
        result['foreign_ratio'] = (1 - jpy_mv / total_mv) * 100 if total_mv else 0

        # 為替デルタ
        if 'delta_fx' in df.columns:
            result['total_fx_delta'] = float(df['delta_fx'].sum())
            fx_delta_by_ccy = df.groupby('issue_currency')['delta_fx'].sum().to_dict()
            result['fx_delta_by_currency'] = fx_delta_by_ccy

        # 外貨建て金額
        if 'market_value_fc' in df.columns:
            fc_exp = df[df['market_value_fc'].notna()].groupby('issue_currency')['market_value_fc'].sum()
            result['fc_exposure'] = fc_exp.to_dict()

        return result

    def analyze_credit_risk(self, df: pd.DataFrame) -> Dict[str, Any]:
        """
        信用リスク分析。

        計算ロジック:
          リスクアセット = Σ(銘柄i時価 × リスクウエイトi)
          ※ リスクウエイトはバーゼル規制に基づく信用リスクの重み
            国債: 0%, 銀行: 20-50%, 事業法人: 50-100%

          時価レベル区分:
            Level 1: 活発な市場の公表価格
            Level 2: 観察可能な市場データ
            Level 3: 観察不能な入力値
        """
        result = {'available': False}

        if 'risk_weight' not in df.columns and 'fair_value_level' not in df.columns:
            if 'var_1y' not in df.columns:
                return result

        result['available'] = True

        # リスクウエイト分布
        if 'risk_weight' in df.columns and 'market_value' in df.columns:
            rw_dist = df.groupby('risk_weight').agg({
                'market_value': 'sum',
            }).reset_index()
            total_mv = rw_dist['market_value'].sum()
            rw_dist['pct'] = rw_dist['market_value'] / total_mv * 100 if total_mv else 0
            result['rw_distribution'] = rw_dist

            # 加重平均リスクウエイト
            if total_mv > 0:
                result['weighted_avg_rw'] = (df['risk_weight'] * df['market_value']).sum() / total_mv

        # リスクアセット
        if 'risk_asset' in df.columns:
            result['total_risk_asset'] = float(df['risk_asset'].sum())

        # 時価レベル区分
        if 'fair_value_level' in df.columns:
            fv_dist = df.groupby('fair_value_level').agg({
                'market_value': 'sum',
            }).reset_index()
            total_mv = fv_dist['market_value'].sum()
            fv_dist['pct'] = fv_dist['market_value'] / total_mv * 100 if total_mv else 0
            result['fv_level_distribution'] = fv_dist

        # VaR
        for col in ['var_1y', 'var_5y']:
            if col in df.columns:
                result[f'total_{col}'] = float(df[col].sum())

        return result

    def analyze_unrealized_gl(self, df: pd.DataFrame) -> Dict[str, Any]:
        """
        評価損益分析。

        計算ロジック:
          評価損益 = 時価 - 簿価
          評価損益率 = 評価損益 / 簿価

          含み損銘柄リスト: 損失額の大きい順に上位表示
          分布分析: ヒストグラム用のビン分けデータ
        """
        result = {'available': False}

        if 'unrealized_gl' not in df.columns:
            return result

        result['available'] = True
        gl = df['unrealized_gl']

        result['total_gl'] = float(gl.sum())
        result['n_gain'] = int((gl > 0).sum())
        result['n_loss'] = int((gl < 0).sum())
        result['n_even'] = int((gl == 0).sum())
        result['max_gain'] = float(gl.max())
        result['max_loss'] = float(gl.min())

        # 含み損トップ10
        if 'security_name' in df.columns:
            loss_df = df[df['unrealized_gl'] < 0].nsmallest(10, 'unrealized_gl')
            loss_list = []
            for _, row in loss_df.iterrows():
                item = {
                    'name': str(row.get('security_name', '')),
                    'unrealized_gl': float(row['unrealized_gl']),
                }
                if 'gl_ratio' in df.columns:
                    item['gl_ratio'] = float(row.get('gl_ratio', 0))
                if 'market_value' in df.columns:
                    item['market_value'] = float(row.get('market_value', 0))
                loss_list.append(item)
            result['top_losses'] = loss_list

            # 含み益トップ10
            gain_df = df[df['unrealized_gl'] > 0].nlargest(10, 'unrealized_gl')
            gain_list = []
            for _, row in gain_df.iterrows():
                item = {
                    'name': str(row.get('security_name', '')),
                    'unrealized_gl': float(row['unrealized_gl']),
                }
                gain_list.append(item)
            result['top_gains'] = gain_list

        # GL率分布
        if 'gl_ratio' in df.columns:
            glr = df['gl_ratio'].dropna()
            result['gl_ratio_stats'] = {
                'mean': float(glr.mean()),
                'median': float(glr.median()),
                'std': float(glr.std()),
                'min': float(glr.min()),
                'max': float(glr.max()),
            }

        result['evidence'] = {
            'method': '評価損益 = 時価 - 簿価',
            'n_securities': len(df),
        }
        return result

    def generate_risk_summary(self, df: pd.DataFrame) -> List[Dict[str, Any]]:
        """
        リスク分析の総合サマリーを生成する。

        各リスク要因を分析し、重要度の高い順にソートして返す。
        各項目にはseverity（重要度）とevidence（根拠）を含める。
        """
        insights = []

        # デュレーション分析
        dur = self.analyze_duration(df)
        if dur.get('available') and 'weighted_avg' in dur:
            avg_dur = dur['weighted_avg']
            if avg_dur > 7:
                insights.append({
                    'title': '⏱️ 長期デュレーション',
                    'description': f'加重平均残存年限が{avg_dur:.1f}年と長めです。金利上昇時の価格下落リスクが高い状態です。',
                    'severity': 'high' if avg_dur > 10 else 'medium',
                    'category': '金利リスク',
                    'evidence': f'加重平均残存年限={avg_dur:.1f}年（時価ウエイト）',
                })

        # 集中度分析
        conc = self.analyze_concentration(df)
        if conc.get('available'):
            for key in ['issuer', 'industry', 'currency']:
                if key in conc and 'hhi' in conc[key]:
                    hhi = conc[key]['hhi']
                    if hhi > 0.15:
                        label = {'issuer': '発行体', 'industry': '業種', 'currency': '通貨'}[key]
                        insights.append({
                            'title': f'🔍 {label}集中リスク',
                            'description': conc[key]['hhi_description'],
                            'severity': 'high' if hhi > 0.25 else 'medium',
                            'category': '集中リスク',
                            'evidence': conc[key].get('evidence', {}),
                        })

        # 為替リスク
        fx = self.analyze_fx_risk(df)
        if fx.get('available') and fx.get('foreign_ratio', 0) > 30:
            insights.append({
                'title': '💱 為替エクスポージャー',
                'description': f'外貨建て資産比率が{fx["foreign_ratio"]:.1f}%と高めです。為替変動への感応度にご注意ください。',
                'severity': 'medium',
                'category': '為替リスク',
                'evidence': f'外貨比率={fx["foreign_ratio"]:.1f}%',
            })

        # 評価損益
        gl = self.analyze_unrealized_gl(df)
        if gl.get('available'):
            total_gl = gl['total_gl']
            if total_gl < 0:
                insights.append({
                    'title': '📉 含み損状態',
                    'description': f'ポートフォリオ全体で{total_gl:,.0f}の含み損があります（含み損銘柄数: {gl["n_loss"]}）',
                    'severity': 'high' if gl['n_loss'] > gl['n_gain'] else 'medium',
                    'category': '評価損益',
                    'evidence': f'含み益{gl["n_gain"]}銘柄 vs 含み損{gl["n_loss"]}銘柄',
                })

        # 重要度順にソート
        sev_order = {'high': 0, 'medium': 1, 'low': 2}
        insights.sort(key=lambda x: sev_order.get(x.get('severity', 'low'), 99))
        return insights
