﻿"""
portfolio_analytics.py - コアポートフォリオ分析エンジン

全レベル（Level 1-3）のデータに対応する分析関数群。
各関数は計算ロジックをdocstringで明確に説明し、
分析結果には根拠（evidence）を含めてxAIに対応する。

計算ロジックの概要:
  - リターン計算: 月次収益(インカム+キャピタル) / 期初簿価
  - 構成比: 資産クラス別時価 / ポートフォリオ全体時価
  - 評価損益: 時価 - 簿価
  - 利回り: インカム収益 / 簿価（年率換算は×12）
"""
import pandas as pd
import numpy as np
from typing import Dict, List, Any, Optional, Tuple
import io


def compute_portfolio_summary(monthly_df: pd.DataFrame) -> Dict[str, Any]:
    """
    ポートフォリオの概要指標を計算する。

    計算ロジック:
      - 総時価 = 最新月の全資産クラス時価合計
      - 総簿価 = 最新月の全資産クラス簿価合計
      - 評価損益 = 総時価 - 総簿価
      - 評価損益率 = 評価損益 / 総簿価
      - 累計インカム = 全期間のインカム収益合計
      - 累計キャピタル = 全期間のキャピタル収益合計
      - 累計トータルリターン = インカム + キャピタル
    """
    latest = monthly_df[monthly_df['date'] == monthly_df['date'].max()]
    all_periods = monthly_df.copy()

    total_market = latest['market_value'].sum()
    total_book = latest['book_value'].sum()
    unrealized_gl = total_market - total_book
    gl_ratio = unrealized_gl / total_book if total_book != 0 else 0

    total_income = all_periods['income'].sum()
    total_capital = all_periods['capital'].sum()
    total_return = total_income + total_capital

    # 期間数から年率換算
    n_months = monthly_df['date'].nunique()
    annualized_return_rate = (total_return / total_book) * (12 / max(n_months, 1)) if total_book != 0 else 0

    return {
        'total_market_value': total_market,
        'total_book_value': total_book,
        'unrealized_gl': unrealized_gl,
        'gl_ratio': gl_ratio,
        'total_income': total_income,
        'total_capital': total_capital,
        'total_return': total_return,
        'annualized_return_rate': annualized_return_rate,
        'n_months': n_months,
        'n_asset_classes': monthly_df['asset_class'].nunique(),
        'latest_date': monthly_df['date'].max(),
        # 根拠情報（xAI用）
        'evidence': {
            'calculation': '総時価/簿価は最新月の合計、収益は全期間累計',
            'latest_date': monthly_df['date'].max(),
            'data_points': len(monthly_df),
        }
    }


def compute_asset_composition(monthly_df: pd.DataFrame,
                                target_date: Optional[str] = None) -> pd.DataFrame:
    """
    資産クラス別の構成比を計算する。

    計算ロジック:
      構成比(%) = 資産クラス時価 / ポートフォリオ全体時価 × 100

    Args:
        monthly_df: 月次データ
        target_date: 対象年月（Noneなら最新月）

    Returns:
        asset_class, market_value, book_value, composition_pct, unrealized_gl, gl_ratio
    """
    if target_date is None:
        target_date = monthly_df['date'].max()

    period = monthly_df[monthly_df['date'] == target_date].copy()
    total_mv = period['market_value'].sum()

    period['composition_pct'] = np.where(
        total_mv != 0,
        period['market_value'] / total_mv * 100,
        0
    )
    period['gl_ratio'] = np.where(
        period['book_value'] != 0,
        period['unrealized_gl'] / period['book_value'] * 100,
        0
    )

    return period.sort_values('market_value', ascending=False).reset_index(drop=True)


def compute_monthly_returns(monthly_df: pd.DataFrame) -> pd.DataFrame:
    """
    月次リターンを計算する。

    計算ロジック:
      月次リターン = (インカム収益 + キャピタル収益) / 期初簿価
      ※ 期初簿価 = 当月簿価（月末値を近似として使用）

      インカム利回り（月次） = インカム収益 / 簿価
      キャピタル利回り（月次） = キャピタル収益 / 簿価
    """
    # 全体集計
    totals = monthly_df.groupby('date').agg({
        'book_value': 'sum',
        'market_value': 'sum',
        'income': 'sum',
        'capital': 'sum',
        'unrealized_gl': 'sum',
    }).reset_index()

    totals = totals.sort_values('date')
    totals['total_return'] = totals['income'] + totals['capital']
    totals['return_rate'] = np.where(
        totals['book_value'] != 0,
        totals['total_return'] / totals['book_value'],
        0
    )
    totals['income_yield'] = np.where(
        totals['book_value'] != 0,
        totals['income'] / totals['book_value'],
        0
    )
    totals['capital_yield'] = np.where(
        totals['book_value'] != 0,
        totals['capital'] / totals['book_value'],
        0
    )

    # 累積リターン（複利）
    totals['cumulative_return'] = (1 + totals['return_rate']).cumprod() - 1

    return totals


def compute_income_capital_breakdown(monthly_df: pd.DataFrame) -> Dict[str, pd.DataFrame]:
    """
    インカム・キャピタル収益の分解分析。

    計算ロジック:
      - 資産クラス別: 各資産クラスのインカム/キャピタル合計と構成比
      - 時系列: 月次のインカム/キャピタル推移
      - インカム比率 = インカム / (インカム + |キャピタル|)
        ※ 安定収益の指標。比率が高いほど安定的。
    """
    # 資産クラス別
    by_asset = monthly_df.groupby('asset_class').agg({
        'income': 'sum',
        'capital': 'sum',
    }).reset_index()
    by_asset['total'] = by_asset['income'] + by_asset['capital']
    total_income = by_asset['income'].sum()
    total_capital = by_asset['capital'].sum()
    by_asset['income_pct'] = np.where(total_income != 0,
                                       by_asset['income'] / total_income * 100, 0)

    # 時系列
    by_month = monthly_df.groupby('date').agg({
        'income': 'sum',
        'capital': 'sum',
    }).reset_index().sort_values('date')
    by_month['total'] = by_month['income'] + by_month['capital']
    by_month['cumulative_income'] = by_month['income'].cumsum()
    by_month['cumulative_capital'] = by_month['capital'].cumsum()
    by_month['cumulative_total'] = by_month['total'].cumsum()

    # 安定性指標
    income_stability = total_income / (total_income + abs(total_capital)) if (total_income + abs(total_capital)) != 0 else 0

    return {
        'by_asset': by_asset,
        'by_month': by_month,
        'income_stability': income_stability,
        'total_income': total_income,
        'total_capital': total_capital,
    }


def compute_security_summary(security_df: pd.DataFrame) -> Dict[str, Any]:
    """
    銘柄レベルデータのサマリー統計。

    計算ロジック:
      - 加重平均利回り = Σ(個別利回り × 時価) / Σ時価
      - 加重平均デュレーション = Σ(個別デュレーション × 時価) / Σ時価
      - ポートフォリオBPV = Σ個別BPV
    """
    result = {'n_securities': len(security_df)}

    if 'market_value' in security_df.columns:
        total_mv = security_df['market_value'].sum()
        result['total_market_value'] = total_mv

        # 加重平均利回り
        if 'book_yield' in security_df.columns:
            mask = security_df['book_yield'].notna() & security_df['market_value'].notna()
            if mask.any():
                w = security_df.loc[mask, 'market_value']
                y = security_df.loc[mask, 'book_yield']
                result['weighted_book_yield'] = (w * y).sum() / w.sum() if w.sum() != 0 else 0

        if 'market_yield' in security_df.columns:
            mask = security_df['market_yield'].notna() & security_df['market_value'].notna()
            if mask.any():
                w = security_df.loc[mask, 'market_value']
                y = security_df.loc[mask, 'market_yield']
                result['weighted_market_yield'] = (w * y).sum() / w.sum() if w.sum() != 0 else 0

        # 加重平均残存年限
        if 'avg_remaining' in security_df.columns:
            mask = security_df['avg_remaining'].notna() & security_df['market_value'].notna()
            if mask.any():
                w = security_df.loc[mask, 'market_value']
                d = security_df.loc[mask, 'avg_remaining']
                result['weighted_avg_remaining'] = (w * d).sum() / w.sum() if w.sum() != 0 else 0

    # BPV合計
    for col in ['jpy_bpv_10', 'jpy_bpv_100', 'fc_bpv_10', 'fc_bpv_100']:
        if col in security_df.columns:
            result[f'total_{col}'] = security_df[col].sum()

    # VaR合計
    for col in ['var_1y', 'var_5y']:
        if col in security_df.columns:
            result[f'total_{col}'] = security_df[col].sum()

    # 評価損益
    if 'unrealized_gl' in security_df.columns:
        result['total_unrealized_gl'] = security_df['unrealized_gl'].sum()
        result['n_gain'] = (security_df['unrealized_gl'] > 0).sum()
        result['n_loss'] = (security_df['unrealized_gl'] < 0).sum()
        result['n_even'] = (security_df['unrealized_gl'] == 0).sum()

    result['evidence'] = {
        'calculation': '加重平均は時価ウエイト。BPV/VaRは単純合計（線形近似）。',
        'n_securities': len(security_df),
    }

    return result


def compute_transaction_summary(transaction_df: pd.DataFrame) -> Dict[str, Any]:
    """
    取引明細のサマリー分析。

    計算ロジック:
      - 売買回転率 = 期間中売却金額 / 期初ポートフォリオ時価
      - 平均取引コスト = 総コスト / 総取引金額
      - インカム受領パターン: 月別インカム受領額の集計
    """
    result = {'n_transactions': len(transaction_df)}

    if 'trade_type' in transaction_df.columns:
        type_counts = transaction_df['trade_type'].value_counts().to_dict()
        result['type_counts'] = type_counts

    # 金額列の特定（amount または income_amount）
    amt_col = 'amount' if 'amount' in transaction_df.columns else ('income_amount' if 'income_amount' in transaction_df.columns else None)

    if amt_col:
        result['total_amount'] = transaction_df[amt_col].sum()

        if 'trade_type' in transaction_df.columns:
            buys = transaction_df[transaction_df['trade_type'].str.contains('購入|買', na=False)]
            sells = transaction_df[transaction_df['trade_type'].str.contains('売却|売', na=False)]

            result['total_buy_amount'] = buys[amt_col].sum() if len(buys) > 0 else 0
            result['total_sell_amount'] = sells[amt_col].sum() if len(sells) > 0 else 0

    if 'cost' in transaction_df.columns:
        result['total_cost'] = transaction_df['cost'].sum()
        if amt_col and transaction_df[amt_col].sum() != 0:
            result['avg_cost_ratio'] = transaction_df['cost'].sum() / transaction_df[amt_col].sum()

    # 月別集計
    if 'trade_date' in transaction_df.columns and amt_col:
        transaction_df = transaction_df.copy()
        transaction_df['month'] = pd.to_datetime(transaction_df['trade_date']).dt.strftime('%Y-%m')
        monthly = transaction_df.groupby('month')[amt_col].agg(['sum', 'count']).reset_index()
        monthly.columns = ['month', 'total_amount', 'n_trades']
        result['monthly_summary'] = monthly

    return result


def export_to_excel(data_dict: Dict[str, pd.DataFrame]) -> bytes:
    """
    分析結果をExcelファイルとしてエクスポートする。

    Args:
        data_dict: {シート名: DataFrame} の辞書

    Returns:
        Excelファイルのバイトデータ
    """
    # Asset class order for sorting
    _AC_ORDER = ['国内債券（固定）','国内債券（変動）','外国債券（ヘッジ有）','外国債券（ヘッジ無）','国内株式','J-REIT','その他投信']
    output = io.BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        for sheet_name, df in data_dict.items():
            # Sort by asset class order if applicable
            for col in ['asset_class', '資産クラス']:
                if col in df.columns:
                    _order_map = {c: i for i, c in enumerate(_AC_ORDER)}
                    df = df.copy()
                    df['_sort'] = df[col].map(_order_map).fillna(999)
                    df = df.sort_values('_sort').drop(columns=['_sort'])
                    break
            # シート名を31文字以内に（Excel制限）
            safe_name = sheet_name[:31]
            df.to_excel(writer, sheet_name=safe_name, index=False)
    output.seek(0)
    return output.getvalue()

