﻿"""
data_models.py - ポートフォリオデータモデル定義

3段階のデータ粒度に対応：
  Level 1: 月次 × 資産クラス（簿価・時価・インカム・キャピタル）
  Level 2: 銘柄レベルスナップショット（デュレーション・利回り・リスク指標等）
  Level 3: 銘柄 + 取引明細（売買・インカム受領等）
"""
from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any
from enum import Enum
import pandas as pd


class DataLevel(Enum):
    """データ粒度レベル"""
    LEVEL1 = 1  # 月次 × 資産クラス
    LEVEL2 = 2  # 銘柄レベルスナップショット
    LEVEL3 = 3  # 銘柄 + 取引明細


# ─── Level 1: 月次資産クラス 必須列名 ───────────────────────
# 列名は完全一致ではなく、部分一致で判定する
LEVEL1_REQUIRED_COLUMNS = {
    'date':       ['年月', '基準日', '日付', 'date'],
    'asset_class':['資産クラス', '資産区分', '区分', 'asset_class'],
    'book_value': ['簿価', '簿価金額', 'book_value'],
    'market_value':['時価', '時価金額', 'market_value'],
    'income':     ['インカム収益額', 'インカム', 'インカム収益', 'income'],
    'capital':    ['キャピタル収益額', 'キャピタル', 'キャピタル収益', 'capital_gain'],
}


# ─── Level 2: 銘柄レベル 認識対象列名 ──────────────────────
# 列名ベースで柔軟にマッピングする（列順は問わない）
LEVEL2_COLUMN_MAP = {
    # 基本情報
    'data_no':        ['データNo', 'データNo.', 'No', 'ID'],
    'category':       ['種別', '区分', 'カテゴリ'],
    'sub_category':   ['分類区分', 'サブ区分'],
    'security_name':  ['銘柄名', '銘柄', 'security_name'],
    'security_code':  ['銘柄コード', 'コード', 'security_code'],
    'issuer_name':    ['発行体名', '発行体', 'issuer'],
    'issuer_category':['発行体区分'],
    'industry':       ['業種', 'セクター', 'sector'],

    # 金利・期間情報
    'coupon_rate':    ['利率', 'クーポン', 'coupon_rate'],
    'issue_date':     ['発行日', 'issue_date'],
    'maturity_date':  ['償還日', 'maturity_date'],
    'next_call_date': ['次回コール日', 'next_call'],
    'call_expected':  ['コール有無の予想', 'コール予想'],
    'trade_date':     ['当初約定日', 'trade_date'],
    'settle_date':    ['当初受渡日', 'settle_date'],

    # 通貨情報
    'issue_currency':      ['発行通貨', '通貨', 'currency'],
    'coupon_currency':     ['利率判定通貨'],
    'redemption_currency': ['償還通貨'],

    # 金額情報
    'face_value':     ['額面', 'face_value', 'notional'],
    'book_value':     ['簿価', '簿価金額', '簿価（償却考慮）', 'book_value'],
    'book_value_raw': ['簿価（償却未考慮）'],
    'market_value':   ['時価', '時価金額', '時価（償却考慮）', 'market_value'],
    'market_value_raw':['時価（償却未考慮）'],
    'unrealized_gl':  ['評価損益', 'unrealized_gl'],
    'amortization':   ['償却額', 'amortization'],
    'period_amort':   ['期中償却額'],
    'fx_gl':          ['為替差損益', 'fx_gain_loss'],

    # 外貨金額
    'book_value_fc':  ['簿価金額（外貨）', 'book_fc'],
    'market_value_fc':['時価金額（外貨）', 'market_fc'],

    # 為替レート
    'book_fx_rate':   ['簿価為替レート', 'book_fx'],
    'market_fx_rate': ['時価為替レート', 'market_fx'],
    'amort_fx_rate':  ['償却額為替レート'],

    # 単価
    'book_price':     ['簿価単価', 'book_price'],
    'market_price':   ['時価単価', 'market_price'],

    # 時価レベル
    'fair_value_level':['時価レベル区分', 'FV_level'],

    # 仕組債
    'structured_fx':  ['仕組債評価為替レート'],
    'structured_eq':  ['仕組債評価株価'],

    # 利回り・デュレーション
    'avg_remaining':  ['平均残存年限', 'remaining_years'],
    'book_yield':     ['簿価利回り', 'book_yield'],
    'market_yield':   ['時価利回り', 'market_yield'],
    'book_compound':  ['簿価複利'],
    'market_compound':['時価複利'],
    'gl_ratio':       ['評価損益率', 'gl_ratio'],

    # リスク指標
    'risk_weight':    ['リスクウエイト', 'risk_weight'],
    'risk_asset':     ['リスクアセット金額', 'risk_asset'],
    'rw_category':    ['リスクウエイト区分'],
    'var_1y':         ['VaR1Y', 'VaR_1Y'],
    'var_5y':         ['VaR5Y', 'VaR_5Y'],

    # BPV（金利感応度）
    'jpy_bpv_10':     ['円金利10BPV', 'JPY_BPV10'],
    'jpy_bpv_100':    ['円金利100BPV', 'JPY_BPV100'],
    'fc_bpv_10':      ['外貨金利10BPV', 'FC_BPV10'],
    'fc_bpv_100':     ['外貨金利100BPV', 'FC_BPV100'],

    # デルタ（感応度）
    'delta_fx':       ['為替Δ', 'delta_fx'],
    'delta_equity':   ['株価Δ', 'delta_equity'],
    'delta_commodity':['コモディティΔ', 'delta_commodity'],
    'delta_reit':     ['REITΔ', 'delta_reit'],

    # ΔEVE・NII
    'eve_parallel_up':  ['ΔEVE(パラレル上昇)', 'EVE_up'],
    'eve_parallel_down':['ΔEVE(パラレル低下)', 'EVE_down'],
    'eve_steepening':   ['ΔEVE(スティープ化)', 'EVE_steep'],
    'nii_1y':           ['NII(1年)', 'NII_1Y'],
    'nii_parallel_up':  ['ΔNII(1年、パラレル上昇)', 'NII_up'],
    'nii_parallel_down':['ΔNII(1年、パラレル低下)', 'NII_down'],

    # 取引先
    'counterparty':   ['取引先(購入)', '取引先', 'counterparty'],
}


# ─── Level 3: 取引明細 認識対象列名 ──────────────────────
LEVEL3_COLUMN_MAP = {
    'trade_date':     ['取引日', '約定日', 'trade_date'],
    'settle_date':    ['受渡日', 'settlement_date'],
    'security_code':  ['銘柄コード', 'コード', 'security_code'],
    'security_name':  ['銘柄名', '銘柄'],
    'trade_type':     ['売買区分', '区分', '取引種別', 'type'],
    'quantity':       ['数量', '口数', 'quantity'],
    'price':          ['単価', '約定単価', 'price'],
    'amount':         ['金額', '約定金額', 'amount'],
    'cost':           ['コスト', '手数料', '売買コスト', 'cost'],
    'income_amount':  ['インカム金額', '利金', '配当', 'income'],
    'currency':       ['通貨', 'currency'],
    'fx_rate':        ['為替レート', 'fx_rate'],
}


@dataclass
class PortfolioData:
    """
    ポートフォリオデータの統合コンテナ

    Attributes:
        level: 検出されたデータ粒度レベル
        monthly_data: Level 1 月次×資産クラスデータ（常に存在）
        security_data: Level 2 銘柄レベルデータ（Level 2以上で存在）
        transaction_data: Level 3 取引明細データ（Level 3で存在）
        metadata: 追加メタ情報（日付範囲、資産クラス一覧等）
        column_mapping: 実際に使用された列名マッピング
    """
    level: DataLevel
    monthly_data: pd.DataFrame  # 正規化済みLevel 1データ
    security_data: Optional[pd.DataFrame] = None  # 正規化済みLevel 2データ
    transaction_data: Optional[pd.DataFrame] = None  # 正規化済みLevel 3データ
    metadata: Dict[str, Any] = field(default_factory=dict)
    column_mapping: Dict[str, str] = field(default_factory=dict)
    original_asset_order: Optional[list] = None

    @property
    def has_security_data(self) -> bool:
        return self.security_data is not None and len(self.security_data) > 0

    @property
    def has_transaction_data(self) -> bool:
        return self.transaction_data is not None and len(self.transaction_data) > 0

    @property
    def date_range(self) -> tuple:
        """データの日付範囲を返す"""
        dates = pd.to_datetime(self.monthly_data['date'])
        return (dates.min(), dates.max())

    @property
    def asset_classes(self) -> list:
        """含まれる資産クラス一覧 (Excelの元の行順)"""
        if self.original_asset_order:
            return list(self.original_asset_order)
        # Fallback: first appearance in data
        seen = []
        for ac in self.monthly_data['asset_class']:
            if ac not in seen:
                seen.append(ac)
        return seen

    @property
    def n_periods(self) -> int:
        """期間数"""
        return self.monthly_data['date'].nunique()

    @property
    def latest_date(self) -> str:
        """最新日付"""
        return str(pd.to_datetime(self.monthly_data['date']).max().strftime('%Y-%m'))


def match_column_name(df_columns: list, candidates: list) -> Optional[str]:
    """
    DataFrameの列名リストから、候補リストにマッチする列名を見つける。

    マッチング戦略（優先順）:
      1. 完全一致
      2. 部分一致（候補が列名に含まれる）
      3. 列名が候補に含まれる

    Args:
        df_columns: DataFrameの列名リスト
        candidates: マッチング候補の列名リスト

    Returns:
        マッチした列名、見つからなければNone
    """
    # 1. 完全一致
    for col in df_columns:
        col_clean = str(col).strip()
        for cand in candidates:
            if col_clean == cand:
                return col

    # 2. 部分一致（候補が列名に含まれる）
    for col in df_columns:
        col_clean = str(col).strip()
        for cand in candidates:
            if cand in col_clean:
                return col

    # 3. 列名が候補に含まれる
    for col in df_columns:
        col_clean = str(col).strip()
        for cand in candidates:
            if col_clean in cand and len(col_clean) >= 2:
                return col

    return None
