"""tab_revenue.py - 収益分析タブ（月次リターンも統合）"""
import streamlit as st
import plotly.graph_objects as go
from portfolio_dashboard.ui_components import (
    render_kpi_cards, create_waterfall_chart, fmt_value, fmt_pct, PLOTLY_LAYOUT,
    apply_jp_xaxis, hex_to_rgba, order_asset_classes, get_asset_color, ASSET_CLASS_ORDER
)
from portfolio_dashboard.analytics.portfolio_analytics import (
    compute_transaction_summary, export_to_excel
)
from portfolio_dashboard.analytics.time_series import TimeSeriesAnalyzer

def render(monthly_df, income_breakdown, transaction_df, show_evidence):
    st.markdown('<div class="section-header">💰 収益分析</div>', unsafe_allow_html=True)
    ib = income_breakdown
    render_kpi_cards([
        {'label': '累計インカム', 'value': fmt_value(ib['total_income'], precision=2)},
        {'label': '累計キャピタル', 'value': fmt_value(ib['total_capital'], precision=2),
         'positive': ib['total_capital'] >= 0},
        {'label': '累計トータル', 'value': fmt_value(ib['total_income'] + ib['total_capital'], precision=2),
         'positive': (ib['total_income'] + ib['total_capital']) >= 0},
        {'label': 'インカム安定性', 'value': f'{ib["income_stability"]:.0%}',
         'sub': '高いほど安定', 'positive': ib['income_stability'] > 0.5},
    ])

    # ===== 月次リターン（時系列タブから統合）=====
    st.markdown('<div class="section-header">📊 月次リターン</div>', unsafe_allow_html=True)
    ts = TimeSeriesAnalyzer()
    totals = ts.compute_period_totals(monthly_df)
    totals['total_return'] = totals['income'] + totals['capital']
    totals['return_rate'] = totals['total_return'] / totals['book_value'].replace(0, 1)
    ret_pct = totals['return_rate'] * 100

    fig_ret = go.Figure()
    fig_ret.add_trace(go.Bar(x=totals['date'], y=ret_pct, name='月次リターン(%)',
        marker_color=['rgba(16,185,129,0.85)' if v >= 0 else 'rgba(239,68,68,0.85)' for v in ret_pct],
        text=[f'{v:+.2f}%' for v in ret_pct], textposition='outside',
        textfont=dict(size=9, color='#334155'), hovertemplate='%{x}: %{y:+.2f}%<extra></extra>'))
    mas = ts.compute_moving_averages(ret_pct)
    for w, ma in mas.items():
        fig_ret.add_trace(go.Scatter(x=totals['date'], y=ma, mode='lines',
            name=str(w) + 'M 移動平均', line=dict(dash='dot', width=1.5)))
    fig_ret.update_layout(**PLOTLY_LAYOUT, height=380,
        title=dict(text='月次リターンと移動平均', font=dict(size=14, color='#0f172a')))
    fig_ret.update_layout(yaxis=dict(title='%'))
    apply_jp_xaxis(fig_ret, totals['date'])
    st.plotly_chart(fig_ret, use_container_width=True)

    # ===== 月次トータル収益（インカム+キャピタル積み上げ）=====
    st.markdown('<div class="section-header">📊 月次トータル収益（インカム＋キャピタル）</div>', unsafe_allow_html=True)
    bm = ib['by_month']

    fig_total = go.Figure()
    fig_total.add_trace(go.Bar(x=bm['date'], y=bm['income'], name='インカム',
        marker_color='#10b981',
        text=[f'{v:,.1f}' for v in bm['income']], textposition='inside',
        textfont=dict(size=8, color='#ffffff'), hovertemplate='インカム: %{y:,.2f}億円<extra></extra>'))
    # Split capital into positive and negative with separate legend entries
    cap_pos = [v if v >= 0 else 0 for v in bm['capital']]
    cap_neg = [v if v < 0 else 0 for v in bm['capital']]
    fig_total.add_trace(go.Bar(x=bm['date'], y=cap_pos, name='キャピタル（＋）',
        marker_color='#8b5cf6',
        text=[f'{v:,.1f}' if v > 0 else '' for v in cap_pos], textposition='inside',
        textfont=dict(size=8, color='#ffffff'), hovertemplate='キャピタル: %{y:+,.2f}億円<extra></extra>'))
    fig_total.add_trace(go.Bar(x=bm['date'], y=cap_neg, name='キャピタル（−）',
        marker_color='#ef4444',
        text=[f'{v:,.1f}' if v < 0 else '' for v in cap_neg], textposition='inside',
        textfont=dict(size=8, color='#ffffff'), hovertemplate='キャピタル: %{y:+,.2f}億円<extra></extra>'))
    fig_total.add_trace(go.Scatter(x=bm['date'], y=bm['total'], mode='text',
        text=[f'{v:+,.1f}' for v in bm['total']], textposition='top center',
        textfont=dict(size=9, color='#334155'), showlegend=False, hoverinfo='skip'))
    fig_total.update_layout(**PLOTLY_LAYOUT, height=400,
        title=dict(text='月次トータル収益（積み上げ）', font=dict(size=14, color='#0f172a')),
        barmode='relative')
    apply_jp_xaxis(fig_total, bm['date'])
    st.plotly_chart(fig_total, use_container_width=True)

    # 累積トータル収益
    fig_cum = go.Figure()
    fig_cum.add_trace(go.Scatter(x=bm['date'], y=bm['cumulative_income'], name='累積インカム',
        fill='tozeroy', fillcolor=hex_to_rgba('#10b981', 0.15),
        line=dict(color='#10b981', width=2.5), mode='lines+markers', marker=dict(size=4),
        hovertemplate='累積インカム: %{y:,.2f}億円<extra></extra>'))
    fig_cum.add_trace(go.Scatter(x=bm['date'], y=bm['cumulative_capital'], name='累積キャピタル',
        fill='tozeroy', fillcolor=hex_to_rgba('#8b5cf6', 0.15),
        line=dict(color='#8b5cf6', width=2.5), mode='lines+markers', marker=dict(size=4),
        hovertemplate='累積キャピタル: %{y:+,.2f}億円<extra></extra>'))
    fig_cum.add_trace(go.Scatter(x=bm['date'], y=bm['cumulative_total'], name='累積トータル',
        line=dict(color='#0f172a', width=3, dash='dot'), mode='lines+markers', marker=dict(size=5),
        hovertemplate='累積トータル: %{y:+,.2f}億円<extra></extra>'))
    fig_cum.update_layout(**PLOTLY_LAYOUT, height=380,
        title=dict(text='累積収益推移', font=dict(size=14, color='#0f172a')))
    fig_cum.add_hline(y=0, line_dash='dash', line_color='#cbd5e1', line_width=1)
    apply_jp_xaxis(fig_cum, bm['date'])
    st.plotly_chart(fig_cum, use_container_width=True)

    # ===== インカム・キャピタル個別詳細（横幅いっぱい、上下に並べる）=====
    st.markdown('<div class="section-header">📈 インカム・キャピタル内訳</div>', unsafe_allow_html=True)

    fig_inc = go.Figure()
    fig_inc.add_trace(go.Bar(x=bm['date'], y=bm['income'], name='インカム', marker_color='#10b981',
        text=[f'{v:,.1f}' for v in bm['income']], textposition='outside',
        textfont=dict(size=8, color='#334155'), hovertemplate='インカム: %{y:,.2f}億円<extra></extra>'))
    fig_inc.add_trace(go.Scatter(x=bm['date'], y=bm['cumulative_income'], mode='lines+markers',
        name='累積', yaxis='y2', line=dict(color='#3b82f6', width=2, dash='dot'), marker=dict(size=4),
        hovertemplate='累積: %{y:,.2f}億円<extra></extra>'))
    fig_inc.update_layout(**PLOTLY_LAYOUT, height=320,
        title=dict(text='月次インカム収益', font=dict(size=14, color='#0f172a')))
    fig_inc.update_layout(yaxis2=dict(overlaying='y', side='right', showgrid=False,
        title=dict(text='累積', font=dict(color='#64748b', size=10))))
    apply_jp_xaxis(fig_inc, bm['date'])
    st.plotly_chart(fig_inc, use_container_width=True)

    fig_cap = go.Figure()
    fig_cap.add_trace(go.Bar(x=bm['date'], y=bm['capital'], name='キャピタル',
        marker_color=['#10b981' if v >= 0 else '#ef4444' for v in bm['capital']],
        text=[f'{v:+,.1f}' for v in bm['capital']], textposition='outside',
        textfont=dict(size=8, color='#334155'), hovertemplate='キャピタル: %{y:+,.2f}億円<extra></extra>'))
    fig_cap.add_trace(go.Scatter(x=bm['date'], y=bm['cumulative_capital'], mode='lines+markers',
        name='累積', yaxis='y2', line=dict(color='#8b5cf6', width=2, dash='dot'), marker=dict(size=4),
        hovertemplate='累積: %{y:+,.2f}億円<extra></extra>'))
    fig_cap.update_layout(**PLOTLY_LAYOUT, height=320,
        title=dict(text='月次キャピタル損益', font=dict(size=14, color='#0f172a')))
    fig_cap.update_layout(yaxis2=dict(overlaying='y', side='right', showgrid=False,
        title=dict(text='累積', font=dict(color='#64748b', size=10))))
    apply_jp_xaxis(fig_cap, bm['date'])
    st.plotly_chart(fig_cap, use_container_width=True)

    # ===== 資産クラス別 =====
    ba = ib['by_asset']
    st.markdown('<div class="section-header">🏦 資産クラス別収益</div>', unsafe_allow_html=True)

    # Waterfall (ordered)
    ba_ordered = ba.copy()
    ba_ordered['_order'] = ba_ordered['asset_class'].map({c: i for i, c in enumerate(order_asset_classes(ba_ordered['asset_class'].unique().tolist()))})
    ba_ordered = ba_ordered.sort_values('_order').drop(columns=['_order'], errors='ignore')
    fig_wf = create_waterfall_chart(ba_ordered['asset_class'].tolist() + ['トータル'],
        ba_ordered['total'].tolist() + [ba_ordered['total'].sum()], title='資産クラス別収益内訳')
    st.plotly_chart(fig_wf, use_container_width=True)

    fig_ac = go.Figure()
    fig_ac.add_trace(go.Bar(x=ba_ordered['asset_class'], y=ba_ordered['income'], name='インカム',
        marker_color='#10b981', text=[f'{v:,.1f}' for v in ba_ordered['income']],
        textposition='auto', textfont=dict(size=9, color='#334155')))
    fig_ac.add_trace(go.Bar(x=ba_ordered['asset_class'], y=ba_ordered['capital'], name='キャピタル',
        marker_color=['#8b5cf6' if v >= 0 else '#ef4444' for v in ba_ordered['capital']],
        text=[f'{v:+,.1f}' for v in ba_ordered['capital']],
        textposition='auto', textfont=dict(size=9, color='#334155')))
    fig_ac.update_layout(**PLOTLY_LAYOUT, height=380,
        title=dict(text='資産クラス別インカム・キャピタル', font=dict(size=14, color='#0f172a')), barmode='group')
    st.plotly_chart(fig_ac, use_container_width=True)

    # トランザクション
    if transaction_df is not None and len(transaction_df) > 0:
        st.markdown('<div class="section-header">📝 取引サマリー</div>', unsafe_allow_html=True)
        tx = compute_transaction_summary(transaction_df)
        tc1, tc2 = st.columns(2)
        with tc1:
            st.metric("取引件数", tx['n_transactions'])
            if 'type_counts' in tx:
                for t, c in tx['type_counts'].items():
                    st.markdown(f"- {t}: {c}件")
        with tc2:
            if 'total_cost' in tx: st.metric("総コスト", fmt_value(tx['total_cost']))
            if 'avg_cost_ratio' in tx: st.metric("平均コスト率", f"{tx['avg_cost_ratio']*100:.3f}%")

    st.markdown("---")
    dl = export_to_excel({'資産クラス別': ba, '月次': bm})
    st.download_button("📥 収益データ (Excel)", data=dl, file_name="revenue.xlsx",
                       mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")