﻿"""tab_genai.py - GenAI連携タブ"""
import streamlit as st
import pandas as pd
from portfolio_dashboard.ui_components import fmt_value, fmt_pct

def render(monthly_df, data, summary, composition, insights, security_df):
    st.markdown('<div class="section-header">🔗 GenAI連携プロンプト生成</div>', unsafe_allow_html=True)
    st.markdown("分析データを社内GenAIに投入するための最適化プロンプトを生成します。")

    templates = {
        'ポートフォリオレビュー': '以下のポートフォリオデータを分析し、リスク・リターンの観点から総合レビューを提供してください。',
        '顧客提案ドラフト': '以下のデータを基に顧客向け提案レターのドラフトを作成してください。',
        'リスクレポート': '以下のデータからリスクレポートを作成してください。',
        '運用戦略レビュー': '以下のパフォーマンスデータから運用戦略の振り返りと今後の方針案を提示してください。',
    }

    sel = st.selectbox("テンプレート", list(templates.keys()))
    ci = st.text_area("カスタム指示（任意）", height=80, placeholder="例: 金利上昇50bpのストレス考慮")
    inc_ins = st.checkbox("AIインサイト含める", value=True)
    mr = st.slider("データ行数上限", 10, 50, 25)

    if st.button("📝 プロンプト生成", use_container_width=True):
        p = [f"# ポートフォリオ分析コンテキスト",
             f"期間: {data.date_range[0].strftime('%Y/%m')} 〜 {data.date_range[1].strftime('%Y/%m')}",
             f"レベル: {data.level.name}", "",
             f"## サマリー",
             f"総時価: {fmt_value(summary['total_market_value'])}",
             f"総簿価: {fmt_value(summary['total_book_value'])}",
             f"評価損益: {fmt_value(summary['unrealized_gl'])} ({fmt_pct(summary['gl_ratio'])})",
             f"累計インカム: {fmt_value(summary['total_income'])}",
             f"年率リターン: {fmt_pct(summary['annualized_return_rate'])}", "",
             f"## 資産構成"]
        for _, r in composition.iterrows():
            p.append(f"- {r['asset_class']}: 時価{r['market_value']:,.0f} ({r['composition_pct']:.1f}%)")

        if inc_ins and insights:
            p.append(f"\n## AIインサイト")
            for i in insights[:10]:
                p.append(f"- [{i.get('severity','')}] {i['title']}: {i['description']}")

        if data.has_security_data and security_df is not None:
            p.append(f"\n## 銘柄データ（上位{mr}件）")
            top = security_df.nlargest(mr, 'market_value') if 'market_value' in security_df.columns else security_df.head(mr)
            for _, r in top.iterrows():
                pts = []
                if 'security_name' in top.columns: pts.append(str(r['security_name']))
                if 'market_value' in top.columns: pts.append(f"時価:{r['market_value']:,.0f}")
                if 'unrealized_gl' in top.columns: pts.append(f"損益:{r['unrealized_gl']:+,.0f}")
                p.append(f"- {' | '.join(pts)}")

        ctx = '\n'.join(p)
        instr = ci if ci else templates[sel]
        prompt = f"{instr}\n\n---\n\n{ctx}"

        st.markdown(f"**生成プロンプト** ({len(prompt):,}文字)")
        st.text_area("コピー用", value=prompt, height=400, key="gp")
        st.download_button("📥 テキスト保存", data=prompt.encode('utf-8'),
                           file_name="genai_prompt.txt", mime="text/plain")
