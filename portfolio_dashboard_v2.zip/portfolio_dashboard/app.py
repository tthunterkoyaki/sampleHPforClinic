# Pre-load torch before Streamlit's file watcher scans modules
# This avoids WinError 127/206 when Streamlit subprocess loads torch DLLs
import sys as _sys, ctypes as _ctypes
_torch_lib = _sys.executable.replace('python.exe','') + 'Lib\\site-packages\\torch\\lib'
if __import__('os').path.isdir(_torch_lib):
    try:
        __import__('os').add_dll_directory(_torch_lib)
    except OSError:
        pass
    if _torch_lib not in __import__('os').environ.get('PATH',''):
        __import__('os').environ['PATH'] = _torch_lib + ';' + __import__('os').environ.get('PATH','')
try:
    import torch  # noqa: pre-load to avoid DLL issues in Streamlit subprocess
except Exception:
    pass
import os
# app.py - Portfolio Dashboard Main
import streamlit as st
import pandas as pd
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from portfolio_dashboard.data_loader import load_portfolio_excel
from portfolio_dashboard.sample_generator import generate_sample_excel
from portfolio_dashboard.analytics.portfolio_analytics import (
    compute_portfolio_summary, compute_asset_composition,
    compute_income_capital_breakdown, export_to_excel
)
from portfolio_dashboard.analytics.time_series import TimeSeriesAnalyzer
from portfolio_dashboard.analytics.risk_analytics import RiskAnalyzer
from portfolio_dashboard.ai.portfolio_insight import PortfolioInsightGenerator
from portfolio_dashboard.ai.trend_detector import TrendDetector
from portfolio_dashboard.ui_components import register_asset_classes, inject_css, render_level_badge

st.set_page_config(page_title="Portfolio Dashboard", page_icon="\U0001f4ca", layout="wide", initial_sidebar_state="expanded")
inject_css()

@st.cache_resource
def load_bert_models():
    try:
        # Fix Windows long path issue with torch DLL loading
        import sys, ctypes
        torch_lib = os.path.join(os.path.dirname(sys.executable),
                                  'Lib', 'site-packages', 'torch', 'lib')
        if os.path.exists(torch_lib):
            buf = ctypes.create_unicode_buffer(512)
            ctypes.windll.kernel32.GetShortPathNameW(torch_lib, buf, 512)
            short = buf.value
            if short:
                os.environ['PATH'] = short + os.pathsep + os.environ.get('PATH', '')
                # Monkey-patch add_dll_directory to handle long paths
                _orig_add_dll = os.add_dll_directory
                def _safe_add_dll(path):
                    try:
                        return _orig_add_dll(path)
                    except (FileNotFoundError, OSError):
                        # Try with short path
                        b = ctypes.create_unicode_buffer(512)
                        ctypes.windll.kernel32.GetShortPathNameW(str(path), b, 512)
                        if b.value:
                            return _orig_add_dll(b.value)
                        raise
                os.add_dll_directory = _safe_add_dll
        from bert_assistant.models import ModelManager
        return ModelManager(), True
    except Exception:
        return None, False

bert_mm, bert_available = load_bert_models()

with st.sidebar:
    st.markdown("## \U0001f4ca Portfolio Dashboard")
    st.markdown("---")
    st.markdown("### \U0001f4c1 データ読み込み")
    uploaded = st.file_uploader("Excelファイルをアップロード", type=["xlsx","xls"], key="fu")
    st.markdown("**サンプルデータ:**")
    c1, c2, c3 = st.columns(3)
    with c1: sample_l1 = st.button("L1", help="基本", use_container_width=True)
    with c2: sample_l2 = st.button("L2", help="詳細", use_container_width=True)
    with c3: sample_l3 = st.button("L3", help="フルセット", use_container_width=True)
    st.download_button("\U0001f4e5 サンプル(L3)", data=generate_sample_excel(3), file_name="sample_L3.xlsx",
                       mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")

@st.cache_data
def load_data(fb):
    return load_portfolio_excel(fb)

data = None
if sample_l1: st.session_state['sl'] = 1
if sample_l2: st.session_state['sl'] = 2
if sample_l3: st.session_state['sl'] = 3

if uploaded:
    data, err = load_data(uploaded.read())
    if err: st.error(f"\u274c {err}")
elif 'sl' in st.session_state:
    data, err = load_data(generate_sample_excel(st.session_state['sl']))

if data is None:
    st.markdown('<div style="text-align:center;padding:4rem 2rem;">'
    '<h1 style="font-size:2.5rem;font-weight:800;background:linear-gradient(135deg,#3b82f6,#8b5cf6);'
    '-webkit-background-clip:text;-webkit-text-fill-color:transparent;">Portfolio Dashboard</h1>'
    '<p style="color:#64748b;font-size:1.1rem;margin-top:1rem;">保有有価証券のダッシュボード型分析ツール</p>'
    '<p style="color:#94a3b8;font-size:0.9rem;margin-top:2rem;">左のサイドバーからExcelをアップロードするか、サンプルデータボタンでご確認ください。</p>'
    '</div>', unsafe_allow_html=True)
    st.stop()

# Date filtering
monthly_df = data.monthly_data
monthly_df['date'] = pd.to_datetime(monthly_df['date'])
all_dates = sorted(monthly_df['date'].unique())

with st.sidebar:
    st.markdown("---")
    st.markdown("### \U0001f4c5 期間選択")
    all_dates_ts = [pd.Timestamp(d) for d in all_dates]
    april_dates = [d for d in all_dates_ts if d.month == 4]
    if april_dates:
        latest = all_dates_ts[-1]
        same_fy = [d for d in april_dates if (d.year == latest.year and latest.month >= 4) or (d.year == latest.year - 1 and latest.month < 4)]
        default_start = same_fy[-1] if same_fy else (april_dates[-1] if april_dates else all_dates_ts[0])
    else:
        default_start = all_dates_ts[0]
    start_idx = all_dates_ts.index(default_start) if default_start in all_dates_ts else 0
    start_sel = st.selectbox("開始", options=all_dates_ts, index=start_idx,
        format_func=lambda d: f"{d.year}/{d.month}月", key="date_start")
    end_options = [d for d in all_dates_ts if d >= start_sel]
    end_sel = st.selectbox("終了", options=end_options, index=len(end_options)-1,
        format_func=lambda d: f"{d.year}/{d.month}月", key="date_end")
    st.markdown("---")
    show_evidence = st.checkbox("\U0001f50d AI根拠を表示", value=False, help="インサイトカードにAIの判定根拠を表示します")
    if bert_available:
        st.markdown('<span class="level-badge level-2"><span class="status-dot"></span> BERT Active</span>', unsafe_allow_html=True)
        with st.expander("🧠 BERTモデル状態", expanded=False):
            status = bert_mm.get_status()
            for name, s in status.items():
                icon = "✅" if "loaded" in s else "⏳" if s == "not loaded" else "❌"
                st.markdown(f"{icon} {name}: {s}")
            if hasattr(bert_mm, 'get_error_details'):
                errors = bert_mm.get_error_details()
                if errors:
                    st.markdown("**エラー:**")
                    for key, err in errors.items():
                        st.code(err, language="text")
            if st.button("🔄 全モデル再ロード", key="reload_all_models"):
                bert_mm._models.clear()
                bert_mm._status.clear()
                if hasattr(bert_mm, '_errors'):
                    bert_mm._errors.clear()
                st.rerun()

# Global download will be added after data is computed (see below)

# Apply date filter
# Store unfiltered data for period-start reference
full_monthly_df = monthly_df.copy()
monthly_df = monthly_df[(monthly_df['date'] >= start_sel) & (monthly_df['date'] <= end_sel)].copy()
security_df = data.security_data
transaction_df = data.transaction_data

summary = compute_portfolio_summary(monthly_df)
composition = compute_asset_composition(monthly_df)
if hasattr(data, "asset_classes"): register_asset_classes(data.asset_classes)
income_breakdown = compute_income_capital_breakdown(monthly_df)
ts = TimeSeriesAnalyzer()
ra = RiskAnalyzer()
ig = PortfolioInsightGenerator(model_manager=bert_mm if bert_available else None)
td = TrendDetector()
insights = ig.generate_insights(monthly_df, security_df, transaction_df)

# Global download button in sidebar
with st.sidebar:
    st.markdown("---")
    if monthly_df is not None and len(monthly_df) > 0:
        from portfolio_dashboard.analytics.portfolio_analytics import export_to_excel as _export
        _dl_data = {'集計': ts.compute_period_totals(monthly_df)}
        if security_df is not None and len(security_df) > 0:
            _dl_data['銘柄データ'] = security_df
        if transaction_df is not None and len(transaction_df) > 0:
            _dl_data['取引データ'] = transaction_df
        st.download_button("📥 全データダウンロード", data=_export(_dl_data),
                           file_name="portfolio_all.xlsx",
                           mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")

hc1, hc2 = st.columns([4, 1])
with hc1:
    st.markdown('<h2 style="margin:0;font-weight:800;color:#1e293b;">\U0001f4ca ポートフォリオ ダッシュボード</h2>', unsafe_allow_html=True)
    s_str = f"{start_sel.year}/{start_sel.month}月"
    e_str = f"{end_sel.year}/{end_sel.month}月"
    n_p = len(monthly_df['date'].unique())
    st.markdown(f'<span style="color:#94a3b8;">期間: {s_str} → {e_str} | {n_p}ヶ月</span>', unsafe_allow_html=True)
with hc2:
    render_level_badge(data.level.value)

tab_names = ["\U0001f4ca 概要", "\U0001f4c8 分析"]
if data.has_security_data:
    tab_names.append("\U0001f4cb 銘柄")
    tab_names.append("\u26a1 リスク")
tab_names.append("\U0001f916 AI分析")
tabs = st.tabs(tab_names)
ti = 0

from portfolio_dashboard.tab_overview import render as render_overview
from portfolio_dashboard.tab_analysis import render as render_analysis
from portfolio_dashboard.tab_securities import render as render_securities
from portfolio_dashboard.tab_risk import render as render_risk
from portfolio_dashboard.tab_ai_insights import render as render_ai

with tabs[ti]:
    render_overview(monthly_df, composition, summary, ts, insights, show_evidence, full_monthly_df=full_monthly_df, start_sel=start_sel)
ti += 1
with tabs[ti]:
    render_analysis(monthly_df, data, income_breakdown, transaction_df, ts, show_evidence)
ti += 1
if data.has_security_data:
    with tabs[ti]:
        render_securities(security_df, ra, show_evidence)
    ti += 1
    with tabs[ti]:
        render_risk(security_df, ra, show_evidence)
    ti += 1
with tabs[ti]:
    render_ai(monthly_df, security_df, insights, ig, ts, td, bert_mm, bert_available, data, show_evidence)
