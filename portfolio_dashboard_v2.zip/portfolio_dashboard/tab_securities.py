"""tab_securities.py - 銘柄分析タブ（xaxisバグ修正、データラベル改善）"""
import streamlit as st
import plotly.graph_objects as go
import pandas as pd
from portfolio_dashboard.ui_components import (
    render_kpi_cards, fmt_hyakuman, fmt_pct, PLOTLY_LAYOUT, hex_to_rgba,
    order_asset_classes, get_asset_color
)
from portfolio_dashboard.analytics.portfolio_analytics import compute_security_summary, export_to_excel

def render(security_df, ra, show_evidence):
    st.markdown('<div class="section-header">📋 銘柄一覧</div>', unsafe_allow_html=True)
    ss = compute_security_summary(security_df)
    render_kpi_cards([
        {'label': '銘柄数', 'value': str(ss['n_securities'])},
        {'label': '加重平均利回り(簿価)', 'value': fmt_pct(ss.get('weighted_book_yield', 0))},
        {'label': '加重平均残存年数', 'value': str(round(ss.get('weighted_avg_remaining', 0), 1)) + '年'},
        {'label': '評価損益', 'value': fmt_hyakuman(ss.get('total_unrealized_gl', 0), 2),
         'sub': '益:' + str(ss.get('n_gain',0)) + ' / 損:' + str(ss.get('n_loss',0)),
         'positive': ss.get('total_unrealized_gl', 0) >= 0},
    ])

    c1, c2 = st.columns(2)
    with c1:
        dur = ra.analyze_duration(security_df)
        if dur.get('available'):
            st.markdown('<div class="section-header">📊 残存年数分布</div>', unsafe_allow_html=True)
            wa = round(dur['weighted_avg'], 1)
            bk = dur['buckets']
            fig = go.Figure(go.Bar(x=bk['bucket'], y=bk['market_value'],
                marker_color='#3b82f6',
                text=bk['market_value'].apply(lambda x: f'{x:,.0f}'),
                textposition='outside', cliponaxis=False,
                textfont=dict(color='#334155', size=9)))
            layout = {k:v for k,v in PLOTLY_LAYOUT.items() if k not in ('xaxis','yaxis')}
            fig.update_layout(**layout, height=350,
                title=dict(text=f'残存年数別（加重平均: {wa}年）', font=dict(size=14, color='#0f172a')),
                xaxis=dict(gridcolor='#e2e8f0'), yaxis=dict(range=[0, bk['market_value'].max() * 1.3], gridcolor='#e2e8f0'))
            st.plotly_chart(fig, use_container_width=True)

    with c2:
        # Maturity distribution by asset class
        dur2 = ra.analyze_duration(security_df)
        if dur2.get('available') and 'avg_remaining' in security_df.columns:
            _ac = 'asset_class' if 'asset_class' in security_df.columns else 'category'
            st.markdown('<div class="section-header">\U0001f4ca 資産クラス別残存年数</div>', unsafe_allow_html=True)
            fig = go.Figure()
            for ac in order_asset_classes(security_df[_ac].unique().tolist()):
                acd = security_df[security_df[_ac] == ac]
                vals = acd['avg_remaining'].dropna()
                if len(vals) > 0:
                    fig.add_trace(go.Box(y=vals, name=ac, marker_color=get_asset_color(ac),
                        boxmean=True))
            layout2 = {k:v for k,v in PLOTLY_LAYOUT.items() if k not in ('xaxis','yaxis','margin')}
            fig.update_layout(**layout2, height=350,
                yaxis=dict(title='残存年数(年)', gridcolor='#e2e8f0'),
                title=dict(text='資産クラス別残存年数分布', font=dict(size=14, color='#0f172a')),
                margin=dict(l=50, r=20, t=60, b=40),
                showlegend=False)
            st.plotly_chart(fig, use_container_width=True)

    conc = ra.analyze_concentration(security_df)
    if conc.get('available'):
        st.markdown('<div class="section-header">🎯 集中度分析</div>', unsafe_allow_html=True)
        ct = st.tabs(["発行体別", "業種別", "通貨別"])
        for i, key in enumerate(['issuer', 'industry', 'currency']):
            with ct[i]:
                if key in conc and 'distribution' in conc[key]:
                    d = conc[key]['distribution'].head(10)
                    lc = d.columns[0]
                    d = d.sort_values('時価', ascending=True)
                    _ac = 'asset_class' if 'asset_class' in security_df.columns else 'category'
                    # Stacked horizontal bar by asset class
                    if _ac in security_df.columns and key in ('issuer','industry','currency'):
                        _grp_col = {'issuer':'issuer_name','industry':'industry','currency':'issue_currency'}.get(key)
                        if _grp_col and _grp_col in security_df.columns:
                            top_names = d[lc].tolist()
                            sub = security_df[security_df[_grp_col].isin(top_names)]
                            agg = sub.groupby([_grp_col, _ac])['market_value'].sum().reset_index()
                            fig = go.Figure()
                            for ac in order_asset_classes(agg[_ac].unique().tolist()):
                                acd = agg[agg[_ac] == ac]
                                # Sort by total
                                order_map = {n:j for j,n in enumerate(top_names[::-1])}
                                acd = acd.copy()
                                acd['_o'] = acd[_grp_col].map(order_map).fillna(999)
                                acd = acd.sort_values('_o')
                                fig.add_trace(go.Bar(y=acd[_grp_col], x=acd['market_value'],
                                    name=ac, marker_color=get_asset_color(ac), orientation='h'))
                            layout3 = {k:v for k,v in PLOTLY_LAYOUT.items() if k not in ('xaxis','yaxis','margin')}
                            # Sort: largest at top
                            total_by_name = sub.groupby(_grp_col)['market_value'].sum().sort_values(ascending=False)
                            fig.update_layout(**layout3, height=380, barmode='stack',
                                title=dict(text=f'{lc}別（上位10）', font=dict(size=14, color='#0f172a')),
                                xaxis=dict(gridcolor='#e2e8f0'),
                                yaxis=dict(gridcolor='#e2e8f0', categoryorder='array', categoryarray=total_by_name.index.tolist()[::-1]),
                                margin=dict(l=120, r=20, t=50, b=40),
                                legend=dict(orientation='h', yanchor='top', y=-0.15, xanchor='center', x=0.5, font=dict(size=8)))
                            st.plotly_chart(fig, use_container_width=True)
                        else:
                            fig = go.Figure(go.Bar(y=d[lc], x=d['時価'], marker_color='#3b82f6', orientation='h'))
                            layout3 = {k:v for k,v in PLOTLY_LAYOUT.items() if k not in ('xaxis','yaxis')}
                            fig.update_layout(**layout3, height=350,
                                title=dict(text=f'{lc}別（上位10）', font=dict(size=14, color='#0f172a')),
                                xaxis=dict(gridcolor='#e2e8f0'), yaxis=dict(gridcolor='#e2e8f0'))
                            st.plotly_chart(fig, use_container_width=True)
                    else:
                        fig = go.Figure(go.Bar(y=d[lc], x=d['時価'], marker_color='#3b82f6', orientation='h'))
                        layout3 = {k:v for k,v in PLOTLY_LAYOUT.items() if k not in ('xaxis','yaxis')}
                        fig.update_layout(**layout3, height=350,
                            title=dict(text=f'{lc}別（上位10）', font=dict(size=14, color='#0f172a')),
                            xaxis=dict(gridcolor='#e2e8f0'), yaxis=dict(gridcolor='#e2e8f0'))
                        st.plotly_chart(fig, use_container_width=True)
                    st.markdown('HHI: **' + str(round(conc[key]['hhi'], 3)) + '** (' + conc[key]['hhi_level'] + ')')

    st.markdown('<div class="section-header">📋 銘柄詳細</div>', unsafe_allow_html=True)
    dc = ['security_name','category','issuer_name','industry','market_value','book_value','unrealized_gl','book_yield','avg_remaining','issue_currency']
    ac = [c for c in dc if c in security_df.columns]
    rn = {'security_name':'銘柄名','category':'分類','issuer_name':'発行体','industry':'業種',
          'market_value':'時価','book_value':'簿価','unrealized_gl':'評価損益',
          'book_yield':'簿価利回り','avg_remaining':'残存年数','issue_currency':'通貨'}
    st.dataframe(security_df[ac].rename(columns=rn), use_container_width=True, hide_index=True, height=400)
    st.download_button("📥 銘柄データ (Excel)", data=export_to_excel({'銘柄データ': security_df}),
                       file_name="securities.xlsx", mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")