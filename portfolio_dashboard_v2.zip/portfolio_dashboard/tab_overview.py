"""tab_overview.py - 概要タブ（最新月＋期初比較＋簿価統合）"""
import streamlit as st
import plotly.graph_objects as go
import pandas as pd
from portfolio_dashboard.ui_components import (
    render_kpi_cards, render_insight_cards, create_pie_chart,
    fmt_oku, fmt_pct, PLOTLY_LAYOUT, hex_to_rgba,
    apply_jp_xaxis, order_asset_classes, COLORS
)

def render(monthly_df, composition, summary, ts, insights, show_evidence, full_monthly_df=None, start_sel=None):
    # Compute latest date and period start for KPI labels
    import pandas as _pd
    _all_dates = sorted(monthly_df['date'].unique())
    _latest_dt = _pd.Timestamp(_all_dates[-1])
    _start_dt = _pd.Timestamp(_all_dates[0])
    _latest_label = f"{_latest_dt.year}年{_latest_dt.month}月"
    # Period start values for comparison
    _start_data = monthly_df[monthly_df['date'] == _all_dates[0]].agg({'market_value': 'sum', 'unrealized_gl': 'sum'})
    _mv_vs_start = summary['total_market_value'] - _start_data['market_value']
    _gl_vs_start = summary['unrealized_gl'] - _start_data['unrealized_gl']
    _start_label = f"{_start_dt.year}年{_start_dt.month}月"

    render_kpi_cards([
        {'label': f'時価 ({_latest_label})', 'value': fmt_oku(summary['total_market_value']),
         'sub': f'期初比: {_mv_vs_start:+,.1f}億円'},
        {'label': f'評価損益 ({_latest_label})', 'value': fmt_oku(summary['unrealized_gl'], precision=2, sign=True),
         'sub': f'期初比: {_gl_vs_start:+,.2f}億円', 'positive': summary['unrealized_gl'] >= 0},
        {'label': '累計インカム', 'value': fmt_oku(summary['total_income'], precision=2, sign=True),
         'sub': str(summary['n_months']) + 'ヶ月累計'},
        {'label': '年率リターン', 'value': fmt_pct(summary['annualized_return_rate']),
         'sub': 'インカム+キャピタル', 'positive': summary['annualized_return_rate'] >= 0},
    ])

    # === Latest month summary (includes book value, replaces old summary table) ===
    st.markdown('<div class="section-header">📅 最新月の実績</div>', unsafe_allow_html=True)
    totals = ts.compute_period_totals(monthly_df)
    if len(totals) >= 2:
        latest = totals.iloc[-1]
        prev = totals.iloc[-2]
        dt = latest['date']
        dt_str = f"{pd.Timestamp(dt).year}年{pd.Timestamp(dt).month}月"
        mv_chg = latest['market_value'] - prev['market_value']
        gl_chg = latest['unrealized_gl'] - prev['unrealized_gl']
        inc = latest['income']
        cap = latest['capital']
        total_ret = inc + cap
        ret_rate = total_ret / prev['book_value'] * 100 if prev['book_value'] != 0 else 0

        mc1, mc2, mc3, mc4, mc5 = st.columns(5)
        def _mc(col, label, value, change=None, positive=None):
            with col:
                cc = ''
                if positive is not None:
                    cc = 'kpi-positive' if positive else 'kpi-negative'
                ch = ''
                if change is not None:
                    cl = 'kpi-positive' if change >= 0 else 'kpi-negative'
                    cs = f'{change:+,.2f}億円' if abs(change) < 100 else f'{change:+,.1f}億円'
                    ch = f'<div class="mc-change {cl}">前月比: {cs}</div>'
                st.markdown(f'<div class="month-card"><div class="mc-label">{label} ({dt_str})</div><div class="mc-value {cc}">{value}</div>{ch}</div>', unsafe_allow_html=True)
        _mc(mc1, '時価', fmt_oku(latest['market_value']), mv_chg)
        _mc(mc2, '評価損益', fmt_oku(latest['unrealized_gl'], 2, sign=True), gl_chg, latest['unrealized_gl'] >= 0)
        _mc(mc3, 'インカム', fmt_oku(inc, 2, sign=True))
        _mc(mc4, 'キャピタル', fmt_oku(cap, 2, sign=True), positive=cap >= 0)
        _mc(mc5, '月次リターン', f'{ret_rate:+.2f}%', positive=ret_rate >= 0)

        # Asset class detail for latest month (with book value)
        latest_month = monthly_df[monthly_df['date'] == monthly_df['date'].max()].copy()
        dates_unique = sorted(monthly_df['date'].unique())
        prev_date = dates_unique[-2] if len(dates_unique) >= 2 else None
        prev_month = monthly_df[monthly_df['date'] == prev_date].copy() if prev_date else None
        if prev_month is not None:
            merged = latest_month.merge(
                prev_month[['asset_class','market_value','unrealized_gl']],
                on='asset_class', suffixes=('','_prev'), how='left')
            merged['mv_change'] = merged['market_value'] - merged['market_value_prev'].fillna(0)
            ao = {c: i for i, c in enumerate(order_asset_classes(merged['asset_class'].tolist()))}
            merged['_o'] = merged['asset_class'].map(ao)
            merged = merged.sort_values('_o')
            display_df = merged[['asset_class','book_value','market_value','mv_change','unrealized_gl','income','capital']].copy()
            display_df.columns = ['資産クラス','簿価(億円)','時価(億円)','時価変動','評価損益(億円)','インカム(億円)','キャピタル(億円)']
            st.dataframe(display_df.style.format({
                '簿価(億円)':'{:,.1f}','時価(億円)':'{:,.1f}','時価変動':'{:+,.2f}',
                '評価損益(億円)':'{:+,.2f}','インカム(億円)':'{:,.2f}','キャピタル(億円)':'{:+,.2f}'}),
                use_container_width=True, hide_index=True)

    # === Dual pie charts: full width ===
    latest_date = monthly_df['date'].max()
    latest_ts = _pd.Timestamp(latest_date)
    # Period start = month BEFORE the first selected date (e.g., March for April start)
    all_dates = sorted(monthly_df['date'].unique())
    first_selected = _pd.Timestamp(all_dates[0])
    fy_start_data = None
    if full_monthly_df is not None:
        all_full_dates = sorted(full_monthly_df['date'].unique())
        first_idx = None
        for idx, d in enumerate(all_full_dates):
            if _pd.Timestamp(d) == first_selected:
                first_idx = idx
                break
        if first_idx is not None and first_idx > 0:
            fy_start_data = all_full_dates[first_idx - 1]
    if fy_start_data is None:
        fy_start_data = all_dates[0]

    col_pie1, col_pie2 = st.columns(2)
    with col_pie1:
        lt_str = f"{latest_ts.year}年{latest_ts.month}月"
        st.markdown(f'<div class="section-header">🔵 資産構成（{lt_str}）</div>', unsafe_allow_html=True)
        comp_now = composition.copy()
        fig_now = create_pie_chart(comp_now['asset_class'].tolist(), comp_now['market_value'].tolist(),
                                    title=f'直近構成比（{lt_str}）')
        st.plotly_chart(fig_now, use_container_width=True)

    with col_pie2:
        fy_ts = pd.Timestamp(fy_start_data)
        fy_str = f"{fy_ts.year}年{fy_ts.month}月"
        st.markdown(f'<div class="section-header">🔵 資産構成（{fy_str} 期末）</div>', unsafe_allow_html=True)
        _source_df = full_monthly_df if full_monthly_df is not None else monthly_df
        fy_data = _source_df[_source_df['date'] == fy_start_data]
        if len(fy_data) > 0:
            fy_comp = fy_data.groupby('asset_class').agg({'market_value': 'sum'}).reset_index()
            fig_fy = create_pie_chart(fy_comp['asset_class'].tolist(), fy_comp['market_value'].tolist(),
                                       title=f'期末構成比（{fy_str}）')
            st.plotly_chart(fig_fy, use_container_width=True)

    # === Full width time series ===
    st.markdown('<div class="section-header">📈 時価・簿価推移</div>', unsafe_allow_html=True)
    fig_mv = go.Figure()
    fig_mv.add_trace(go.Scatter(x=totals['date'], y=totals['book_value'], mode='lines+markers',
        name='簿価', line=dict(color='#94a3b8', width=2, dash='dash'), marker=dict(size=4),
        hovertemplate='簿価: %{y:,.1f}億円<extra></extra>'))
    fig_mv.add_trace(go.Scatter(x=totals['date'], y=totals['market_value'], mode='lines+markers',
        name='時価', line=dict(color='#3b82f6', width=3), marker=dict(size=5),
        hovertemplate='時価: %{y:,.1f}億円<extra></extra>'))
    fig_mv.add_trace(go.Bar(x=totals['date'], y=totals['unrealized_gl'], name='評価損益',
        marker_color=[hex_to_rgba('#10b981', 0.4) if v >= 0 else hex_to_rgba('#ef4444', 0.4)
                      for v in totals['unrealized_gl']],
        yaxis='y2', hovertemplate='評価損益: %{y:,.2f}億円<extra></extra>'))
    fig_mv.update_layout(**PLOTLY_LAYOUT, height=380,
        title=dict(text='時価・簿価推移', font=dict(size=14, color='#0f172a')),
        yaxis2=dict(overlaying='y', side='right', showgrid=False,
            title=dict(text='評価損益', font=dict(color='#64748b', size=10))),
        barmode='overlay')
    apply_jp_xaxis(fig_mv, totals['date'])
    st.plotly_chart(fig_mv, use_container_width=True)

    if insights:
        st.markdown('<div class="section-header">💡 トップインサイト</div>', unsafe_allow_html=True)
        render_insight_cards(insights[:3], show_evidence=show_evidence)