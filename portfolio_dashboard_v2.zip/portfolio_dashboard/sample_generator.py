"""
sample_generator.py - サンプルデータ生成

テスト・デモ用のリアルな金融機関ポートフォリオサンプルデータを生成する。
Level 1-3 の各粒度に対応。

生成データの前提:
  - 地域金融機関（信用金庫・地方銀行）の有価証券ポートフォリオを想定
  - 総資産規模: 約1,000-2,000億円程度
  - 国内債券中心、外国債券・株式は補完的
  - 22ヶ月分の時系列（2024年3月～2025年12月、収益計測は4月～）
"""
import pandas as pd
import numpy as np
import io
from typing import Optional


def generate_sample_excel(level: int = 3, seed: int = 42) -> bytes:
    """
    サンプルExcelデータを生成する。

    Args:
        level: 生成するデータレベル（1, 2, or 3）
            1: 月次×資産クラスのみ
            2: 月次 + 銘柄スナップショット
            3: 月次 + 銘柄 + 取引明細
        seed: 乱数シード（再現性のため）

    Returns:
        Excelファイルのバイトデータ
    """
    np.random.seed(seed)

    monthly_df = _generate_monthly_data()
    output = io.BytesIO()

    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        monthly_df.to_excel(writer, sheet_name='月次データ', index=False)

        if level >= 2:
            security_df = _generate_security_data()
            security_df.to_excel(writer, sheet_name='銘柄データ', index=False)

        if level >= 3:
            transaction_df = _generate_transaction_data()
            transaction_df.to_excel(writer, sheet_name='取引明細', index=False)

    output.seek(0)
    return output.getvalue()


# ─── 資産クラス定義 ───────────────────────────────
ASSET_CLASSES = {
    '国内債券（固定）': {'base_bv': 450, 'yield': 0.005, 'vol': 0.02, 'drift': 0.0},
    '国内債券（変動）': {'base_bv': 150, 'yield': 0.003, 'vol': 0.005, 'drift': 0.001},
    '外国債券（ヘッジ有）': {'base_bv': 120, 'yield': 0.025, 'vol': 0.03, 'drift': -0.001},
    '外国債券（ヘッジ無）': {'base_bv': 80, 'yield': 0.035, 'vol': 0.06, 'drift': 0.002},
    '国内株式': {'base_bv': 70, 'yield': 0.02, 'vol': 0.08, 'drift': 0.005},
    'J-REIT': {'base_bv': 40, 'yield': 0.04, 'vol': 0.05, 'drift': 0.002},
    'その他投信': {'base_bv': 60, 'yield': 0.015, 'vol': 0.04, 'drift': 0.001},
}

# 証券の種類 -> monthly_dataの資産クラスへのマッピング
CATEGORY_TO_ASSET_CLASS = {
    '国債': '国内債券（固定）',
    '地方債': '国内債券（固定）',
    '社債': '国内債券（固定）',
    '外国債券': '外国債券（ヘッジ有）',  # 外国債券 = 4 chars
    '国内株式': '国内株式',
    'J-REIT': 'J-REIT',
    'その他投信': 'その他投信',
}

def _generate_monthly_data() -> pd.DataFrame:
    """
    月次×資産クラスデータを生成。

    生成ロジック:
      簿価: 前月簿価 × (1 + 微小ドリフト + ノイズ)
        ※ 売買による増減を模擬
      時価: 簿価 × (1 + 市場変動)
        市場変動 = ドリフト + ランダムショック
      インカム: 簿価 × 月次利回り × (1 + 季節変動)
        ※ 3,6,9,12月にやや多い（決算期効果）
      キャピタル: 時価変動の一部を実現損益として計上
    """
    months = pd.date_range('2024-03', '2025-12', freq='ME')  # 3月末始点
    rows = []

    for ac, params in ASSET_CLASSES.items():
        bv = params['base_bv']
        mv = bv * (1 + np.random.uniform(-0.02, 0.02))

        for i, month in enumerate(months):
            month_str = month.strftime('%Y-%m')

            # 簿価の微小変動（売買模擬）
            bv_change = np.random.normal(0, bv * 0.01)
            bv = max(bv + bv_change, bv * 0.8)

            # 時価の変動
            market_shock = np.random.normal(params['drift'], params['vol'])
            # 金利上昇シナリオ（2024後半～2025前半）
            if '債券' in ac and 8 <= i <= 16:
                market_shock -= 0.005  # 金利上昇→債券価格下落
            mv = bv * (1 + market_shock)

            # インカム収益（月次）
            seasonal = 1.3 if month.month in [3, 6, 9, 12] else 0.9
            income = bv * (params['yield'] / 12) * seasonal * (1 + np.random.normal(0, 0.1))
            income = max(income, 0)

            # キャピタル収益（実現損益の一部）
            capital = (mv - bv) * np.random.uniform(0, 0.1) * np.random.choice([-1, 1], p=[0.4, 0.6])

            rows.append({
                '年月': month_str,
                '資産クラス': ac,
                '簿価': round(bv, 2),
                '時価': round(mv, 2),
                'インカム収益額': round(income, 4),
                'キャピタル収益額': round(capital, 4),
            })

    return pd.DataFrame(rows)


# ─── 銘柄マスタ ─────────────────────────────────
SECURITIES = [
    # 国債
    {'name': '第370回利付国債(10年)', 'code': 'JGB370', 'type': '国債', 'sub': '固定利付', 'issuer': '日本国政府', 'industry': '政府', 'ccy': 'JPY', 'coupon': 0.005, 'rw': 0, 'dur': 8.5},
    {'name': '第371回利付国債(10年)', 'code': 'JGB371', 'type': '国債', 'sub': '固定利付', 'issuer': '日本国政府', 'industry': '政府', 'ccy': 'JPY', 'coupon': 0.008, 'rw': 0, 'dur': 9.2},
    {'name': '第165回利付国債(20年)', 'code': 'JGB165-20', 'type': '国債', 'sub': '固定利付', 'issuer': '日本国政府', 'industry': '政府', 'ccy': 'JPY', 'coupon': 0.012, 'rw': 0, 'dur': 16.3},
    {'name': '第88回利付国債(5年)', 'code': 'JGB088-5', 'type': '国債', 'sub': '固定利付', 'issuer': '日本国政府', 'industry': '政府', 'ccy': 'JPY', 'coupon': 0.003, 'rw': 0, 'dur': 4.1},
    {'name': '第25回変動利付国債(15年)', 'code': 'JGB025-V', 'type': '国債', 'sub': '変動利付', 'issuer': '日本国政府', 'industry': '政府', 'ccy': 'JPY', 'coupon': 0.002, 'rw': 0, 'dur': 0.5},
    # 地方債
    {'name': '東京都公募公債R6-5', 'code': 'TMG-R6-5', 'type': '地方債', 'sub': '固定利付', 'issuer': '東京都', 'industry': '地方公共団体', 'ccy': 'JPY', 'coupon': 0.006, 'rw': 0, 'dur': 7.0},
    {'name': '大阪府公募公債R6-3', 'code': 'OPG-R6-3', 'type': '地方債', 'sub': '固定利付', 'issuer': '大阪府', 'industry': '地方公共団体', 'ccy': 'JPY', 'coupon': 0.007, 'rw': 0, 'dur': 6.5},
    # 社債
    {'name': 'トヨタ自動車 第45回社債', 'code': 'TOYOTA-45', 'type': '社債', 'sub': '固定利付', 'issuer': 'トヨタ自動車', 'industry': '輸送用機器', 'ccy': 'JPY', 'coupon': 0.008, 'rw': 20, 'dur': 5.3},
    {'name': '三菱UFJ FG 第30回社債', 'code': 'MUFG-30', 'type': '社債', 'sub': '固定利付', 'issuer': '三菱UFJ FG', 'industry': '銀行', 'ccy': 'JPY', 'coupon': 0.010, 'rw': 20, 'dur': 4.8},
    {'name': 'NTT 第55回社債', 'code': 'NTT-55', 'type': '社債', 'sub': '固定利付', 'issuer': 'NTT', 'industry': '情報通信', 'ccy': 'JPY', 'coupon': 0.007, 'rw': 20, 'dur': 3.2},
    {'name': 'ソフトバンクG 第60回社債', 'code': 'SBG-60', 'type': '社債', 'sub': '固定利付', 'issuer': 'ソフトバンクG', 'industry': '情報通信', 'ccy': 'JPY', 'coupon': 0.018, 'rw': 50, 'dur': 4.5},
    {'name': '東京電力HD 第40回社債', 'code': 'TEPCO-40', 'type': '社債', 'sub': '固定利付', 'issuer': '東京電力HD', 'industry': '電力', 'ccy': 'JPY', 'coupon': 0.015, 'rw': 50, 'dur': 6.1},
    # 外国債券
    {'name': 'US Treasury 2.5% 2030', 'code': 'UST-2030', 'type': '外国債券', 'sub': 'ヘッジ有', 'issuer': '米国政府', 'industry': '政府', 'ccy': 'USD', 'coupon': 0.025, 'rw': 0, 'dur': 5.5},
    {'name': 'US Treasury 3.0% 2033', 'code': 'UST-2033', 'type': '外国債券', 'sub': 'ヘッジ有', 'issuer': '米国政府', 'industry': '政府', 'ccy': 'USD', 'coupon': 0.030, 'rw': 0, 'dur': 7.8},
    {'name': 'Apple Inc 3.25% 2029', 'code': 'AAPL-2029', 'type': '外国債券', 'sub': 'ヘッジ無', 'issuer': 'Apple Inc', 'industry': 'テクノロジー', 'ccy': 'USD', 'coupon': 0.0325, 'rw': 20, 'dur': 4.2},
    {'name': 'Bund 1.5% 2031', 'code': 'BUND-2031', 'type': '外国債券', 'sub': 'ヘッジ無', 'issuer': 'ドイツ連邦政府', 'industry': '政府', 'ccy': 'EUR', 'coupon': 0.015, 'rw': 0, 'dur': 6.0},
    {'name': 'Goldman Sachs 4.0% 2028', 'code': 'GS-2028', 'type': '外国債券', 'sub': 'ヘッジ有', 'issuer': 'Goldman Sachs', 'industry': '金融', 'ccy': 'USD', 'coupon': 0.040, 'rw': 50, 'dur': 3.1},
    # 株式（投信含む）
    {'name': 'TOPIX連動型ETF', 'code': 'TOPIX-ETF', 'type': '国内株式', 'sub': 'ETF', 'issuer': '日興AM', 'industry': '投信', 'ccy': 'JPY', 'coupon': 0.02, 'rw': 100, 'dur': 0},
    {'name': 'トヨタ自動車（株式）', 'code': '7203', 'type': '国内株式', 'sub': '個別株', 'issuer': 'トヨタ自動車', 'industry': '輸送用機器', 'ccy': 'JPY', 'coupon': 0.025, 'rw': 100, 'dur': 0},
    {'name': '三菱商事（株式）', 'code': '8058', 'type': '国内株式', 'sub': '個別株', 'issuer': '三菱商事', 'industry': '商社', 'ccy': 'JPY', 'coupon': 0.03, 'rw': 100, 'dur': 0},
    # J-REIT
    {'name': '日本ビルファンド', 'code': '8951', 'type': 'J-REIT', 'sub': 'REIT', 'issuer': '日本ビルファンド', 'industry': '不動産', 'ccy': 'JPY', 'coupon': 0.04, 'rw': 100, 'dur': 0},
    {'name': 'ジャパンリアルエステイト', 'code': '8952', 'type': 'J-REIT', 'sub': 'REIT', 'issuer': 'JRE', 'industry': '不動産', 'ccy': 'JPY', 'coupon': 0.038, 'rw': 100, 'dur': 0},
    # その他
    {'name': 'グローバルバランスファンド', 'code': 'GB-FUND', 'type': 'その他投信', 'sub': '投信', 'issuer': '野村AM', 'industry': '投信', 'ccy': 'JPY', 'coupon': 0.015, 'rw': 100, 'dur': 3.0},
    {'name': 'ヘッジファンド型投信', 'code': 'HF-FUND', 'type': 'その他投信', 'sub': '投信', 'issuer': '大和AM', 'industry': '投信', 'ccy': 'JPY', 'coupon': 0.01, 'rw': 100, 'dur': 1.5},
]


def _generate_security_data() -> pd.DataFrame:
    """
    銘柄レベルスナップショットデータを生成。

    各銘柄について、システムから抽出されるイメージの
    詳細データを生成する。
    """
    rows = []
    fx_rates = {'JPY': 1.0, 'USD': 155.5, 'EUR': 168.2}

    for i, sec in enumerate(SECURITIES):
        face = np.random.choice([100, 500, 1000, 2000, 5000]) * (1 if sec['ccy'] != 'JPY' else 1)
        # 簿価単価（額面100円あたり）
        book_price = 100 + np.random.normal(0, 3)
        # 時価単価（金利環境を反映）
        rate_impact = -sec['dur'] * 0.005 if sec['dur'] > 0 else 0
        market_price = book_price * (1 + rate_impact + np.random.normal(0, 0.02))

        fx = fx_rates.get(sec['ccy'], 1.0)
        book_fc = face * book_price / 100
        market_fc = face * market_price / 100
        book_jpy = book_fc * fx
        market_jpy = market_fc * fx

        # 発行日・償還日
        issue_year = np.random.randint(2015, 2024)
        maturity_years = max(sec['dur'] * 1.2, 1) if sec['dur'] > 0 else 0
        issue_date = f'{issue_year}-{np.random.randint(1,13):02d}-15'
        mat_date = f'{issue_year + int(maturity_years) + np.random.randint(1,5)}-{np.random.randint(1,13):02d}-15' if maturity_years > 0 else ''

        # BPV計算: BPV ≈ -修正デュレーション × 時価 × 0.0001
        bpv_10 = -sec['dur'] * market_jpy * 0.001 if sec['dur'] > 0 else 0
        bpv_100 = bpv_10 * 10

        row = {
            'データNo.': i + 1,
            '種別': sec['type'],
            '分類区分': sec['sub'],
            '銘柄名': sec['name'],
            '銘柄コード': sec['code'],
            '発行体名': sec['issuer'],
            '業種': sec['industry'],
            '利率': sec['coupon'],
            '発行日': issue_date,
            '償還日': mat_date if mat_date else None,
            '発行通貨': sec['ccy'],
            '額面': face,
            '簿価': round(book_jpy, 2),
            '時価': round(market_jpy, 2),
            '評価損益': round(market_jpy - book_jpy, 2),
            '簿価金額（外貨）': round(book_fc, 2) if sec['ccy'] != 'JPY' else None,
            '時価金額（外貨）': round(market_fc, 2) if sec['ccy'] != 'JPY' else None,
            '簿価為替レート': fx if sec['ccy'] != 'JPY' else None,
            '時価為替レート': fx * (1 + np.random.normal(0, 0.01)) if sec['ccy'] != 'JPY' else None,
            '簿価単価': round(book_price, 4),
            '時価単価': round(market_price, 4),
            '時価レベル区分': np.random.choice(['Level 1', 'Level 2', 'Level 2'], p=[0.4, 0.5, 0.1]),
            '平均残存年限': round(sec['dur'] + np.random.normal(0, 0.3), 2) if sec['dur'] > 0 else None,
            '簿価利回り': round(sec['coupon'] + np.random.normal(0, 0.001), 4),
            '時価利回り': round(sec['coupon'] * (book_price / market_price) + np.random.normal(0, 0.001), 4) if market_price > 0 else 0,
            '評価損益率': round((market_jpy - book_jpy) / book_jpy, 4) if book_jpy != 0 else 0,
            'リスクウエイト': sec['rw'],
            'リスクアセット金額': round(market_jpy * sec['rw'] / 100, 2),
            'VaR1Y': round(abs(market_jpy * sec['dur'] * 0.01 * np.random.uniform(0.5, 1.5)), 2) if sec['dur'] > 0 else round(market_jpy * 0.05 * np.random.uniform(0.5, 1.5), 2),
            'VaR5Y': round(abs(market_jpy * sec['dur'] * 0.02 * np.random.uniform(0.5, 1.5)), 2) if sec['dur'] > 0 else round(market_jpy * 0.10 * np.random.uniform(0.5, 1.5), 2),
            '円金利10BPV': round(bpv_10, 2) if sec['ccy'] == 'JPY' else 0,
            '円金利100BPV': round(bpv_100, 2) if sec['ccy'] == 'JPY' else 0,
            '外貨金利10BPV': round(bpv_10, 2) if sec['ccy'] != 'JPY' else 0,
            '外貨金利100BPV': round(bpv_100, 2) if sec['ccy'] != 'JPY' else 0,
            '為替Δ': round(market_jpy * 0.01, 2) if sec['ccy'] != 'JPY' else 0,
            'ΔEVE(パラレル上昇)': round(-sec['dur'] * market_jpy * 0.01, 2) if sec['dur'] > 0 else 0,
            'ΔEVE(パラレル低下)': round(sec['dur'] * market_jpy * 0.01, 2) if sec['dur'] > 0 else 0,
            'NII(1年)': round(face * sec['coupon'] * fx, 2),
            '取引先(購入)': np.random.choice(['野村證券', '大和証券', 'みずほ証券', 'SMBC日興', '三菱UFJモルガン']),
        }
        # Map to monthly_data asset_class
        _cat = sec['type']
        _sub = sec.get('sub', '')
        if _cat == '国債' and '変動' in _sub:
            row['asset_class'] = '国内債券（変動）'
        elif _cat == '外国債券' or _cat == '外国債':
            if 'ヘッジ無' in _sub:
                row['asset_class'] = '外国債券（ヘッジ無）'
            else:
                row['asset_class'] = '外国債券（ヘッジ有）'
        else:
            row['asset_class'] = CATEGORY_TO_ASSET_CLASS.get(_cat, _cat)
        rows.append(row)

    df = pd.DataFrame(rows)
    # Reorder columns so asset_class is near category
    cols = list(df.columns)
    if 'asset_class' in cols:
        cols.remove('asset_class')
        cat_idx = cols.index('種類') if '種類' in cols else 1
        cols.insert(cat_idx + 1, 'asset_class')
        df = df[cols]
    return df


def _generate_transaction_data() -> pd.DataFrame:
    """取引明細データを生成。"""
    rows = []
    dates = pd.date_range('2024-04-01', '2025-12-20', freq='B')  # 4月以降

    for _ in range(120):
        sec = np.random.choice(SECURITIES)
        date = pd.Timestamp(np.random.choice(dates))
        trade_type = np.random.choice(['購入', '売却', 'インカム'], p=[0.4, 0.25, 0.35])

        fx = {'JPY': 1.0, 'USD': 155.5, 'EUR': 168.2}.get(sec['ccy'], 1.0)

        if trade_type == 'インカム':
            face = np.random.choice([100, 500, 1000]) * (1 if sec['ccy'] != 'JPY' else 1)
            amount = round(face * sec['coupon'] / 2 * fx, 2)
            qty = 0
            price = 0
            cost = 0
        else:
            qty = np.random.choice([100, 200, 500, 1000])
            price = round(100 + np.random.normal(0, 3), 2)
            amount = round(qty * price * fx / 100, 2)
            cost = round(amount * np.random.uniform(0.001, 0.005), 2)

        rows.append({
            '取引日': date.strftime('%Y-%m-%d'),
            '銘柄コード': sec['code'],
            '銘柄名': sec['name'],
            '売買区分': trade_type,
            '数量': qty,
            '単価': price,
            '金額': amount,
            'コスト': cost,
            '通貨': sec['ccy'],
        })

    df = pd.DataFrame(rows).sort_values('取引日').reset_index(drop=True)
    return df

