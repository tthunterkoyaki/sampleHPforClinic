"""tab_timeseries.py - 時系列分析タブ（月次リターンを収益分析に統合したためシンプル化）"""
import streamlit as st
import plotly.graph_objects as go
from portfolio_dashboard.ui_components import (
    render_insight_cards, create_time_series_chart, create_stacked_bar_chart,
    get_asset_color, PLOTLY_LAYOUT, hex_to_rgba, apply_jp_xaxis, order_asset_classes
)
from portfolio_dashboard.analytics.portfolio_analytics import export_to_excel

def render(monthly_df, data, ts, show_evidence):
    st.markdown('<div class="section-header">📈 時系列推移分析</div>', unsafe_allow_html=True)

    ordered_classes = order_asset_classes(data.asset_classes)

    # 資産クラス別時価推移（積み上げ棒グラフ）
    comp_ts = ts.compute_composition_changes(monthly_df)
    fig_stack = create_stacked_bar_chart(comp_ts, 'date', ordered_classes, 'market_value',
                                          'asset_class', title='資産クラス別時価推移（積み上げ棒グラフ）')
    st.plotly_chart(fig_stack, use_container_width=True)

    # 構成比推移（積み上げ棒グラフ）
    fig_pct = go.Figure()
    for ac in ordered_classes:
        acd = comp_ts[comp_ts['asset_class'] == ac]
        fig_pct.add_trace(go.Bar(x=acd['date'], y=acd['composition_pct'], name=ac,
            marker_color=get_asset_color(ac), hovertemplate=f'{ac}: %{{y:.1f}}%<extra></extra>'))
    fig_pct.update_layout(**PLOTLY_LAYOUT, height=350,
        title=dict(text='構成比推移(%)', font=dict(size=14, color='#0f172a')), barmode='stack')
    fig_pct.update_layout(yaxis=dict(title='%', range=[0, 100]))
    apply_jp_xaxis(fig_pct, sorted(comp_ts['date'].unique()))
    st.plotly_chart(fig_pct, use_container_width=True)

    # 累積リターン
    st.markdown('<div class="section-header">📊 累積リターン</div>', unsafe_allow_html=True)
    cum = ts.compute_cumulative_returns(monthly_df)
    fig_cum = create_time_series_chart(cum, 'date',
        {'index_total': 'トータル', 'index_income': 'インカム', 'index_capital': 'キャピタル'},
        title='累積リターン指数（基準=100）')
    fig_cum.add_hline(y=100, line_dash='dash', line_color='#cbd5e1', line_width=1)
    apply_jp_xaxis(fig_cum, cum['date'])
    st.plotly_chart(fig_cum, use_container_width=True)

    # トレンド検出
    st.markdown('<div class="section-header">🔍 トレンド検出</div>', unsafe_allow_html=True)
    trends = ts.detect_trends(monthly_df)
    dir_map = {'up': '上昇', 'down': '下降', 'flat': '横ばい'}
    if trends:
        for t in trends:
            icon = '📈' if t['direction'] == 'up' else ('📉' if t['direction'] == 'down' else '➡️')
            sev = 'info' if t['direction'] == 'flat' else ('medium' if t['direction'] == 'down' else 'low')
            dir_label = dir_map.get(t['direction'], '')
            render_insight_cards([{'severity': sev, 'icon': icon,
                'title': t['label'] + ' - ' + dir_label + 'トレンド',
                'description': t['description'],
                'reasoning': 'R²=' + str(round(t['r_squared'], 3)),
                'evidence': t['evidence']}],
                show_evidence=show_evidence)

    anomalies = ts.find_anomalies(monthly_df)
    if anomalies:
        st.markdown('<div class="section-header">⚠ 異常値検出</div>', unsafe_allow_html=True)
        anom_cards = []
        for a in anomalies[:5]:
            anom_cards.append({'severity': a['severity'], 'icon': '⚠',
                'title': a['description'], 'description': 'Z=' + str(round(a['z_score'], 1)),
                'evidence': a['evidence']})
        render_insight_cards(anom_cards, show_evidence=show_evidence)

    st.markdown("---")
    totals = ts.compute_period_totals(monthly_df)
    dl = export_to_excel({'集計': totals, '構成比推移': comp_ts, '累積リターン': cum})
    st.download_button("📥 時系列データ (Excel)", data=dl, file_name="timeseries.xlsx",
                       mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")