﻿"""portfolio_dashboard - 保有銘柄ダッシュボード＋分析ツール"""
__version__ = "1.0.0"
