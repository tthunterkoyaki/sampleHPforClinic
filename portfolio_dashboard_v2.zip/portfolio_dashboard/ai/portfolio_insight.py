"""portfolio_insight.py - ポートフォリオインサイト自動生成エンジン

bert_assistant.InsightGeneratorとは別に、ポートフォリオ特化のインサイトを生成する。
"""
import pandas as pd
import numpy as np
from typing import List, Dict, Any, Optional


class PortfolioInsightGenerator:
    """
    ポートフォリオデータからインサイトを自動生成するクラス。

    分析の流れ:
      1. Level 1 (月次データ): 時系列トレンド、構成変化、収益分析
      2. Level 2 (銘柄データ): 個別銘柄リスク、含み損、償還分析
      3. Level 3 (取引データ): 取引コスト分析
      4. アクショナブル分析: 示唆・提言レベルのインサイト

    判定ロジック:
      - 統計的手法: Zスコア、線形回帰、変動係数(CV)
      - ルールベース: 閾値超過検出
      - 重要度: high/medium/low/info の4段階
    """

    def __init__(self, model_manager=None):
        self.mm = model_manager

    def generate_insights(self, monthly_df, security_df=None, transaction_df=None):
        """全レベルのデータからインサイトを生成し、重要度順にソートして返す。"""
        insights = []

        # Level 1
        insights.extend(self._analyze_time_series_insights(monthly_df))
        insights.extend(self._analyze_composition_insights(monthly_df))
        insights.extend(self._analyze_return_insights(monthly_df))
        insights.extend(self._analyze_actionable_insights(monthly_df))

        # Level 2
        if security_df is not None and len(security_df) > 0:
            insights.extend(self._analyze_security_insights(security_df))

        # Level 3
        if transaction_df is not None and len(transaction_df) > 0:
            insights.extend(self._analyze_transaction_insights(transaction_df))

        sev_order = {'high': 0, 'medium': 1, 'low': 2, 'info': 3}
        insights.sort(key=lambda x: sev_order.get(x.get('severity', 'info'), 99))
        return insights

    def _analyze_time_series_insights(self, df):
        insights = []
        totals = df.groupby('date').agg({
            'market_value': 'sum', 'book_value': 'sum', 'unrealized_gl': 'sum',
        }).sort_index()
        if len(totals) < 3:
            return insights

        gl_series = totals['unrealized_gl']
        gl_diffs = gl_series.diff().dropna()
        # Count consecutive positive GL values (evaluation gain months)
        consec_pos_gl = 0
        for v in gl_series.iloc[::-1]:
            if v > 0: consec_pos_gl += 1
            else: break
        # Count consecutive negative GL values (evaluation loss months)
        consec_neg_gl = 0
        for v in gl_series.iloc[::-1]:
            if v < 0: consec_neg_gl += 1
            else: break
        # Count consecutive improving diffs
        consec_improve = 0
        for v in gl_diffs.iloc[::-1]:
            if v > 0: consec_improve += 1
            else: break
        # Count consecutive worsening diffs
        consec_worsen = 0
        for v in gl_diffs.iloc[::-1]:
            if v < 0: consec_worsen += 1
            else: break
        # Report: prioritize GL value streaks over diff streaks
        if consec_neg_gl >= 3:
            insights.append({
                'type': 'trend', 'severity': 'medium',
                'icon': '\U0001f4c9', 'title': f'{consec_neg_gl}\u30f6\u6708\u9023\u7d9a\u3067\u8a55\u4fa1\u640d',
                'description': f'{consec_neg_gl}\u30f6\u6708\u9023\u7d9a\u3067\u8a55\u4fa1\u640d\u3068\u306a\u3063\u3066\u3044\u307e\u3059\u3002\u76f4\u8fd1\u5024: {gl_series.iloc[-1]:,.1f}\u5104\u5186\u3002\u91d1\u5229\u4e0a\u6607\u5c40\u9762\u3067\u306e\u30c7\u30e5\u30ec\u30fc\u30b7\u30e7\u30f3\u77ed\u671f\u5316\u3084\u30d8\u30c3\u30b8\u4ed8\u4e0e\u306e\u691c\u8a0e\u3092\u304a\u52e7\u3081\u3057\u307e\u3059\u3002',
                'reasoning': f'\u76f4\u8fd1{consec_neg_gl}\u30f6\u6708\u9023\u7d9a\u3067\u8a55\u4fa1\u640d\u76ca\u304c\u30de\u30a4\u30ca\u30b9\u3002',
                'evidence': {'consecutive_months': consec_neg_gl, 'end_value': float(gl_series.iloc[-1])},
            })
        elif consec_pos_gl >= 3:
            insights.append({
                'type': 'trend', 'severity': 'info',
                'icon': '\U0001f4c8', 'title': f'{consec_pos_gl}\u30f6\u6708\u9023\u7d9a\u3067\u8a55\u4fa1\u76ca',
                'description': f'{consec_pos_gl}\u30f6\u6708\u9023\u7d9a\u3067\u8a55\u4fa1\u76ca\u3068\u306a\u3063\u3066\u3044\u307e\u3059\u3002\u76f4\u8fd1\u5024: {gl_series.iloc[-1]:,.1f}\u5104\u5186\u3002\u5e02\u5834\u74b0\u5883\u304c\u826f\u597d\u3067\u3059\u304c\u3001\u5229\u76ca\u78ba\u5b9a\u306e\u30bf\u30a4\u30df\u30f3\u30b0\u3082\u691c\u8a0e\u306b\u5024\u3057\u307e\u3059\u3002',
                'reasoning': f'\u76f4\u8fd1{consec_pos_gl}\u30f6\u6708\u9023\u7d9a\u3067\u8a55\u4fa1\u640d\u76ca\u304c\u30d7\u30e9\u30b9\u3002',
                'evidence': {'consecutive_months': consec_pos_gl, 'end_value': float(gl_series.iloc[-1])},
            })
        elif consec_worsen >= 3:
            insights.append({
                'type': 'trend', 'severity': 'medium',
                'icon': '\U0001f4c9', 'title': f'\u8a55\u4fa1\u640d\u76ca\u304c{consec_worsen}\u30f6\u6708\u9023\u7d9a\u60aa\u5316',
                'description': f'\u76f4\u8fd1{consec_worsen}\u30f6\u6708\u9593\u3001\u8a55\u4fa1\u640d\u76ca\u304c\u9023\u7d9a\u3057\u3066\u4f4e\u4e0b\u3057\u3066\u3044\u307e\u3059\u3002\u76f4\u8fd1\u5024: {gl_series.iloc[-1]:,.1f}\u5104\u5186\u3002',
                'reasoning': f'\u8a55\u4fa1\u640d\u76ca\u306e\u76f4\u8fd1{consec_worsen}\u30f6\u6708\u306e\u5dee\u5206\u304c\u3059\u3079\u3066\u30de\u30a4\u30ca\u30b9\u3002',
                'evidence': {'consecutive_months': consec_worsen, 'end_value': float(gl_series.iloc[-1])},
            })
        elif consec_improve >= 3:
            insights.append({
                'type': 'trend', 'severity': 'info',
                'icon': '\U0001f4c8', 'title': f'\u8a55\u4fa1\u640d\u76ca\u304c{consec_improve}\u30f6\u6708\u9023\u7d9a\u6539\u5584',
                'description': f'\u76f4\u8fd1{consec_improve}\u30f6\u6708\u9593\u3001\u8a55\u4fa1\u640d\u76ca\u304c\u9023\u7d9a\u3057\u3066\u6539\u5584\u3057\u3066\u3044\u307e\u3059\u3002\u76f4\u8fd1\u5024: {gl_series.iloc[-1]:,.1f}\u5104\u5186\u3002',
                'reasoning': f'\u8a55\u4fa1\u640d\u76ca\u306e\u76f4\u8fd1{consec_improve}\u30f6\u6708\u306e\u5dee\u5206\u304c\u3059\u3079\u3066\u30d7\u30e9\u30b9\u3002',
                'evidence': {'consecutive_months': consec_improve, 'end_value': float(gl_series.iloc[-1])},
            })

        mv = totals['market_value']
        if len(mv) >= 6:
            cv = mv.std() / mv.mean() if mv.mean() != 0 else 0
            if cv > 0.05:
                insights.append({
                    'type': 'volatility', 'severity': 'medium',
                    'icon': '\u26a1', 'title': '\u6642\u4fa1\u306e\u5909\u52d5\u304c\u5927\u304d\u3044',
                    'description': f'\u6642\u4fa1\u306e\u5909\u52d5\u4fc2\u6570(CV={cv:.3f})\u304c\u9ad8\u3044\u6c34\u6e96\u3067\u3059\u3002\u5e02\u5834\u30ea\u30b9\u30af\u306e\u7ba1\u7406\u3092\u5f37\u5316\u3059\u308b\u5fc5\u8981\u304c\u3042\u308b\u304b\u3082\u3057\u308c\u307e\u305b\u3093\u3002',
                    'reasoning': f'\u5909\u52d5\u4fc2\u6570(CV=\u6a19\u6e96\u504f\u5dee/\u5e73\u5747)\u304c0.05\u3092\u8d85\u3048\u308b\u5834\u5408\u306b\u8b66\u544a\u3002',
                    'evidence': {'mean': float(mv.mean()), 'std': float(mv.std())},
                })
        return insights

    def _analyze_composition_insights(self, df):
        insights = []
        dates = sorted(df['date'].unique())
        if len(dates) < 4:
            return insights
        mid = len(dates) // 2
        first_half = df[df['date'].isin(dates[:mid])]
        second_half = df[df['date'].isin(dates[mid:])]
        first_comp = first_half.groupby('asset_class')['market_value'].mean()
        second_comp = second_half.groupby('asset_class')['market_value'].mean()
        first_total = first_comp.sum()
        second_total = second_comp.sum()
        if first_total > 0 and second_total > 0:
            for ac in first_comp.index:
                if ac in second_comp.index:
                    pct1 = first_comp[ac] / first_total * 100
                    pct2 = second_comp[ac] / second_total * 100
                    change = pct2 - pct1
                    if abs(change) > 5:
                        d = '\u5897\u52a0' if change > 0 else '\u6e1b\u5c11'
                        insights.append({
                            'type': 'composition_shift', 'severity': 'low',
                            'icon': '\U0001f504', 'title': f'{ac}\u306e\u69cb\u6210\u6bd4\u304c{d}',
                            'description': f'{ac}\u306e\u69cb\u6210\u6bd4\u304c\u524d\u534a{pct1:.1f}%\u2192\u5f8c\u534a{pct2:.1f}%\u306b{d}\u3002\u30dd\u30fc\u30c8\u30d5\u30a9\u30ea\u30aa\u306e\u30ea\u30d0\u30e9\u30f3\u30b9\u304c\u9032\u3093\u3067\u3044\u308b\u53ef\u80fd\u6027\u304c\u3042\u308a\u307e\u3059\u3002',
                            'reasoning': '\u30c7\u30fc\u30bf\u671f\u9593\u306e\u524d\u534a\u3068\u5f8c\u534a\u3092\u6bd4\u8f03\u3057\u30015%pt\u8d85\u306e\u69cb\u6210\u6bd4\u5909\u5316\u3092\u691c\u51fa\u3002',
                            'evidence': {'before': float(pct1), 'after': float(pct2), 'change': float(change)},
                        })
        return insights

    def _analyze_return_insights(self, df):
        insights = []
        totals = df.groupby('date').agg({'income': 'sum', 'capital': 'sum', 'book_value': 'sum'}).sort_index()
        total_income = totals['income'].sum()
        total_capital = totals['capital'].sum()
        total_return = total_income + total_capital

        if total_return != 0:
            income_ratio = total_income / (abs(total_income) + abs(total_capital)) * 100
            if income_ratio > 80:
                insights.append({
                    'type': 'return_quality', 'severity': 'info', 'icon': '\U0001f3e6',
                    'title': '\u30a4\u30f3\u30ab\u30e0\u4e3b\u5c0e\u306e\u5b89\u5b9a\u53ce\u76ca\u69cb\u9020',
                    'description': f'\u53ce\u76ca\u306e{income_ratio:.0f}%\u304c\u30a4\u30f3\u30ab\u30e0\u7531\u6765\u3002\u5b89\u5b9a\u7684\u3067\u3059\u304c\u3001\u91d1\u5229\u4f4e\u4e0b\u5c40\u9762\u3067\u306f\u518d\u6295\u8cc7\u30ea\u30b9\u30af\u306b\u6ce8\u610f\u304c\u5fc5\u8981\u3067\u3059\u3002',
                    'reasoning': '\u30a4\u30f3\u30ab\u30e0\u6bd4\u738780%\u8d85\u306f\u5b89\u5b9a\u7684\u306a\u53ce\u76ca\u69cb\u9020\u3068\u5224\u5b9a\u3002',
                    'evidence': {'income_ratio': float(income_ratio)},
                })
            elif total_capital < 0 and abs(total_capital) > total_income * 0.5:
                insights.append({
                    'type': 'return_quality', 'severity': 'medium', 'icon': '\u26a1',
                    'title': '\u30ad\u30e3\u30d4\u30bf\u30eb\u30ed\u30b9\u304c\u30a4\u30f3\u30ab\u30e0\u3092\u4fb5\u98df',
                    'description': f'\u30ad\u30e3\u30d4\u30bf\u30eb\u640d\u5931({total_capital:,.1f}\u5104\u5186)\u304c\u30a4\u30f3\u30ab\u30e0\u53ce\u76ca({total_income:,.1f}\u5104\u5186)\u306e{abs(total_capital)/total_income*100:.0f}%\u306b\u9054\u3057\u3066\u3044\u307e\u3059\u3002',
                    'reasoning': '\u30ad\u30e3\u30d4\u30bf\u30eb\u640d\u5931\u304c\u30a4\u30f3\u30ab\u30e0\u306e50%\u4ee5\u4e0a\u3092\u4fb5\u98df\u3059\u308b\u5834\u5408\u306b\u8b66\u544a\u3002',
                    'evidence': {'total_income': float(total_income), 'total_capital': float(total_capital)},
                })

        n_months = len(totals)
        avg_bv = totals['book_value'].mean()
        if avg_bv > 0 and n_months > 0:
            annual_return = (total_return / avg_bv) * (12 / n_months) * 100
            insights.append({
                'type': 'performance', 'severity': 'info', 'icon': '\U0001f4ca',
                'title': f'\u5e74\u7387\u63db\u7b97\u30ea\u30bf\u30fc\u30f3: {annual_return:.2f}%',
                'description': f'\u671f\u9593\u4e2d\u306e\u5e74\u7387\u63db\u7b97\u30c8\u30fc\u30bf\u30eb\u30ea\u30bf\u30fc\u30f3\u306f{annual_return:.2f}%\u3067\u3059\uff08{n_months}\u30f6\u6708\u9593\u5b9f\u7e3e\uff09\u3002',
                'reasoning': f'\u5e74\u7387\u63db\u7b97 = (\u7d2f\u8a08\u53ce\u76ca / \u5e73\u5747\u7c3f\u4fa1) x (12 / {n_months})',
                'evidence': {'total_return': float(total_return), 'avg_book_value': float(avg_bv), 'n_months': n_months},
            })
        return insights

    def _analyze_security_insights(self, df):
        insights = []
        if 'unrealized_gl' in df.columns and 'security_name' in df.columns:
            losses = df[df['unrealized_gl'] < 0].nsmallest(3, 'unrealized_gl')
            if len(losses) > 0:
                worst = losses.iloc[0]
                insights.append({
                    'type': 'security_alert', 'severity': 'medium', 'icon': '\U0001f534',
                    'title': f'\u6700\u5927\u542b\u307f\u640d: {worst["security_name"]}',
                    'description': f'{worst["security_name"]}\u306e\u542b\u307f\u640d\u304c{worst["unrealized_gl"]:,.0f}\u3068\u6700\u5927\u3002\u91d1\u5229\u611f\u5fdc\u5ea6\u3084\u30af\u30ec\u30b8\u30c3\u30c8\u30ea\u30b9\u30af\u3092\u78ba\u8a8d\u3057\u3001\u4fdd\u6709\u7d99\u7d9a\u306e\u59a5\u5f53\u6027\u3092\u691c\u8a0e\u3057\u3066\u304f\u3060\u3055\u3044\u3002',
                    'reasoning': '\u500b\u5225\u9298\u67c4\u306e\u542b\u307f\u640d\u984d\u3067\u30bd\u30fc\u30c8\u3057\u3001\u6700\u5927\u306e\u9298\u67c4\u3092\u7279\u5b9a\u3002',
                    'evidence': {'security': str(worst.get('security_name', '')), 'unrealized_gl': float(worst['unrealized_gl'])},
                })
        if 'avg_remaining' in df.columns and 'security_name' in df.columns:
            near = df[df['avg_remaining'] < 0.5]
            if len(near) > 0:
                total_mv = near['market_value'].sum() if 'market_value' in near.columns else 0
                insights.append({
                    'type': 'maturity', 'severity': 'low', 'icon': '\u23f0',
                    'title': f'{len(near)}\u9298\u67c4\u304c6\u30f6\u6708\u4ee5\u5185\u306b\u511f\u9084',
                    'description': f'\u5408\u8a08{total_mv:,.0f}\u304c6\u30f6\u6708\u4ee5\u5185\u306b\u511f\u9084\u4e88\u5b9a\u3002\u73fe\u5728\u306e\u91d1\u5229\u74b0\u5883\u3067\u306e\u518d\u6295\u8cc7\u5148\u3092\u65e9\u3081\u306b\u691c\u8a0e\u3059\u308b\u3053\u3068\u3092\u304a\u52e7\u3081\u3057\u307e\u3059\u3002',
                    'reasoning': '\u6b8b\u5b58\u5e74\u96500.5\u5e74\u672a\u6e80\u306e\u9298\u67c4\u3092\u691c\u51fa\u3002',
                    'evidence': {'n_securities': len(near), 'total_market_value': float(total_mv)},
                })
        return insights

    def _analyze_transaction_insights(self, df):
        insights = []
        if 'cost' in df.columns and 'amount' in df.columns:
            total_cost = df['cost'].sum()
            total_amount = df['amount'].sum()
            if total_amount > 0:
                cost_ratio = total_cost / total_amount * 100
                if cost_ratio > 0.5:
                    insights.append({
                        'type': 'cost', 'severity': 'low', 'icon': '\U0001f4b0',
                        'title': f'\u53d6\u5f15\u30b3\u30b9\u30c8\u7387: {cost_ratio:.2f}%',
                        'description': f'\u53d6\u5f15\u30b3\u30b9\u30c8\u7387\u304c{cost_ratio:.2f}%\u3067\u3059\u3002\u53d6\u5f15\u5148\u306e\u5206\u6563\u3084\u30cd\u30c3\u30c8\u53d6\u5f15\u306e\u6d3b\u7528\u3067\u30b3\u30b9\u30c8\u524a\u6e1b\u306e\u4f59\u5730\u304c\u3042\u308b\u304b\u3082\u3057\u308c\u307e\u305b\u3093\u3002',
                        'reasoning': '\u53d6\u5f15\u30b3\u30b9\u30c8\u73870.5%\u8d85\u3092\u6ce8\u610f\u5bfe\u8c61\u3068\u3057\u3066\u691c\u51fa\u3002',
                        'evidence': {'total_cost': float(total_cost), 'total_amount': float(total_amount)},
                    })
        return insights

    def _analyze_actionable_insights(self, df):
        insights = []
        totals = df.groupby('date').agg({
            'income': 'sum', 'capital': 'sum', 'book_value': 'sum',
            'market_value': 'sum', 'unrealized_gl': 'sum',
        }).sort_index()

        if len(totals) >= 6:
            recent_inc = totals['income'].tail(3).mean()
            earlier_inc = totals['income'].head(3).mean()
            if earlier_inc > 0:
                inc_change = (recent_inc - earlier_inc) / earlier_inc * 100
                if inc_change < -10:
                    insights.append({
                        'type': 'actionable', 'severity': 'medium', 'icon': '\U0001f4a1',
                        'title': '\u30a4\u30f3\u30ab\u30e0\u53ce\u76ca\u306e\u4f4e\u4e0b\u50be\u5411',
                        'description': f'\u76f4\u8fd13\u30f6\u6708\u306e\u30a4\u30f3\u30ab\u30e0\u6708\u5e73\u5747\u304c\u521d\u671f\u6bd4{inc_change:.1f}%\u4f4e\u4e0b\u3002\u4f4e\u91d1\u5229\u74b0\u5883\u3067\u306e\u518d\u6295\u8cc7\u30ea\u30b9\u30af\u304c\u9855\u5728\u5316\u3057\u3066\u3044\u308b\u53ef\u80fd\u6027\u304c\u3042\u308a\u307e\u3059\u3002\u5229\u56de\u308a\u6539\u5584\u306e\u305f\u3081\u306e\u30dd\u30fc\u30c8\u30d5\u30a9\u30ea\u30aa\u5165\u66ff\u3092\u691c\u8a0e\u3059\u308b\u4fa1\u5024\u304c\u3042\u308a\u307e\u3059\u3002',
                        'reasoning': '\u521d\u671f3\u30f6\u6708\u3068\u76f4\u8fd13\u30f6\u6708\u306e\u30a4\u30f3\u30ab\u30e0\u5e73\u5747\u3092\u6bd4\u8f03\u3057\u300110%\u8d85\u306e\u4f4e\u4e0b\u3092\u691c\u51fa\u3002',
                        'evidence': {'before': float(earlier_inc), 'after': float(recent_inc)},
                    })
                elif inc_change > 15:
                    insights.append({
                        'type': 'actionable', 'severity': 'info', 'icon': '\U0001f4c8',
                        'title': '\u30a4\u30f3\u30ab\u30e0\u53ce\u76ca\u306e\u6539\u5584',
                        'description': f'\u76f4\u8fd1\u306e\u30a4\u30f3\u30ab\u30e0\u6708\u5e73\u5747\u304c\u521d\u671f\u6bd4{inc_change:.1f}%\u6539\u5584\u3002\u91d1\u5229\u4e0a\u6607\u5c40\u9762\u3067\u306e\u518d\u6295\u8cc7\u52b9\u679c\u304c\u5bc4\u4e0e\u3057\u3066\u3044\u307e\u3059\u3002',
                        'reasoning': '\u521d\u671f3\u30f6\u6708\u3068\u76f4\u8fd13\u30f6\u6708\u306e\u30a4\u30f3\u30ab\u30e0\u5e73\u5747\u3092\u6bd4\u8f03\u3002',
                        'evidence': {'before': float(earlier_inc), 'after': float(recent_inc)},
                    })

        if len(totals) >= 4:
            gl_trend = totals['unrealized_gl'].diff().dropna()
            # Count consecutive negative diffs (worsening)
            consecutive_neg = 0
            for v in gl_trend.iloc[::-1]:
                if v < 0: consecutive_neg += 1
                else: break
            if consecutive_neg >= 3:
                insights.append({
                    'type': 'actionable', 'severity': 'medium', 'icon': '\U0001f4c9',
                    'title': f'\u8a55\u4fa1\u640d\u76ca\u306e\u7d99\u7d9a\u7684\u60aa\u5316',
                    'description': f'{consecutive_neg}\u30f6\u6708\u9023\u7d9a\u3067\u8a55\u4fa1\u640d\u76ca\u304c\u60aa\u5316\u3057\u3066\u3044\u307e\u3059\u3002\u91d1\u5229\u4e0a\u6607\u5c40\u9762\u304c\u7d99\u7d9a\u3057\u3066\u3044\u308b\u53ef\u80fd\u6027\u304c\u9ad8\u304f\u3001\u30c7\u30e5\u30ec\u30fc\u30b7\u30e7\u30f3\u77ed\u671f\u5316\u3084\u30d8\u30c3\u30b8\u4ed8\u4e0e\u306e\u691c\u8a0e\u3092\u304a\u52e7\u3081\u3057\u307e\u3059\u3002',
                    'reasoning': f'\u76f4\u8fd1{consecutive_neg}\u30f6\u6708\u9023\u7d9a\u3067\u524d\u6708\u6bd4\u30de\u30a4\u30ca\u30b9\u3092\u691c\u51fa\u3002',
                    'evidence': {'consecutive_months': consecutive_neg},
                })


        by_ac = df.groupby('asset_class').agg({'market_value': 'sum'}).reset_index()
        total_mv = by_ac['market_value'].sum()
        if total_mv > 0:
            by_ac['pct'] = by_ac['market_value'] / total_mv * 100
            max_ac = by_ac.loc[by_ac['pct'].idxmax()]
            if max_ac['pct'] > 55:
                insights.append({
                    'type': 'actionable', 'severity': 'low', 'icon': '\u2696\ufe0f',
                    'title': f'{max_ac["asset_class"]}\u3078\u306e\u504f\u91cd',
                    'description': f'{max_ac["asset_class"]}\u304c\u30dd\u30fc\u30c8\u30d5\u30a9\u30ea\u30aa\u306e{max_ac["pct"]:.1f}%\u3092\u5360\u3081\u3066\u3044\u307e\u3059\u3002\u5206\u6563\u6295\u8cc7\u306e\u89b3\u70b9\u304b\u3089\u3001\u4ed6\u8cc7\u7523\u30af\u30e9\u30b9\u3078\u306e\u914d\u5206\u62e1\u5927\u3092\u691c\u8a0e\u3057\u3066\u3082\u3088\u3044\u304b\u3082\u3057\u308c\u307e\u305b\u3093\u3002',
                    'reasoning': '\u5358\u4e00\u8cc7\u7523\u30af\u30e9\u30b9\u304c55%\u8d85\u3092\u5360\u3081\u308b\u5834\u5408\u306b\u5206\u6563\u52b9\u679c\u306e\u4f4e\u4e0b\u3092\u8b66\u544a\u3002',
                    'evidence': {'asset_class': str(max_ac['asset_class']), 'share': f'{max_ac["pct"]:.1f}%'},
                })
        return insights

    def generate_summary_text(self, insights):
        if not insights:
            return '\u7279\u8a18\u3059\u3079\u304d\u30a4\u30f3\u30b5\u30a4\u30c8\u306f\u3042\u308a\u307e\u305b\u3093\u3002'
        high = [i for i in insights if i.get('severity') == 'high']
        medium = [i for i in insights if i.get('severity') == 'medium']
        lines = []
        if high:
            lines.append(f'\u26a0\ufe0f **\u91cd\u8981\u30a2\u30e9\u30fc\u30c8** ({len(high)}\u4ef6):')
            for h in high[:3]: lines.append(f'  - {h["title"]}')
        if medium:
            lines.append(f'\U0001f514 **\u6ce8\u610f\u4e8b\u9805** ({len(medium)}\u4ef6):')
            for m in medium[:3]: lines.append(f'  - {m["title"]}')
        lines.append(f'\n\u5408\u8a08 {len(insights)} \u4ef6\u306e\u30a4\u30f3\u30b5\u30a4\u30c8\u304c\u691c\u51fa\u3055\u308c\u307e\u3057\u305f\u3002')
        return '\n'.join(lines)