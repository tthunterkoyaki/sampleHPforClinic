﻿"""
trend_detector.py - トレンド検出・異常検知モジュール

統計的手法によるトレンド検出と変化点検出を行う。
BERTモデルは使用せず、純粋な統計的アプローチで
データの構造変化を検出する。

使用手法:
  - 線形回帰: 長期トレンドの方向性判定
  - CUSUM: 累積和による変化点検出
  - 移動平均乖離: 短期的な異常検出
"""
import pandas as pd
import numpy as np
from typing import Dict, List, Any, Optional, Tuple


class TrendDetector:
    """
    トレンド検出・異常検知エンジン

    統計的手法を用いて時系列データから
    トレンド、変化点、異常値を検出する。
    """

    def detect_change_points(self, series: pd.Series,
                              threshold: float = 1.5) -> List[Dict]:
        """
        CUSUM法による変化点検出。

        アルゴリズム:
          CUSUM (Cumulative Sum) は累積和の変化から
          時系列の平均レベルの変化を検出する手法。

          1. 系列の平均を計算
          2. 各時点の値と平均の差分を累積
          3. 累積和が閾値（標準偏差×threshold）を超えた点を変化点と判定

          CUSUM_t = Σ_{i=1}^{t} (x_i - μ)
          変化点: |CUSUM_t| > threshold × σ × √t

        Returns:
            変化点リスト。各要素に位置、方向、根拠を含む。
        """
        if len(series) < 5:
            return []

        values = series.values.astype(float)
        mean = np.mean(values)
        std = np.std(values)
        if std == 0:
            return []

        # 正方向CUSUM
        cusum_pos = np.zeros(len(values))
        cusum_neg = np.zeros(len(values))
        change_points = []

        for i in range(1, len(values)):
            cusum_pos[i] = max(0, cusum_pos[i-1] + (values[i] - mean) / std - 0.5)
            cusum_neg[i] = max(0, cusum_neg[i-1] - (values[i] - mean) / std - 0.5)

            if cusum_pos[i] > threshold:
                change_points.append({
                    'index': i,
                    'date': series.index[i] if hasattr(series.index[i], 'strftime') else str(series.index[i]),
                    'direction': 'up',
                    'strength': float(cusum_pos[i]),
                    'description': f'上方シフトを検出（CUSUM={cusum_pos[i]:.2f}）',
                    'evidence': {
                        'method': 'CUSUM（累積和）変化点検出',
                        'threshold': threshold,
                        'cusum_value': float(cusum_pos[i]),
                    }
                })
                cusum_pos[i] = 0  # リセット

            if cusum_neg[i] > threshold:
                change_points.append({
                    'index': i,
                    'date': series.index[i] if hasattr(series.index[i], 'strftime') else str(series.index[i]),
                    'direction': 'down',
                    'strength': float(cusum_neg[i]),
                    'description': f'下方シフトを検出（CUSUM={cusum_neg[i]:.2f}）',
                    'evidence': {
                        'method': 'CUSUM（累積和）変化点検出',
                        'threshold': threshold,
                        'cusum_value': float(cusum_neg[i]),
                    }
                })
                cusum_neg[i] = 0  # リセット

        return change_points

    def detect_regime_change(self, df: pd.DataFrame,
                              value_col: str = 'market_value') -> List[Dict]:
        """
        レジーム（局面）変化の検出。

        手法:
          データを前半・後半に分割し、各統計量を比較。
          平均と分散の有意な変化を検出する。

          判定基準:
            平均変化: |後半平均 - 前半平均| / 前半標準偏差 > 1.0
            分散変化: 後半分散 / 前半分散 > 2.0 または < 0.5
        """
        totals = df.groupby('date')[value_col].sum().sort_index()
        if len(totals) < 8:
            return []

        mid = len(totals) // 2
        first_half = totals.iloc[:mid].values
        second_half = totals.iloc[mid:].values

        changes = []

        # 平均レベルの変化
        mean1, mean2 = np.mean(first_half), np.mean(second_half)
        std1 = np.std(first_half) if np.std(first_half) > 0 else 1
        effect_size = abs(mean2 - mean1) / std1

        if effect_size > 1.0:
            direction = '上昇' if mean2 > mean1 else '低下'
            changes.append({
                'type': 'level_shift',
                'description': f'{value_col}の平均水準が{direction}しました（効果量={effect_size:.2f}）',
                'severity': 'medium' if effect_size > 2 else 'low',
                'evidence': {
                    'method': '期間二分割比較（コーエンのd相当）',
                    'first_half_mean': float(mean1),
                    'second_half_mean': float(mean2),
                    'effect_size': float(effect_size),
                    'interpretation': f'効果量{effect_size:.2f}は{"大きい" if effect_size > 2 else "中程度の"}変化',
                }
            })

        # ボラティリティの変化
        var1 = np.var(first_half) if np.var(first_half) > 0 else 1
        var2 = np.var(second_half)
        var_ratio = var2 / var1

        if var_ratio > 2.0 or var_ratio < 0.5:
            direction = '増大' if var_ratio > 1 else '縮小'
            changes.append({
                'type': 'volatility_shift',
                'description': f'{value_col}のボラティリティが{direction}しました（変化率={var_ratio:.2f}倍）',
                'severity': 'medium',
                'evidence': {
                    'method': '分散比検定（F検定相当）',
                    'first_half_variance': float(var1),
                    'second_half_variance': float(var2),
                    'variance_ratio': float(var_ratio),
                }
            })

        return changes

    def compute_trend_strength(self, series: pd.Series) -> Dict[str, Any]:
        """
        トレンドの強度を定量化する。

        手法:
          1. 線形回帰で傾き（β）を推定
          2. 決定係数（R²）でフィットの良さを評価
          3. 正規化傾き（β/平均値）でスケール非依存の比較を可能にする

        Returns:
            slope: 傾き（1期間あたりの変化量）
            r_squared: 決定係数（0-1、1に近いほど強いトレンド）
            normalized_slope: 平均値で正規化した傾き
            direction: 'up' / 'down' / 'flat'
            confidence: トレンドの確信度（R²ベース）
        """
        if len(series) < 3:
            return {'direction': 'flat', 'confidence': 0}

        x = np.arange(len(series))
        y = series.values.astype(float)

        if np.std(y) == 0:
            return {'direction': 'flat', 'slope': 0, 'r_squared': 0, 'confidence': 0}

        coeffs = np.polyfit(x, y, 1)
        slope = coeffs[0]

        y_pred = np.polyval(coeffs, x)
        ss_res = np.sum((y - y_pred) ** 2)
        ss_tot = np.sum((y - np.mean(y)) ** 2)
        r_squared = 1 - ss_res / ss_tot if ss_tot > 0 else 0

        mean_abs = np.mean(np.abs(y))
        norm_slope = slope / mean_abs if mean_abs > 0 else 0

        if r_squared > 0.3 and slope > 0:
            direction = 'up'
        elif r_squared > 0.3 and slope < 0:
            direction = 'down'
        else:
            direction = 'flat'

        return {
            'slope': float(slope),
            'r_squared': float(r_squared),
            'normalized_slope': float(norm_slope),
            'direction': direction,
            'confidence': float(min(r_squared * 1.5, 1.0)),
            'evidence': {
                'method': '最小二乗法線形回帰',
                'n_points': len(series),
                'slope_per_period': float(slope),
                'r_squared': float(r_squared),
            }
        }

    def forecast_simple(self, series: pd.Series, n_periods: int = 3) -> Dict[str, Any]:
        """
        シンプルな線形外挿予測。

        手法:
          線形回帰の延長線上で将来値を推定。
          ※ あくまで「現在のトレンドが続いた場合」の参考値。

        注意:
          この予測は過去トレンドの単純外挿であり、
          市場環境の変化、政策変更等は考慮していません。
          意思決定の参考情報としてのみ使用してください。
        """
        if len(series) < 4:
            return {'available': False}

        x = np.arange(len(series))
        y = series.values.astype(float)
        coeffs = np.polyfit(x, y, 1)

        future_x = np.arange(len(series), len(series) + n_periods)
        forecast = np.polyval(coeffs, future_x)

        # 信頼区間（残差の標準偏差ベース）
        y_pred = np.polyval(coeffs, x)
        residual_std = np.std(y - y_pred)

        return {
            'available': True,
            'forecast': [float(f) for f in forecast],
            'upper_bound': [float(f + 2 * residual_std) for f in forecast],
            'lower_bound': [float(f - 2 * residual_std) for f in forecast],
            'evidence': {
                'method': '線形外挿（最小二乗法）',
                'residual_std': float(residual_std),
                'caveat': '過去トレンドの単純外挿。市場環境変化は未考慮。',
                'n_historical': len(series),
                'n_forecast': n_periods,
            }
        }
