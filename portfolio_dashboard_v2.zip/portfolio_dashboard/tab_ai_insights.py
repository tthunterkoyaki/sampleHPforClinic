"""tab_ai_insights.py - AI分析タブ（テンプレ修正、インサイト強化、GenAI文言修正）"""
import streamlit as st
import pandas as pd
from portfolio_dashboard.ui_components import (
    render_insight_cards, fmt_hyakuman, fmt_pct, PLOTLY_LAYOUT
)

def render(monthly_df, security_df, insights, ig, ts, td, bert_mm, bert_available, data, show_evidence):
    ai_tabs = st.tabs(["📊 AIインサイト", "🔍 セマンティック検索", "🏷️ AI分類", "💬 AIアシスタント", "🔗 GenAI連携"])

    with ai_tabs[0]:
        st.markdown('<div class="section-header">🤖 AI インサイト</div>', unsafe_allow_html=True)
        st.markdown("""
        <div class="insight-card info">
            <div class="insight-title">ℹ️ AIインサイトの仕組み</div>
            <div class="insight-desc">
            <b>統計分析:</b> Zスコアによる外れ値検出、線形回帰によるトレンド分析、HHI（集中度指数）の計測<br>
            <b>ルールベース判定:</b> 構成比変化（前半/後半5%超の乖離）、インカム/キャピタル比率、含み損銘柄の検出<br>
            <b>重要度:</b> 🔴重要（閾値超過かつ複数要因）/ 🟡注意（単一閾値超過）/ 🟢参考 / 🔵情報<br>
            BERTモデル利用時はテキスト分類・センチメント分析の結果も加味されます。
            「🔍 AI根拠を表示」をONにすると、各インサイトの判定根拠と計算データを確認できます。
            </div>
        </div>
        """, unsafe_allow_html=True)
        if insights:
            st.markdown(ig.generate_summary_text(insights))
            st.markdown("---")
            sev_filter = st.multiselect("重要度フィルタ", options=['high','medium','low','info'],
                default=['high','medium','low','info'],
                format_func=lambda x: {'high':'🔴 重要','medium':'🟡 注意','low':'🟢 参考','info':'🔵 情報'}[x])
            filtered = [i for i in insights if i.get('severity','info') in sev_filter]
            render_insight_cards(filtered, show_evidence=show_evidence, max_display=20)
        else:
            st.info("データを読み込むとAIインサイトが生成されます。")

    with ai_tabs[1]:
        st.markdown('<div class="section-header">🔍 セマンティック検索</div>', unsafe_allow_html=True)
        st.markdown("BERTの多言語埋め込みモデルで銘柄を意味検索します。キーワードや文章で検索可能です。")
        if bert_available and bert_mm and data.has_security_data:
            st.markdown("**テンプレート:**")
            templates = ["リスクの高い銘柄", "為替ヘッジ付き外債", "高利回り銘柄", "残存が長い国内債券", "含み損が大きい銘柄"]
            tc = st.columns(len(templates))
            for idx, t in enumerate(templates):
                with tc[idx]:
                    if st.button(t, key=f"st_{idx}", use_container_width=True):
                        st.session_state['sem_search_input'] = t
                        st.rerun()
            sq = st.text_input("検索クエリ", placeholder="例: リスクの高い銘柄", key="sem_search_input")
            if sq:
                with st.spinner("セマンティック検索を実行中..."):
                    _run_semantic_search(sq, bert_mm, security_df)
        else:
            st.info("Level 2以上のデータとBERTモデルが必要です。")

    with ai_tabs[2]:
        st.markdown('<div class="section-header">🏷️ ゼロショットAI分類</div>', unsafe_allow_html=True)
        st.markdown("""BERTのゼロショット分類を使って、テキストを候補ラベルに自動分類します。
        手動では付与しにくい分類（リスク水準など）を試せます。""")
        if bert_available and bert_mm:
            st.markdown("**テンプレート:**")
            cls_templates = [
                ("リスク判定", "外貨建て社債ファンド ヘッジなし 残存10年", "低リスク,中リスク,高リスク"),
                ("流動性判定", "第370回利付国債 10年", "高流動性,中流動性,低流動性"),
                ("投資適格判定", "ソフトバンクG 第60回社債 利率1.8%", "投資適格,投機的,判定不能"),
            ]
            btc = st.columns(len(cls_templates))
            for idx, (name, text, labels) in enumerate(cls_templates):
                with btc[idx]:
                    if st.button(name, key=f"ct_{idx}", use_container_width=True):
                        st.session_state['cls_text_input'] = text
                        st.session_state['cls_labels_input'] = labels
                        st.rerun()
            cls_text = st.text_area("分類するテキスト",
                placeholder="例: 米国国債3年", height=80, key="cls_text_input")
            if 'cls_labels_input' not in st.session_state:
                st.session_state['cls_labels_input'] = '低リスク,中リスク,高リスク'
            cls_labels = st.text_input("候補ラベル（カンマ区切り）", key="cls_labels_input")
            if st.button("🏷️ 分類実行", key="cls_btn") and cls_text:
                _run_classification(cls_text, cls_labels, bert_mm)
        else:
            st.info("BERTモデルが必要です。")

    with ai_tabs[3]:
        st.markdown('<div class="section-header">💬 AIアシスタント</div>', unsafe_allow_html=True)
        st.markdown("""BERTベースの検索＋QAエンジンです。LLMではないため自由な会話はできませんが、
        銘柄データのセマンティック検索と関連情報の返答が可能です。テンプレート質問をご活用ください。""")
        if bert_available and bert_mm and data.has_security_data:
            try:
                emb = bert_mm.get_embedding_model()
            except Exception:
                emb = None
            if emb:
                from bert_assistant.qa import QAEngine
                from bert_assistant.search import SemanticSearchEngine
                se = SemanticSearchEngine(emb)
                text_cols = [c for c in ['security_name','category','issuer_name','industry'] if c in security_df.columns]
                se.index(security_df, text_columns=text_cols)
                qa = QAEngine(se, bert_mm)
                st.markdown("**よくある質問:**")
                suggestions = qa.get_suggested_questions(security_df)
                cols_q = st.columns(min(len(suggestions), 3))
                for idx, q in enumerate(suggestions[:3]):
                    with cols_q[idx]:
                        if st.button(q, key=f"sq_{idx}", use_container_width=True):
                            st.session_state['qa_input_f'] = q
                            st.rerun()
                st.markdown("**用語解説:**")
                kb_qs = ["デュレーション", "含み損益", "VaR", "金利リスク", "ALM"]
                kb_cols = st.columns(len(kb_qs))
                for idx, q in enumerate(kb_qs):
                    with kb_cols[idx]:
                        if st.button(q, key=f"kb_{idx}", use_container_width=True):
                            st.session_state['qa_input_f'] = q
                            st.rerun()
                user_q = st.text_input("質問を入力", placeholder="テンプレートボタンもご活用ください", key="qa_input_f")
                if user_q:
                    with st.spinner("回答を生成中..."):
                        answer = qa.ask(user_q)
                    st.markdown(
                        f'<div style="padding:0.8rem 1rem;border-radius:12px;margin:0.4rem 0;'
                        f'background:linear-gradient(135deg,rgba(59,130,246,0.08),rgba(139,92,246,0.05));'
                        f'border:1px solid rgba(59,130,246,0.15);font-size:0.9rem;">🧑 {user_q}</div>',
                        unsafe_allow_html=True)
                    st.markdown(answer['answer'])
                    if answer.get('confidence', 0) > 0:
                        st.caption(f"信頼度: {answer['confidence']*100:.0f}% | 手法: {answer.get('method','')}")
            else:
                st.warning("Embeddingモデルの読み込みに失敗しました。")
                if hasattr(bert_mm, 'get_error_details'):
                    errors = bert_mm.get_error_details()
                    if errors:
                        with st.expander("エラー詳細"):
                            for err_key, err_msg in errors.items():
                                st.code(err_msg, language="text")
                if st.button("🔄 モデルを再ロード", key="retry_emb_qa"):
                    bert_mm._models.pop('embedding', None)
                    bert_mm._status.pop('embedding', None)
                    if hasattr(bert_mm, '_errors'):
                        bert_mm._errors.pop('embedding', None)
                    st.rerun()
        else:
            st.info("Level 2以上のデータとBERTモデルが必要です。")

    with ai_tabs[4]:
        st.markdown('<div class="section-header">🔗 GenAI連携プロンプト生成</div>', unsafe_allow_html=True)
        st.markdown("分析データを社内生成AIに渡すための最適プロンプトを自動生成します。")
        from bert_assistant.bridge import GenAIBridge
        bridge = GenAIBridge(app_name='ポートフォリオダッシュボード')
        templates = bridge.get_template_names()
        sel = st.selectbox("テンプレート選択", templates, key="genai_template")
        ci = st.text_area("カスタム指示（任意）", height=80,
                           placeholder="例: 金利上昇50bpの影響を分析して", key="genai_custom")
        inc_ins = st.checkbox("AIインサイトを含める", value=True, key="genai_inc")
        mr = st.slider("データ行数上限", 10, 50, 25, key="genai_rows")
        if st.button("🚀 プロンプト生成", use_container_width=True, key="genai_gen"):
            target_df = security_df if data.has_security_data and security_df is not None else monthly_df
            prompt = bridge.generate_prompt(target_df, template_name=sel,
                insights=insights if inc_ins else None, custom_instruction=ci if ci else None, max_rows=mr)
            st.markdown(f"**生成プロンプト** ({len(prompt):,}文字)")
            st.text_area("コピー用", value=prompt, height=400, key="genai_out")
            st.download_button("📥 保存", data=prompt.encode('utf-8'), file_name="genai_prompt.txt",
                               mime="text/plain", key="genai_dl")
        st.markdown("---")
        st.markdown("**💡 おすすめの質問:**")
        target_df = security_df if data.has_security_data and security_df is not None else monthly_df
        for q in bridge.get_suggested_questions(target_df):
            st.markdown(f"- {q}")


def _run_semantic_search(query, bert_mm, security_df):
    try:
        from bert_assistant.search import SemanticSearchEngine
        emb = bert_mm.get_embedding_model()
        if emb:
            se = SemanticSearchEngine(emb)
            text_cols = [c for c in ['security_name','category','issuer_name','industry'] if c in security_df.columns]
            se.index(security_df, text_columns=text_cols)
            results = se.search(query, top_k=10)
            st.markdown(f"**{len(results)}件の関連銘柄:**")
            for i, res in enumerate(results):
                idx = res['index']
                score = res['score'] * 100
                if idx < len(security_df):
                    sr = security_df.iloc[idx]
                    nm = sr.get('security_name', f'銘柄{idx}')
                    cat = sr.get('category', '')
                    st.markdown(
                        f'<div class="insight-card info">'
                        f'<div class="insight-title">#{i+1} {nm}</div>'
                        f'<div class="insight-desc">関連度: <strong>{score:.0f}%</strong> | 分類: {cat}</div>'
                        f'<div style="height:4px;background:#e2e8f0;border-radius:2px;margin-top:6px;">'
                        f'<div style="height:100%;width:{int(score)}%;background:linear-gradient(90deg,#3b82f6,#8b5cf6);border-radius:2px;"></div>'
                        f'</div></div>', unsafe_allow_html=True)
        else:
            st.warning("Embeddingモデルの読み込みに失敗しました。")
            if hasattr(bert_mm, 'get_error_details'):
                errors = bert_mm.get_error_details()
                if errors:
                    with st.expander("エラー詳細"):
                        for err_key, err_msg in errors.items():
                            st.code(err_msg, language="text")
    except Exception as e:
        st.warning(f"検索エラー: {e}")


def _run_classification(text, labels_str, bert_mm):
    try:
        from bert_assistant.classify import ZeroShotClassifier
        pipe = bert_mm.get_classifier()
        if pipe is None:
            st.warning("分類モデルの読み込みに失敗しました。")
            if hasattr(bert_mm, 'get_error_details'):
                errors = bert_mm.get_error_details()
                if errors:
                    with st.expander("エラー詳細"):
                        for err_key, err_msg in errors.items():
                            st.code(err_msg, language="text")
            return
        zsc = ZeroShotClassifier(pipe)
        labels = [l.strip() for l in labels_str.split(',')]
        result = zsc.classify(text, labels)
        st.markdown("**分類結果:**")
        for lbl, scr in zip(result['all_labels'], result['all_scores']):
            pct = scr * 100
            color = '#10b981' if scr == max(result['all_scores']) else '#94a3b8'
            st.markdown(
                f'<div style="display:flex;align-items:center;gap:8px;margin:4px 0;">'
                f'<span style="min-width:100px;font-weight:600;color:#334155;">{lbl}</span>'
                f'<div style="flex:1;height:20px;background:#f1f5f9;border-radius:4px;overflow:hidden;">'
                f'<div style="height:100%;width:{pct}%;background:{color};border-radius:4px;"></div></div>'
                f'<span style="min-width:50px;text-align:right;font-weight:600;">{pct:.0f}%</span></div>',
                unsafe_allow_html=True)
    except Exception as e:
        st.warning(f"分類エラー: {e}")