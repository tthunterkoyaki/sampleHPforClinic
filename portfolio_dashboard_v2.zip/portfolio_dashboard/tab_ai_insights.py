"""tab_ai_insights.py - AI\u5206\u6790\u30bf\u30d6\uff08\u5168\u9762\u6539\u4fee\u7248\uff09"""
import streamlit as st
import pandas as pd

FOCUS_AREAS = {
    'risk_concentration': {'label': '\U0001f4ca \u30ea\u30b9\u30af\u96c6\u4e2d\u5ea6', 'desc': '\u7279\u5b9a\u9298\u67c4\u30fb\u30bb\u30af\u30bf\u30fc\u3078\u306e\u504f\u308a'},
    'unrealized_gl': {'label': '\U0001f4c9 \u8a55\u4fa1\u640d\u76ca\u306e\u50be\u5411', 'desc': '\u542b\u307f\u640d\u62e1\u5927\u4e2d\u306e\u9298\u67c4\u7fa4'},
    'income_efficiency': {'label': '\U0001f4b0 \u30a4\u30f3\u30ab\u30e0\u52b9\u7387', 'desc': '\u5229\u56de\u308a\u306e\u7570\u5e38\u5024\u30fb\u4f4e\u52b9\u7387\u9298\u67c4'},
    'maturity_risk': {'label': '\u23f0 \u6b8b\u5b58\u5e74\u6570\u30ea\u30b9\u30af', 'desc': '\u77ed\u671f\u96c6\u4e2d\u30fb\u9577\u671f\u504f\u91cd'},
    'fx_risk': {'label': '\U0001f30d \u70ba\u66ff\u30ea\u30b9\u30af', 'desc': '\u901a\u8ca8\u96c6\u4e2d\u5ea6'},
    'trend_anomaly': {'label': '\U0001f4c8 \u30c8\u30ec\u30f3\u30c9\u7570\u5e38', 'desc': '\u6708\u6b21\u5909\u52d5\u306e\u7570\u5e38\u691c\u77e5'},
}

_KEY_LABELS = {
    'market_value': '\u6642\u4fa1', 'unrealized_gl': '\u8a55\u4fa1\u640d\u76ca', 'yield_rate': '\u5229\u56de\u308a',
    'duration': '\u30c7\u30e5\u30ec\u30fc\u30b7\u30e7\u30f3', '\u6b8b\u5b58\u5e74\u6570': '\u6b8b\u5b58\u5e74\u6570', 'coupon_rate': '\u30af\u30fc\u30dd\u30f3',
}


def render(monthly_df, security_df, insights, ig, ts, td, bert_mm, bert_available, data, show_evidence):
    ai_tabs = st.tabs(["\U0001f4ca AI\u30a4\u30f3\u30b5\u30a4\u30c8", "\U0001f50d \u30bb\u30de\u30f3\u30c6\u30a3\u30c3\u30af\u691c\u7d22", "\U0001f3f7\ufe0f AI\u5206\u985e",
                        "\U0001f916 AI\u30a2\u30b7\u30b9\u30bf\u30f3\u30c8", "\U0001f517 GenAI\u9023\u643a"])

    # -- Tab 1: AI\u30a4\u30f3\u30b5\u30a4\u30c8\uff08\u89b3\u70b9\u9078\u629e\u4ed8\u304d\uff09 --
    with ai_tabs[0]:
        st.markdown('<div class="section-header">\U0001f4a1 AI\u30a4\u30f3\u30b5\u30a4\u30c8</div>', unsafe_allow_html=True)
        st.markdown("\u5206\u6790\u3057\u305f\u3044\u89b3\u70b9\u3092\u9078\u629e\u3057\u3066\u304f\u3060\u3055\u3044\u3002AI\u304c\u30c7\u30fc\u30bf\u304b\u3089\u81ea\u52d5\u7684\u306b\u30a4\u30f3\u30b5\u30a4\u30c8\u3092\u62bd\u51fa\u3057\u307e\u3059\u3002")

        col_sel, col_btn = st.columns([5, 1])
        with col_sel:
            selected = st.multiselect(
                "\u5206\u6790\u89b3\u70b9\u3092\u9078\u629e",
                options=list(FOCUS_AREAS.keys()),
                default=list(FOCUS_AREAS.keys()),
                format_func=lambda x: FOCUS_AREAS[x]['label'],
                key="focus_areas"
            )
        with col_btn:
            st.markdown("<br>", unsafe_allow_html=True)
            if st.button("\u5168\u9078\u629e", key="select_all_focus", use_container_width=True):
                st.session_state['focus_areas'] = list(FOCUS_AREAS.keys())
                st.rerun()

        if selected:
            chips = ' '.join([
                f'<span style="display:inline-block;padding:2px 10px;margin:2px;'
                f'background:linear-gradient(135deg,rgba(59,130,246,0.1),rgba(139,92,246,0.08));'
                f'border:1px solid rgba(59,130,246,0.2);border-radius:20px;font-size:0.8rem;">'
                f'{FOCUS_AREAS[k]["label"]}</span>' for k in selected])
            st.markdown(chips, unsafe_allow_html=True)

        if st.button("\U0001f504 \u30a4\u30f3\u30b5\u30a4\u30c8\u751f\u6210", use_container_width=True, key="gen_insights"):
            with st.spinner("\u30a4\u30f3\u30b5\u30a4\u30c8\u3092\u5206\u6790\u4e2d..."):
                new_insights = ig.generate_insights(monthly_df, security_df, td,
                                                     focus_areas=selected if selected else None)
                st.session_state['filtered_insights'] = new_insights

        display_insights = st.session_state.get('filtered_insights', insights)

        if display_insights:
            st.markdown(f"**{len(display_insights)}\u4ef6** \u306e\u30a4\u30f3\u30b5\u30a4\u30c8\u304c\u898b\u3064\u304b\u308a\u307e\u3057\u305f")
            for ins in display_insights:
                sev = ins.get('severity', 'info')
                sev_colors = {'high': '#ef4444', 'medium': '#f59e0b', 'low': '#3b82f6', 'info': '#6b7280'}
                sev_labels = {'high': '\u91cd\u8981', 'medium': '\u6ce8\u610f', 'low': '\u53c2\u8003', 'info': '\u60c5\u5831'}
                color = sev_colors.get(sev, '#6b7280')
                badge = sev_labels.get(sev, '\u60c5\u5831')
                icon = ins.get('icon', '\U0001f4a1')
                st.markdown(
                    f'<div class="insight-card {sev}" style="border-left:4px solid {color};">'
                    f'<div class="insight-title">{icon} {ins["title"]} '
                    f'<span style="font-size:0.7rem;padding:2px 8px;border-radius:10px;'
                    f'background:{color}20;color:{color};font-weight:600;">{badge}</span></div>'
                    f'<div class="insight-desc">{ins["description"]}</div>'
                    f'</div>', unsafe_allow_html=True)
                evidence = ins.get('evidence', {})
                reasoning = ins.get('reasoning', '')
                if evidence or reasoning:
                    with st.expander("\U0001f4cb \u6839\u62e0\u30c7\u30fc\u30bf", expanded=show_evidence):
                        if reasoning:
                            st.markdown(f"**\u5206\u6790\u6839\u62e0:** {reasoning}")
                        if isinstance(evidence, dict) and evidence:
                            ev_items = []
                            for k, v in evidence.items():
                                if isinstance(v, float):
                                    ev_items.append(f"**{k}**: {v:,.2f}")
                                elif isinstance(v, list):
                                    ev_items.append(f"**{k}**: {', '.join(str(x) for x in v[:5])}")
                                else:
                                    ev_items.append(f"**{k}**: {v}")
                            st.markdown(' | '.join(ev_items))
        else:
            st.info("\u300c\u30a4\u30f3\u30b5\u30a4\u30c8\u751f\u6210\u300d\u30dc\u30bf\u30f3\u3092\u62bc\u3057\u3066\u5206\u6790\u3092\u958b\u59cb\u3057\u3066\u304f\u3060\u3055\u3044\u3002")

    # -- Tab 2: \u30bb\u30de\u30f3\u30c6\u30a3\u30c3\u30af\u691c\u7d22 --
    with ai_tabs[1]:
        st.markdown('<div class="section-header">\U0001f50d \u30bb\u30de\u30f3\u30c6\u30a3\u30c3\u30af\u691c\u7d22</div>', unsafe_allow_html=True)
        st.markdown("BERT\u306e\u591a\u8a00\u8a9e\u57cb\u3081\u8fbc\u307f\u30e2\u30c7\u30eb\u3067\u9298\u67c4\u3092\u610f\u5473\u691c\u7d22\u3057\u307e\u3059\u3002**\u5404\u7d50\u679c\u306b\u30de\u30c3\u30c1\u6839\u62e0\u3092\u8868\u793a**\u3057\u307e\u3059\u3002")
        if bert_available and data.has_security_data and security_df is not None:
            st.markdown("**\u30c6\u30f3\u30d7\u30ec\u30fc\u30c8:**")
            templates = ['\u30ea\u30b9\u30af\u306e\u9ad8\u3044\u9298\u67c4', '\u70ba\u66ff\u30d8\u30c3\u30b8\u4ed8\u304d\u5916\u50b5', '\u9ad8\u5229\u56de\u308a\u9298\u67c4', '\u6b8b\u5b58\u304c\u9577\u3044\u56fd\u5185\u50b5\u5238', '\u542b\u307f\u640d\u304c\u5927\u304d\u3044\u9298\u67c4']
            tcols = st.columns(len(templates))
            for idx, t in enumerate(templates):
                with tcols[idx]:
                    if st.button(t, key=f"tpl_{idx}", use_container_width=True):
                        st.session_state['search_query_f'] = t
                        st.rerun()
            query = st.text_input("\u691c\u7d22\u30af\u30a8\u30ea", placeholder="\u30ad\u30fc\u30ef\u30fc\u30c9\u3084\u6587\u7ae0\u3067\u691c\u7d22", key="search_query_f")
            if query:
                with st.spinner("\u691c\u7d22\u4e2d..."):
                    _run_semantic_search(query, bert_mm, security_df, show_evidence)
        else:
            st.info("Level 2\u4ee5\u4e0a\u306e\u30c7\u30fc\u30bf\u3068BERT\u30e2\u30c7\u30eb\u304c\u5fc5\u8981\u3067\u3059\u3002")

    # -- Tab 3: AI\u5206\u985e --
    with ai_tabs[2]:
        st.markdown('<div class="section-header">\U0001f3f7\ufe0f \u30bc\u30ed\u30b7\u30e7\u30c3\u30c8AI\u5206\u985e</div>', unsafe_allow_html=True)
        st.markdown("\u5168\u9298\u67c4\u3092\u4e00\u62ec\u3067\u30ea\u30b9\u30af\u30d7\u30ed\u30d5\u30a1\u30a4\u30ea\u30f3\u30b0\u3057\u307e\u3059\u3002\u30bc\u30ed\u30b7\u30e7\u30c3\u30c8\u5b66\u7fd2\u306b\u3088\u308a\u3001**\u4e8b\u524d\u5b66\u7fd2\u306a\u3057\u3067**\u4efb\u610f\u306e\u30ab\u30c6\u30b4\u30ea\u306b\u5206\u985e\u3067\u304d\u307e\u3059\u3002")
        if bert_available and data.has_security_data and security_df is not None:
            from bert_assistant.classify import ZeroShotClassifier, RISK_PROFILES
            pipe = bert_mm.get_classifier()
            tab_preset, tab_custom = st.tabs(["\U0001f3af \u30d7\u30ea\u30bb\u30c3\u30c8\u5206\u985e", "\u270f\ufe0f \u30ab\u30b9\u30bf\u30e0\u5206\u985e"])
            with tab_preset:
                profile_type = st.selectbox("\u30ea\u30b9\u30af\u5206\u985e\u30bf\u30a4\u30d7", list(RISK_PROFILES.keys()), key="profile_type")
                st.markdown(f"**\u5206\u985e\u30e9\u30d9\u30eb:** {', '.join(RISK_PROFILES[profile_type])}")
                n_sec = len(security_df)
                est = max(1, n_sec * 2)
                st.caption(f"\u5bfe\u8c61: {n_sec}\u9298\u67c4 | \u63a8\u5b9a\u51e6\u7406\u6642\u9593: \u7d04{est}\u79d2")
                if st.button(f"\U0001f680 {profile_type}\u3067\u5168\u9298\u67c4\u3092\u5206\u985e", use_container_width=True, key="run_profile"):
                    if pipe is None:
                        st.warning("\u5206\u985e\u30e2\u30c7\u30eb\u306e\u8aad\u307f\u8fbc\u307f\u306b\u5931\u6557\u3057\u307e\u3057\u305f\u3002")
                    else:
                        zsc = ZeroShotClassifier(pipe)
                        progress = st.progress(0, text="\u5206\u985e\u958b\u59cb...")
                        def update_progress(pct, txt):
                            progress.progress(pct, text=txt)
                        text_col = 'security_name' if 'security_name' in security_df.columns else security_df.columns[0]
                        result_df, results = zsc.risk_profile(security_df, text_column=text_col,
                                                              profile_type=profile_type, progress_callback=update_progress)
                        progress.progress(1.0, text="\u5b8c\u4e86\uff01")
                        st.session_state['classification_result'] = (result_df, profile_type)
                if 'classification_result' in st.session_state:
                    result_df, ptype = st.session_state['classification_result']
                    st.markdown(f"### \U0001f4ca {ptype} \u5206\u985e\u7d50\u679c")
                    dist = result_df[ptype].value_counts()
                    scols = st.columns(len(dist))
                    colors = ['#ef4444', '#f59e0b', '#10b981']
                    for i, (label, count) in enumerate(dist.items()):
                        with scols[i % len(scols)]:
                            c = colors[i % len(colors)]
                            st.markdown(
                                f'<div style="text-align:center;padding:12px;border-radius:12px;'
                                f'background:{c}10;border:1px solid {c}30;">'
                                f'<div style="font-size:1.5rem;font-weight:700;color:{c};">{count}</div>'
                                f'<div style="font-size:0.8rem;color:#64748b;">{label}</div></div>',
                                unsafe_allow_html=True)
                    show_cols = [c for c in ['security_name','asset_class', ptype, f'{ptype}_\u78ba\u4fe1\u5ea6'] if c in result_df.columns]
                    st.dataframe(result_df[show_cols].sort_values(f'{ptype}_\u78ba\u4fe1\u5ea6', ascending=False),
                                 use_container_width=True, height=400)
                    if pipe:
                        zsc2 = ZeroShotClassifier(pipe)
                        anomalies = zsc2.detect_anomalies(result_df, ptype)
                        if anomalies:
                            st.markdown("### \u26a0\ufe0f \u77db\u76fe\u691c\u51fa")
                            st.markdown("\u5206\u985e\u7d50\u679c\u3068\u5b9f\u30c7\u30fc\u30bf\u304c\u77db\u76fe\u3059\u308b\u9298\u67c4\u3067\u3059\uff1a")
                            for a in anomalies:
                                st.markdown(
                                    f'<div class="insight-card medium">'
                                    f'<div class="insight-title">\u26a0\ufe0f {a["name"]}</div>'
                                    f'<div class="insight-desc">{a["reason"]}</div></div>',
                                    unsafe_allow_html=True)
            with tab_custom:
                st.markdown("\u4efb\u610f\u306e\u30e9\u30d9\u30eb\u3067\u5168\u9298\u67c4\u3092\u4e00\u62ec\u5206\u985e\u3057\u307e\u3059\u3002")
                custom_labels = st.text_input("\u30ab\u30b9\u30bf\u30e0\u30e9\u30d9\u30eb\uff08\u30ab\u30f3\u30de\u533a\u5207\u308a\uff09",
                    value="\u56fd\u50b5, \u793e\u50b5, \u6295\u8cc7\u4fe1\u8a17, \u682a\u5f0f, REIT", key="custom_labels_batch")
                if st.button("\U0001f680 \u30ab\u30b9\u30bf\u30e0\u5206\u985e\u3092\u5b9f\u884c", use_container_width=True, key="run_custom_batch"):
                    if pipe is None:
                        st.warning("\u5206\u985e\u30e2\u30c7\u30eb\u306e\u8aad\u307f\u8fbc\u307f\u306b\u5931\u6557\u3057\u307e\u3057\u305f\u3002")
                    else:
                        labels = [l.strip() for l in custom_labels.split(',')]
                        zsc = ZeroShotClassifier(pipe)
                        progress = st.progress(0, text="\u5206\u985e\u958b\u59cb...")
                        text_col = 'security_name' if 'security_name' in security_df.columns else security_df.columns[0]
                        result_df, results = zsc.classify_dataframe(
                            security_df, text_col, labels, result_column='\u30ab\u30b9\u30bf\u30e0\u5206\u985e',
                            progress_callback=lambda p, t: progress.progress(p, text=t))
                        progress.progress(1.0, text="\u5b8c\u4e86\uff01")
                        dist = result_df['\u30ab\u30b9\u30bf\u30e0\u5206\u985e'].value_counts()
                        st.markdown("### \U0001f4ca \u30ab\u30b9\u30bf\u30e0\u5206\u985e\u7d50\u679c")
                        for label, count in dist.items():
                            pct = count / len(result_df) * 100
                            st.markdown(
                                f'<div style="display:flex;align-items:center;gap:8px;margin:4px 0;">'
                                f'<span style="min-width:120px;font-weight:600;">{label}</span>'
                                f'<div style="flex:1;height:22px;background:#f1f5f9;border-radius:4px;overflow:hidden;">'
                                f'<div style="height:100%;width:{pct}%;background:linear-gradient(90deg,#3b82f6,#8b5cf6);'
                                f'border-radius:4px;display:flex;align-items:center;padding-left:6px;'
                                f'color:white;font-size:0.75rem;font-weight:600;">{count}\u4ef6</div></div>'
                                f'<span style="min-width:50px;text-align:right;font-weight:600;">{pct:.0f}%</span></div>',
                                unsafe_allow_html=True)
                        show_cols = [c for c in ['security_name','asset_class','\u30ab\u30b9\u30bf\u30e0\u5206\u985e','\u30ab\u30b9\u30bf\u30e0\u5206\u985e_\u78ba\u4fe1\u5ea6'] if c in result_df.columns]
                        st.dataframe(result_df[show_cols].sort_values('\u30ab\u30b9\u30bf\u30e0\u5206\u985e_\u78ba\u4fe1\u5ea6', ascending=False),
                                     use_container_width=True, height=400)
        else:
            st.info("Level 2\u4ee5\u4e0a\u306e\u30c7\u30fc\u30bf\u3068BERT\u30e2\u30c7\u30eb\u304c\u5fc5\u8981\u3067\u3059\u3002")

    # -- Tab 4: AI\u30a2\u30b7\u30b9\u30bf\u30f3\u30c8 --
    with ai_tabs[3]:
        st.markdown('<div class="section-header">\U0001f916 AI\u30a2\u30b7\u30b9\u30bf\u30f3\u30c8</div>', unsafe_allow_html=True)
        st.markdown("\u30dd\u30fc\u30c8\u30d5\u30a9\u30ea\u30aa\u30c7\u30fc\u30bf\u306b\u57fa\u3065\u3044\u3066\u8cea\u554f\u306b\u56de\u7b54\u3057\u307e\u3059\u3002**\u56de\u7b54\u306e\u6839\u62e0\u3068\u306a\u3063\u305f\u9298\u67c4\u30c7\u30fc\u30bf**\u3092\u8868\u793a\u3057\u307e\u3059\u3002")
        if bert_available and data.has_security_data and security_df is not None:
            emb = bert_mm.get_embedding_model()
            if emb:
                from bert_assistant.search import SemanticSearchEngine
                from bert_assistant.qa import QAEngine
                se = SemanticSearchEngine(emb)
                text_cols = [c for c in ['security_name','category','issuer_name','industry'] if c in security_df.columns]
                se.index(security_df, text_columns=text_cols)
                qa = QAEngine(se, bert_mm)
                st.markdown("**\u3088\u304f\u3042\u308b\u8cea\u554f:**")
                suggestions = qa.get_suggested_questions(security_df)
                cols_q = st.columns(min(len(suggestions), 3))
                for idx, q in enumerate(suggestions[:3]):
                    with cols_q[idx]:
                        if st.button(q, key=f"sq_{idx}", use_container_width=True):
                            st.session_state['qa_input_f'] = q
                            st.rerun()
                st.markdown("**\u7528\u8a9e\u96c6:**")
                kb_qs = ["\u30c7\u30e5\u30ec\u30fc\u30b7\u30e7\u30f3", "\u542b\u307f\u640d\u76ca", "VaR", "\u91d1\u5229\u30ea\u30b9\u30af", "ALM"]
                kb_cols = st.columns(len(kb_qs))
                for idx, q in enumerate(kb_qs):
                    with kb_cols[idx]:
                        if st.button(q, key=f"kb_{idx}", use_container_width=True):
                            st.session_state['qa_input_f'] = q
                            st.rerun()
                user_q = st.text_input("\u8cea\u554f", placeholder="\u30c6\u30f3\u30d7\u30ec\u30fc\u30c8\u307e\u305f\u306f\u81ea\u7531\u306b\u5165\u529b", key="qa_input_f")
                if user_q:
                    with st.spinner("\u56de\u7b54\u3092\u751f\u6210\u4e2d..."):
                        answer = qa.ask(user_q)
                    st.markdown(
                        f'<div style="padding:0.8rem 1rem;border-radius:12px;margin:0.4rem 0;'
                        f'background:linear-gradient(135deg,rgba(59,130,246,0.08),rgba(139,92,246,0.05));'
                        f'border:1px solid rgba(59,130,246,0.15);font-size:0.9rem;">\U0001f4ac {user_q}</div>',
                        unsafe_allow_html=True)
                    conf = answer.get('confidence', 0)
                    if conf > 0.7:
                        conf_label, conf_color = '\u9ad8\u4fe1\u983c', '#10b981'
                    elif conf > 0.4:
                        conf_label, conf_color = '\u4e2d\u4fe1\u983c', '#f59e0b'
                    else:
                        conf_label, conf_color = '\u4f4e\u4fe1\u983c', '#ef4444'
                    st.markdown(
                        f'<span style="font-size:0.75rem;padding:2px 10px;border-radius:10px;'
                        f'background:{conf_color}15;color:{conf_color};font-weight:600;border:1px solid {conf_color}30;">'
                        f'{conf_label} ({conf*100:.0f}%) | {answer.get("method","")}</span>',
                        unsafe_allow_html=True)
                    st.markdown(answer['answer'])
                    evidence = answer.get('evidence', [])
                    if evidence:
                        with st.expander(f"\U0001f4cb \u53c2\u7167\u9298\u67c4\u30c7\u30fc\u30bf ({len(evidence)}\u4ef6)", expanded=show_evidence):
                            for i, ev in enumerate(evidence):
                                sp = ev['score'] * 100
                                st.markdown(f"**#{i+1} {ev['name']}** (\u95a2\u9023\u5ea6: {sp:.0f}%)")
                                if ev.get('matched_fields'):
                                    mf_html = ' '.join([
                                        f'<span style="display:inline-block;padding:1px 8px;margin:1px;'
                                        f'background:rgba(59,130,246,0.1);border-radius:12px;font-size:0.75rem;">'
                                        f'\u2713 {mf["field"]}: {mf["value"]}</span>'
                                        for mf in ev['matched_fields'][:3]])
                                    st.markdown(f"\u30de\u30c3\u30c1\u6839\u62e0: {mf_html}", unsafe_allow_html=True)
                                if ev.get('key_data'):
                                    kd_parts = [f"{_KEY_LABELS.get(k,k)}: {v:,.2f}" for k,v in ev['key_data'].items()]
                                    st.caption(' | '.join(kd_parts))
                                st.markdown("---")
            else:
                st.warning("Embedding\u30e2\u30c7\u30eb\u306e\u8aad\u307f\u8fbc\u307f\u306b\u5931\u6557\u3057\u307e\u3057\u305f\u3002")
                if st.button("\U0001f504 \u30e2\u30c7\u30eb\u30ea\u30ed\u30fc\u30c9", key="retry_emb_qa"):
                    bert_mm._models.pop('embedding', None)
                    bert_mm._status.pop('embedding', None)
                    if hasattr(bert_mm, '_errors'):
                        bert_mm._errors.pop('embedding', None)
                    st.rerun()
        else:
            st.info("Level 2\u4ee5\u4e0a\u306e\u30c7\u30fc\u30bf\u3068BERT\u30e2\u30c7\u30eb\u304c\u5fc5\u8981\u3067\u3059\u3002")

    # -- Tab 5: GenAI\u9023\u643a --
    with ai_tabs[4]:
        st.markdown('<div class="section-header">\U0001f517 GenAI\u9023\u643a\u30d7\u30ed\u30f3\u30d7\u30c8</div>', unsafe_allow_html=True)
        st.markdown("\u30dd\u30fc\u30c8\u30d5\u30a9\u30ea\u30aa\u30c7\u30fc\u30bf\u3092\u5916\u90e8AI\u5411\u3051\u306b\u6700\u9069\u306a\u30d7\u30ed\u30f3\u30d7\u30c8\u3068\u3057\u3066\u6574\u5f62\u3057\u307e\u3059\u3002")
        from bert_assistant.bridge import GenAIBridge
        bridge = GenAIBridge(app_name='\u30dd\u30fc\u30c8\u30d5\u30a9\u30ea\u30aa\u30c0\u30c3\u30b7\u30e5\u30dc\u30fc\u30c9')
        templates = bridge.get_template_names()
        sel = st.selectbox("\u30c6\u30f3\u30d7\u30ec\u30fc\u30c8\u9078\u629e", templates, key="genai_template")
        ci = st.text_area("\u30ab\u30b9\u30bf\u30e0\u6307\u793a\uff08\u4efb\u610f\uff09", height=80,
                           placeholder="\u4f8b: \u91d1\u5229\u4e0a\u660750bp\u306e\u5f71\u97ff\u3092\u5206\u6790\u3057\u3066", key="genai_custom")
        inc_ins = st.checkbox("AI\u30a4\u30f3\u30b5\u30a4\u30c8\u3082\u542b\u3081\u308b", value=True, key="genai_inc")
        mr = st.slider("\u30c7\u30fc\u30bf\u884c\u6570\u4e0a\u9650", 10, 50, 25, key="genai_rows")
        if st.button("\U0001f680 \u30d7\u30ed\u30f3\u30d7\u30c8\u751f\u6210", use_container_width=True, key="genai_gen"):
            target_df = security_df if data.has_security_data and security_df is not None else monthly_df
            prompt = bridge.generate_prompt(target_df, template_name=sel,
                insights=insights if inc_ins else None, custom_instruction=ci if ci else None, max_rows=mr)
            st.markdown(f"**\u30d7\u30ed\u30f3\u30d7\u30c8** ({len(prompt):,}\u6587\u5b57)")
            st.text_area("\u30b3\u30d4\u30fc\u7528", value=prompt, height=400, key="genai_out")
            st.download_button("\U0001f4be \u4fdd\u5b58", data=prompt.encode('utf-8'), file_name="genai_prompt.txt",
                               mime="text/plain", key="genai_dl")
        st.markdown("---")
        st.markdown("**\U0001f4a1 \u304a\u3059\u3059\u3081\u306e\u8cea\u554f:**")
        target_df = security_df if data.has_security_data and security_df is not None else monthly_df
        for q in bridge.get_suggested_questions(target_df):
            st.markdown(f"- {q}")


def _run_semantic_search(query, bert_mm, security_df, show_evidence):
    try:
        from bert_assistant.search import SemanticSearchEngine
        emb = bert_mm.get_embedding_model()
        if emb:
            se = SemanticSearchEngine(emb)
            text_cols = [c for c in ['security_name','category','issuer_name','industry'] if c in security_df.columns]
            se.index(security_df, text_columns=text_cols)
            results = se.search(query, top_k=10)
            st.markdown(f"**{len(results)}\u4ef6** \u306e\u95a2\u9023\u9298\u67c4:")
            for i, res in enumerate(results):
                idx = res['index']
                score = res['score'] * 100
                if idx < len(security_df):
                    sr = security_df.iloc[idx]
                    nm = sr.get('security_name', f'\u9298\u67c4{idx}')
                    cat = sr.get('category', '')
                    mv = sr.get('market_value', None)
                    gl = sr.get('unrealized_gl', None)
                    mv_str = f" | \u6642\u4fa1: {mv:,.1f}" if mv is not None and pd.notna(mv) else ""
                    gl_str = f" | \u8a55\u4fa1\u640d\u76ca: {gl:,.1f}" if gl is not None and pd.notna(gl) else ""
                    st.markdown(
                        f'<div class="insight-card info" style="border-left:3px solid '
                        f'{"#10b981" if score > 60 else "#f59e0b" if score > 40 else "#94a3b8"};">'
                        f'<div class="insight-title">#{i+1} {nm}</div>'
                        f'<div class="insight-desc">\u95a2\u9023\u5ea6: <strong>{score:.0f}%</strong> | \u5206\u985e: {cat}{mv_str}{gl_str}</div>'
                        f'<div style="height:4px;background:#e2e8f0;border-radius:2px;margin-top:6px;">'
                        f'<div style="height:100%;width:{int(score)}%;background:linear-gradient(90deg,#3b82f6,#8b5cf6);border-radius:2px;"></div>'
                        f'</div></div>', unsafe_allow_html=True)
                    matched = res.get('matched_fields', [])
                    field_scores = res.get('field_scores', {})
                    if matched or field_scores:
                        with st.expander(f"\U0001f4cb \u30de\u30c3\u30c1\u6839\u62e0", expanded=show_evidence):
                            if matched:
                                st.markdown("**\u30de\u30c3\u30c1\u3057\u305f\u30d5\u30a3\u30fc\u30eb\u30c9:**")
                                for mf in matched:
                                    bar_w = int(mf['score'] * 100)
                                    st.markdown(
                                        f'<div style="display:flex;align-items:center;gap:8px;margin:2px 0;">'
                                        f'<span style="min-width:80px;font-size:0.8rem;color:#475569;">\u2713 {mf["field"]}</span>'
                                        f'<span style="font-weight:600;font-size:0.85rem;">{mf["value"]}</span>'
                                        f'<div style="flex:1;height:6px;background:#e2e8f0;border-radius:3px;">'
                                        f'<div style="height:100%;width:{bar_w}%;background:#3b82f6;border-radius:3px;"></div></div>'
                                        f'<span style="font-size:0.75rem;color:#94a3b8;">{mf["score"]*100:.0f}%</span></div>',
                                        unsafe_allow_html=True)
                            if field_scores:
                                st.markdown("**\u5168\u30d5\u30a3\u30fc\u30eb\u30c9\u30b9\u30b3\u30a2:**")
                                for field, fs in sorted(field_scores.items(), key=lambda x: x[1], reverse=True):
                                    bar_w = int(fs * 100)
                                    color = '#3b82f6' if fs > 0.4 else '#cbd5e1'
                                    st.markdown(
                                        f'<div style="display:flex;align-items:center;gap:6px;margin:1px 0;font-size:0.8rem;">'
                                        f'<span style="min-width:80px;color:#64748b;">{field}</span>'
                                        f'<div style="flex:1;height:4px;background:#f1f5f9;border-radius:2px;">'
                                        f'<div style="height:100%;width:{bar_w}%;background:{color};border-radius:2px;"></div></div>'
                                        f'<span style="min-width:35px;text-align:right;color:#94a3b8;">{fs*100:.0f}%</span></div>',
                                        unsafe_allow_html=True)
        else:
            st.warning("Embedding\u30e2\u30c7\u30eb\u306e\u8aad\u307f\u8fbc\u307f\u306b\u5931\u6557\u3057\u307e\u3057\u305f\u3002")
    except Exception as e:
        st.warning(f"\u30a8\u30e9\u30fc: {e}")
