"""tab_analysis.py - 分析タブ（時系列+収益統合、小タブ分割）"""
import streamlit as st
import plotly.graph_objects as go
import pandas as pd
from portfolio_dashboard.ui_components import (
    render_kpi_cards, render_insight_cards, create_stacked_bar_chart,
    create_waterfall_chart, fmt_oku, fmt_pct, fmt_hyakuman, PLOTLY_LAYOUT, hex_to_rgba,
    apply_jp_xaxis, order_asset_classes, get_asset_color, ASSET_CLASS_ORDER, COLORS
)
from portfolio_dashboard.analytics.portfolio_analytics import (
    compute_transaction_summary, export_to_excel
)
from portfolio_dashboard.analytics.time_series import TimeSeriesAnalyzer

# Layout without legend/xaxis/yaxis keys (to allow per-chart customization)
CHART_LAYOUT = {k:v for k,v in PLOTLY_LAYOUT.items() if k not in ("legend", "xaxis", "yaxis")}
CHART_LAYOUT["margin"] = dict(l=40, r=80, t=60, b=40)
CHART_LEGEND = dict(orientation="v", yanchor="top", y=1, xanchor="left", x=1.02, font=dict(size=9, color="#334155"))

def render(monthly_df, data, income_breakdown, transaction_df, ts, show_evidence):
    ib = income_breakdown
    ordered_classes = order_asset_classes(data.asset_classes)
    comp_ts = ts.compute_composition_changes(monthly_df)
    totals = ts.compute_period_totals(monthly_df)
    bm = ib["by_month"]
    ba = ib["by_asset"]
    ba_ordered = ba.copy()
    ba_ordered["_o"] = ba_ordered["asset_class"].map({c:i for i,c in enumerate(ASSET_CLASS_ORDER)})
    ba_ordered = ba_ordered.sort_values("_o").drop(columns=["_o"], errors="ignore")

    sub_tabs = st.tabs(["\U0001f4c8 資産推移", "\U0001f4ca 月次収益", "\U0001f3e6 資産クラス別収益", "\U0001f50d トレンド・異常検出"])

    with sub_tabs[0]:
        st.markdown('<div class="section-header">\U0001f4c8 資産クラス別時価推移</div>', unsafe_allow_html=True)
        fig_stack = go.Figure()
        for cat in ordered_classes:
            cd = comp_ts[comp_ts["asset_class"] == cat]
            fig_stack.add_trace(go.Bar(x=cd["date"], y=cd["market_value"], name=cat,
                marker_color=get_asset_color(cat),
                hovertemplate=f'{cat}: %{{y:,.1f}}<extra></extra>'))
        fig_stack.update_layout(**CHART_LAYOUT, height=440, barmode="stack", legend=CHART_LEGEND,
            title=dict(text='資産クラス別時価推移（積み上げ）', font=dict(size=14, color="#0f172a")))
        apply_jp_xaxis(fig_stack, sorted(comp_ts["date"].unique()))
        st.plotly_chart(fig_stack, use_container_width=True)

        fig_pct = go.Figure()
        for ac in ordered_classes:
            acd = comp_ts[comp_ts["asset_class"] == ac]
            fig_pct.add_trace(go.Bar(x=acd["date"], y=acd["composition_pct"], name=ac,
                marker_color=get_asset_color(ac), hovertemplate=f'{ac}: %{{y:.1f}}%<extra></extra>'))
        fig_pct.update_layout(**CHART_LAYOUT, height=350, barmode="stack", legend=CHART_LEGEND,
            title=dict(text='構成比推移(%)', font=dict(size=14, color="#0f172a")),
            yaxis=dict(title='%', range=[0, 100], gridcolor="#e2e8f0"))
        apply_jp_xaxis(fig_pct, sorted(comp_ts["date"].unique()))
        st.plotly_chart(fig_pct, use_container_width=True)

        cum = ts.compute_cumulative_returns(monthly_df)
        fig_cum = go.Figure()
        fig_cum.add_trace(go.Scatter(x=cum["date"], y=(cum["index_income"] - 100), name="インカム",
            fill="tozeroy", fillcolor=hex_to_rgba("#10b981", 0.15),
            line=dict(color="#10b981", width=2.5), mode="lines+markers", marker=dict(size=4),
            hovertemplate='インカム: %{y:+.2f}%<extra></extra>'))
        fig_cum.add_trace(go.Scatter(x=cum["date"], y=(cum["index_capital"] - 100), name="キャピタル",
            fill="tozeroy", fillcolor=hex_to_rgba("#8b5cf6", 0.15),
            line=dict(color="#8b5cf6", width=2.5), mode="lines+markers", marker=dict(size=4),
            hovertemplate='キャピタル: %{y:+.2f}%<extra></extra>'))
        fig_cum.add_trace(go.Scatter(x=cum["date"], y=(cum["index_total"] - 100), name="トータル",
            line=dict(color="#0f172a", width=3, dash="dot"), mode="lines+markers", marker=dict(size=5),
            hovertemplate='トータル: %{y:+.2f}%<extra></extra>'))
        # Endpoint labels removed (overlap with legend)
        fig_cum.update_layout(**CHART_LAYOUT, height=420, legend=CHART_LEGEND,
            title=dict(text='累積リターン推移（%）', font=dict(size=14, color="#0f172a")),
            yaxis=dict(title='%', gridcolor="#e2e8f0"))
        fig_cum.add_hline(y=0, line_dash="dash", line_color="#cbd5e1", line_width=1)
        apply_jp_xaxis(fig_cum, cum["date"])
        st.plotly_chart(fig_cum, use_container_width=True)

    with sub_tabs[1]:
        render_kpi_cards([
            {"label": "累計インカム", "value": fmt_oku(ib["total_income"], 2)},
            {"label": "累計キャピタル", "value": fmt_oku(ib["total_capital"], 2), "positive": ib["total_capital"] >= 0},
            {"label": "累計トータル", "value": fmt_oku(ib["total_income"] + ib["total_capital"], 2),
             "positive": (ib["total_income"] + ib["total_capital"]) >= 0},
            {"label": "インカム安定性", "value": f'{ib["income_stability"]:.0%}', "sub": "高いほど安定",
             "positive": ib["income_stability"] > 0.5},
        ])

        st.markdown('<div class="section-header">\U0001f4ca 月次トータル収益（インカム＋キャピタル）</div>', unsafe_allow_html=True)
        fig_total = go.Figure()
        fig_total.add_trace(go.Bar(x=bm["date"], y=bm["income"], name="インカム", marker_color="#10b981",
            text=[f'{v:,.1f}' for v in bm["income"]], textposition="auto",
            insidetextfont=dict(size=7, color="#ffffff"),
            outsidetextfont=dict(size=7, color="#10b981"), cliponaxis=False,
            hovertemplate='インカム: %{y:,.2f}億円<extra></extra>'))
        cap_pos = [v if v >= 0 else 0 for v in bm["capital"]]
        cap_neg = [v if v < 0 else 0 for v in bm["capital"]]
        fig_total.add_trace(go.Bar(x=bm["date"], y=cap_pos, name="キャピタル（＋）", marker_color="#8b5cf6",
            text=[f'{v:,.1f}' if v > 0 else '' for v in cap_pos], textposition="auto",
            insidetextfont=dict(size=7, color="#ffffff"),
            outsidetextfont=dict(size=7, color="#8b5cf6"), cliponaxis=False))
        fig_total.add_trace(go.Bar(x=bm["date"], y=cap_neg, name="キャピタル（−）", marker_color="#ef4444",
            text=[f'{v:,.1f}' if v < 0 else '' for v in cap_neg], textposition="auto",
            insidetextfont=dict(size=7, color="#ffffff"),
            outsidetextfont=dict(size=7, color="#ef4444"), cliponaxis=False))
        fig_total.add_trace(go.Scatter(x=bm["date"], y=bm["total"], mode="markers+text",
            text=[f'{v:+,.1f}' for v in bm["total"]], textposition="top center",
            textfont=dict(size=9, color="#334155", weight="bold"), showlegend=False,
            marker=dict(size=8, color="#0f172a", symbol="circle"),
            hovertemplate='トータル: %{y:+,.1f}億円<extra></extra>'))
        fig_total.update_layout(**CHART_LAYOUT, height=420, legend=dict(orientation='h', yanchor='top', y=-0.25, xanchor='center', x=0.5, font=dict(size=10)),
            title=dict(text='月次トータル収益（積み上げ）', font=dict(size=14, color="#0f172a")), barmode="relative")
        apply_jp_xaxis(fig_total, bm["date"])
        st.plotly_chart(fig_total, use_container_width=True)

        fig_cumt = go.Figure()
        fig_cumt.add_trace(go.Scatter(x=bm["date"], y=bm["cumulative_income"], name="累積インカム",
            fill="tozeroy", fillcolor=hex_to_rgba("#10b981", 0.15),
            line=dict(color="#10b981", width=2.5), mode="lines+markers", marker=dict(size=4)))
        fig_cumt.add_trace(go.Scatter(x=bm["date"], y=bm["cumulative_capital"], name="累積キャピタル",
            fill="tozeroy", fillcolor=hex_to_rgba("#8b5cf6", 0.15),
            line=dict(color="#8b5cf6", width=2.5), mode="lines+markers", marker=dict(size=4)))
        fig_cumt.add_trace(go.Scatter(x=bm["date"], y=bm["cumulative_total"], name="累積トータル",
            line=dict(color="#0f172a", width=3, dash="dot"), mode="lines+markers", marker=dict(size=5)))
        # Endpoint labels removed (overlap with legend)
        fig_cumt.update_layout(**CHART_LAYOUT, height=420, legend=CHART_LEGEND,
            title=dict(text='累積収益推移', font=dict(size=14, color="#0f172a")))
        fig_cumt.add_hline(y=0, line_dash="dash", line_color="#cbd5e1", line_width=1)
        apply_jp_xaxis(fig_cumt, bm["date"])
        st.plotly_chart(fig_cumt, use_container_width=True)

        st.markdown('<div class="section-header">\U0001f4c8 インカム・キャピタル内訳</div>', unsafe_allow_html=True)
        fig_inc = go.Figure()
        fig_inc.add_trace(go.Bar(x=bm["date"], y=bm["income"], name="インカム", marker_color="#10b981",
            text=[f'{v:,.1f}' for v in bm["income"]], textposition="outside",
            textfont=dict(size=8, color="#334155")))
        fig_inc.update_layout(**CHART_LAYOUT, height=320, legend=CHART_LEGEND,
            title=dict(text='月次インカム収益', font=dict(size=14, color="#0f172a")))
        apply_jp_xaxis(fig_inc, bm["date"])
        st.plotly_chart(fig_inc, use_container_width=True)

        fig_cap = go.Figure()
        fig_cap.add_trace(go.Bar(x=bm["date"], y=bm["capital"], name="キャピタル",
            marker_color=["#10b981" if v >= 0 else "#ef4444" for v in bm["capital"]],
            text=[f'{v:+,.1f}' for v in bm["capital"]], textposition="outside",
            textfont=dict(size=8, color="#334155")))
        fig_cap.update_layout(**CHART_LAYOUT, height=320, legend=CHART_LEGEND,
            title=dict(text='月次キャピタル損益', font=dict(size=14, color="#0f172a")))
        apply_jp_xaxis(fig_cap, bm["date"])
        st.plotly_chart(fig_cap, use_container_width=True)

    with sub_tabs[2]:
        st.markdown('<div class="section-header">\U0001f3e6 資産クラス別収益</div>', unsafe_allow_html=True)
        fig_wf = create_waterfall_chart(ba_ordered["asset_class"].tolist() + ["トータル"],
            ba_ordered["total"].tolist() + [ba_ordered["total"].sum()], title='資産クラス別収益内訳')
        st.plotly_chart(fig_wf, use_container_width=True)

        fig_ac = go.Figure()
        fig_ac.add_trace(go.Bar(x=ba_ordered["asset_class"], y=ba_ordered["income"], name="インカム",
            marker_color="#10b981", text=[f'{v:,.1f}' for v in ba_ordered["income"]],
            textposition="outside", textfont=dict(size=9, color="#10b981"),
            cliponaxis=False))
        ac_cap_pos = [v if v >= 0 else 0 for v in ba_ordered["capital"]]
        ac_cap_neg = [v if v < 0 else 0 for v in ba_ordered["capital"]]
        fig_ac.add_trace(go.Bar(x=ba_ordered["asset_class"], y=ac_cap_pos, name="キャピタル（＋）",
            marker_color="#8b5cf6", text=[f'{v:,.1f}' if v > 0 else '' for v in ac_cap_pos],
            textposition="outside", textfont=dict(size=9, color="#8b5cf6"),
            cliponaxis=False))
        fig_ac.add_trace(go.Bar(x=ba_ordered["asset_class"], y=ac_cap_neg, name="キャピタル（−）",
            marker_color="#ef4444", text=[f'{v:,.1f}' if v < 0 else '' for v in ac_cap_neg],
            textposition="outside", textfont=dict(size=9, color="#ef4444"),
            cliponaxis=False))
        _lo_ac = {k:v for k,v in CHART_LAYOUT.items() if k != 'margin'}
        fig_ac.update_layout(**_lo_ac, height=450,
            legend=dict(orientation='h', yanchor='top', y=-0.28, xanchor='center', x=0.5, font=dict(size=9, color='#334155')),
            title=dict(text='資産クラス別インカム・キャピタル', font=dict(size=14, color="#0f172a")), barmode="group",
            margin=dict(l=40, r=20, t=60, b=100))
        st.plotly_chart(fig_ac, use_container_width=True)

        if transaction_df is not None and len(transaction_df) > 0:
            st.markdown('<div class="section-header">\U0001f4dd 取引サマリー</div>', unsafe_allow_html=True)
            tx = compute_transaction_summary(transaction_df)
            tc1, tc2 = st.columns(2)
            with tc1: st.metric("取引件数", tx["n_transactions"])
            with tc2:
                if "total_cost" in tx: st.metric("総コスト", fmt_hyakuman(tx["total_cost"]))

    with sub_tabs[3]:
        st.markdown('<div class="section-header">\U0001f50d トレンド検出</div>', unsafe_allow_html=True)
        trends = ts.detect_trends(monthly_df)
        dm = {"up":"上昇","down":"下降","flat":"横ばい"}
        if trends:
            for t in trends:
                icon = "\U0001f4c8" if t["direction"]=="up" else ("\U0001f4c9" if t["direction"]=="down" else "\u27a1\ufe0f")
                sev = "info" if t["direction"]=="flat" else ("medium" if t["direction"]=="down" else "low")
                render_insight_cards([{"severity":sev,"icon":icon,
                    "title":t["label"]+" - "+dm.get(t["direction"],"")+" トレンド",
                    "description":t["description"],"reasoning":"R\u00b2="+str(round(t["r_squared"],3)),
                    "evidence":t["evidence"]}], show_evidence=show_evidence)
        anomalies = ts.find_anomalies(monthly_df)
        if anomalies:
            st.markdown('<div class="section-header">\u26a0 異常値検出</div>', unsafe_allow_html=True)
            for a in anomalies[:5]:
                render_insight_cards([{"severity":a["severity"],"icon":"\u26a0",
                    "title":a["description"],"description":"Z="+str(round(a["z_score"],1)),
                    "evidence":a["evidence"]}], show_evidence=show_evidence)

    st.markdown("---")
    dl = export_to_excel({"集計": totals, "構成比推移": comp_ts, "月次収益": bm, "資産クラス別": ba})
    st.download_button("\U0001f4e5 分析データ (Excel)", data=dl, file_name="analysis.xlsx",
                       mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
