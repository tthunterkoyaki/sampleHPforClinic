"""tab_risk.py - リスク分析タブ（ΔNII追加、資産クラス別積み上げ、コメント下部）"""
import streamlit as st
import plotly.graph_objects as go
import pandas as pd
from portfolio_dashboard.ui_components import (
    render_insight_cards, create_bar_chart, create_pie_chart,
    fmt_hyakuman, PLOTLY_LAYOUT, hex_to_rgba, order_asset_classes, get_asset_color, ASSET_CLASS_ORDER
)

def render(security_df, ra, show_evidence):
    _ac_col = 'asset_class' if 'asset_class' in security_df.columns else 'category'
    st.markdown('<div class="section-header">⚡ リスク分析</div>', unsafe_allow_html=True)

    c1, c2 = st.columns(2)
    with c1:
        ir = ra.analyze_interest_rate_risk(security_df)
        if ir.get('available'):
            st.markdown('<div class="section-header">📉 金利リスク</div>', unsafe_allow_html=True)
            # Unified risk metrics table (BPV, ΔEVE, ΔNII, NII)
            risk_rows = []
            if 'bpv' in ir and ir['bpv']:
                for k in ['jpy_bpv_100', 'fc_bpv_100']:
                    if k in ir['bpv']:
                        label = '円貨100BPV' if k == 'jpy_bpv_100' else '外貨100BPV'
                        risk_rows.append({'指標': label, '値': ir['bpv'][k]['total']})
            if 'eve' in ir and ir['eve']:
                risk_rows.append({'指標': 'ΔEVE（上昇）', '値': ir['eve'].get('eve_parallel_up', 0)})
                risk_rows.append({'指標': 'ΔEVE（下降）', '値': ir['eve'].get('eve_parallel_down', 0)})
            if 'nii' in ir and ir['nii']:
                nii_total = ir['nii'].get('nii_1y', 0)
                risk_rows.append({'指標': 'ΔNII（金利+100bp）', '値': nii_total * 0.1})
                risk_rows.append({'指標': '参考: NII（1年）', '値': nii_total})
            if risk_rows:
                rdf = pd.DataFrame(risk_rows)
                def _color_val(val):
                    if isinstance(val, (int, float)):
                        if val < 0: return 'color: #ef4444'
                        if val > 0: return 'color: #10b981'
                    return ''
                styled = rdf.style.format({'値': '{:,.0f}'}).map(_color_val, subset=['値'])
                st.dataframe(styled, use_container_width=True, hide_index=True)

            # Asset-class level ΔEVE: horizontal bars for both up/down
            if 'eve_parallel_up' in security_df.columns and _ac_col in security_df.columns:
                eve_by_ac = security_df.groupby(_ac_col).agg(
                    eve_up=('eve_parallel_up', 'sum'),
                    eve_down=('eve_parallel_down', 'sum') if 'eve_parallel_down' in security_df.columns else ('eve_parallel_up', lambda x: 0)
                ).reset_index()
                eve_by_ac.columns = ['asset_class', 'eve_up', 'eve_down']
                eve_by_ac = eve_by_ac[(eve_by_ac['eve_up'] != 0) | (eve_by_ac['eve_down'] != 0)]
                ao = {c:i for i,c in enumerate(ASSET_CLASS_ORDER)}
                eve_by_ac['_o'] = eve_by_ac['asset_class'].map(ao).fillna(999)
                eve_by_ac = eve_by_ac.sort_values('_o', ascending=False)
                fig_eve = go.Figure()
                fig_eve.add_trace(go.Bar(y=eve_by_ac['asset_class'], x=eve_by_ac['eve_up'],
                    name='金利上昇', marker_color='#ef4444', orientation='h',
                    text=[f'{v:,.0f}' for v in eve_by_ac['eve_up']], textposition='auto',
                    textfont=dict(size=8), cliponaxis=False, constraintext='none',
                    insidetextfont=dict(size=8, color='#ffffff')))
                fig_eve.add_trace(go.Bar(y=eve_by_ac['asset_class'], x=eve_by_ac['eve_down'],
                    name='金利低下', marker_color='#3b82f6', orientation='h',
                    text=[f'{v:,.0f}' for v in eve_by_ac['eve_down']], textposition='auto',
                    textfont=dict(size=8), cliponaxis=False, constraintext='none',
                    insidetextfont=dict(size=8, color='#ffffff')))
                _lo = {k:v for k,v in PLOTLY_LAYOUT.items() if k not in ('margin', 'yaxis', 'xaxis')}
                fig_eve.update_layout(**_lo, height=300, barmode='group',
                    title=dict(text='資産クラス別ΔEVE', font=dict(size=12, color='#0f172a')),
                    legend=dict(orientation='h', yanchor='top', y=-0.15, xanchor='center', x=0.5, font=dict(size=9)),
                    margin=dict(l=100, r=30, t=50, b=50),
                    xaxis=dict(autorange=True))
                fig_eve.add_vline(x=0, line_dash='dash', line_color='#cbd5e1')
                st.plotly_chart(fig_eve, use_container_width=True)

    with c2:
        fx = ra.analyze_fx_risk(security_df)
        if fx.get('available'):
            st.markdown('<div class="section-header">💱 為替リスク</div>', unsafe_allow_html=True)
            st.metric("外貨比率", str(round(fx.get('foreign_ratio',0), 1)) + '%')
            if 'currency_exposure' in fx:
                ce = fx['currency_exposure']
                fig = create_pie_chart(ce['issue_currency'].tolist(), ce['market_value'].tolist(),
                                        title='通貨別エクスポージャー')
                fig.update_layout(height=220, margin=dict(l=10, r=10, t=30, b=10))
                st.plotly_chart(fig, use_container_width=True)

            # Currency x Asset class breakdown
            if 'issue_currency' in security_df.columns and _ac_col in security_df.columns:
                cur_ac = security_df.groupby(['issue_currency', _ac_col])['market_value'].sum().reset_index()
                # Sort currencies by total MV desc
                cur_totals = cur_ac.groupby('issue_currency')['market_value'].sum().sort_values(ascending=True)
                fig_bd = go.Figure()
                for ac in order_asset_classes(security_df[_ac_col].unique().tolist()):
                    acd = cur_ac[cur_ac[_ac_col] == ac]
                    fig_bd.add_trace(go.Bar(y=acd['issue_currency'], x=acd['market_value'],
                        name=ac, marker_color=get_asset_color(ac), orientation='h',
                        hovertemplate=f'{ac}: %{{x:,.0f}}<extra></extra>'))
                _lo_fx = {k:v for k,v in PLOTLY_LAYOUT.items() if k not in ('margin', 'yaxis', 'xaxis')}
                fig_bd.update_layout(**_lo_fx, height=200, barmode='stack',
                    title=dict(text='通貨×資産クラス', font=dict(size=11, color='#0f172a')),
                    yaxis=dict(categoryorder='array', categoryarray=cur_totals.index.tolist()),
                    legend=dict(orientation='h', yanchor='top', y=-0.3, xanchor='center', x=0.5, font=dict(size=7)),
                    margin=dict(l=50, r=20, t=35, b=50),
                    showlegend=False)
                st.plotly_chart(fig_bd, use_container_width=True)

    cr = ra.analyze_credit_risk(security_df)
    if cr.get('available'):
        st.markdown('<div class="section-header">🛡️ 信用リスク</div>', unsafe_allow_html=True)
        cc1, cc2 = st.columns(2)
        with cc1:
            if 'rw_distribution' in cr:
                rw = cr['rw_distribution'].copy()
                rw['RW'] = rw['risk_weight'].astype(str) + '%'
                # Stacked by asset class if category available
                if _ac_col in security_df.columns and 'risk_weight' in security_df.columns:
                    fig = go.Figure()
                    for ac in order_asset_classes(security_df.get('asset_class', security_df.get('category', pd.Series())).unique().tolist()):
                        acd = security_df[security_df.get('asset_class', security_df.get('category', pd.Series())) == ac]
                        rw_ac = acd.groupby('risk_weight')['market_value'].sum().reset_index()
                        rw_ac['RW'] = rw_ac['risk_weight'].astype(str) + '%'
                        fig.add_trace(go.Bar(x=rw_ac['RW'], y=rw_ac['market_value'], name=ac,
                            marker_color=get_asset_color(ac)))
                    fig.update_layout(**PLOTLY_LAYOUT, height=380, barmode='stack',
                        legend=dict(orientation='h', yanchor='top', y=-0.2, xanchor='center', x=0.5, font=dict(size=8)),
                        title=dict(text='リスクウェイト別構成', font=dict(size=14, color='#0f172a')))
                    st.plotly_chart(fig, use_container_width=True)
                else:
                    fig = create_bar_chart(rw, 'RW', 'market_value', title='リスクウェイト別構成')
                    st.plotly_chart(fig, use_container_width=True)
        with cc2:
            if 'fv_level_distribution' in cr:
                fv = cr['fv_level_distribution']
                fig = create_pie_chart(fv['fair_value_level'].tolist(), fv['market_value'].tolist(),
                                        title='公正価値レベル別')
                st.plotly_chart(fig, use_container_width=True)

    gl = ra.analyze_unrealized_gl(security_df)
    if gl.get('available'):
        st.markdown('<div class="section-header">\U0001f4ca \u8a55\u4fa1\u640d\u76ca\u5206\u6790</div>', unsafe_allow_html=True)
        # 3 KPI cards: total, gains, losses
        kc1, kc2, kc3 = st.columns(3)
        with kc1:
            _cls = 'kpi-positive' if gl['total_gl'] >= 0 else 'kpi-negative'
            st.markdown(
                f'<div class="kpi-card"><div class="kpi-label">\u8a55\u4fa1\u640d\u76ca\u5408\u8a08</div>'
                f'<div class="kpi-value {_cls}">{fmt_hyakuman(gl["total_gl"], 2)}</div>'
                f'<div class="kpi-sub">\u76ca:{gl["n_gain"]} / \u640d:{gl["n_loss"]}</div></div>',
                unsafe_allow_html=True)
        with kc2:
            _gt = gl.get('total_gain', 0)
            if _gt == 0 and 'unrealized_gl' in security_df.columns:
                _gt = security_df[security_df['unrealized_gl'] > 0]['unrealized_gl'].sum()
            st.markdown(
                f'<div class="kpi-card"><div class="kpi-label">\u542b\u307f\u76ca\u5408\u8a08</div>'
                f'<div class="kpi-value kpi-positive">{fmt_hyakuman(_gt, 2)}</div></div>',
                unsafe_allow_html=True)
        with kc3:
            _lt = gl.get('total_loss', 0)
            if _lt == 0 and 'unrealized_gl' in security_df.columns:
                _lt = security_df[security_df['unrealized_gl'] < 0]['unrealized_gl'].sum()
            st.markdown(
                f'<div class="kpi-card"><div class="kpi-label">\u542b\u307f\u640d\u5408\u8a08</div>'
                f'<div class="kpi-value kpi-negative">{fmt_hyakuman(_lt, 2)}</div></div>',
                unsafe_allow_html=True)

        # Full sorted tables: gains (left) and losses (right)
        _cols = ['security_name', 'unrealized_gl', 'gl_ratio', 'book_yield', 'coupon_rate', 'avg_remaining', 'asset_class', 'market_value']
        _avail = [c for c in _cols if c in security_df.columns]
        _rn = {'security_name':'銘柄','unrealized_gl':'評価損益','gl_ratio':'損益率(%)','book_yield':'利回り(%)',
               'coupon_rate':'クーポン(%)','avg_remaining':'残存年','asset_class':'資産クラス','market_value':'時価'}

        tg1, tg2 = st.columns(2)
        with tg1:
            st.markdown("**含み益 銘柄一覧:**")
            if 'unrealized_gl' in security_df.columns:
                gains_df = security_df[security_df['unrealized_gl'] > 0][_avail].copy()
                gains_df = gains_df.sort_values('unrealized_gl', ascending=False)
                if 'gl_ratio' in gains_df.columns:
                    gains_df['gl_ratio'] = (gains_df['gl_ratio'] * 100).round(2)
                if 'book_yield' in gains_df.columns:
                    gains_df['book_yield'] = (gains_df['book_yield'] * 100).round(2)
                if 'coupon_rate' in gains_df.columns:
                    gains_df['coupon_rate'] = (gains_df['coupon_rate'] * 100).round(2)
                if 'avg_remaining' in gains_df.columns:
                    gains_df['avg_remaining'] = gains_df['avg_remaining'].round(1)
                if 'unrealized_gl' in gains_df.columns:
                    gains_df['unrealized_gl'] = gains_df['unrealized_gl'].apply(lambda x: f'{x:,.0f}')
                if 'market_value' in gains_df.columns:
                    gains_df['market_value'] = gains_df['market_value'].apply(lambda x: f'{x:,.0f}')
                gains_df = gains_df.rename(columns=_rn)
                st.dataframe(gains_df, use_container_width=True, hide_index=True, height=300)

        with tg2:
            st.markdown("**含み損 銘柄一覧:**")
            if 'unrealized_gl' in security_df.columns:
                loss_df = security_df[security_df['unrealized_gl'] < 0][_avail].copy()
                loss_df = loss_df.sort_values('unrealized_gl', ascending=True)
                if 'gl_ratio' in loss_df.columns:
                    loss_df['gl_ratio'] = (loss_df['gl_ratio'] * 100).round(2)
                if 'book_yield' in loss_df.columns:
                    loss_df['book_yield'] = (loss_df['book_yield'] * 100).round(2)
                if 'coupon_rate' in loss_df.columns:
                    loss_df['coupon_rate'] = (loss_df['coupon_rate'] * 100).round(2)
                if 'avg_remaining' in loss_df.columns:
                    loss_df['avg_remaining'] = loss_df['avg_remaining'].round(1)
                if 'unrealized_gl' in loss_df.columns:
                    loss_df['unrealized_gl'] = loss_df['unrealized_gl'].apply(lambda x: f'{x:,.0f}')
                if 'market_value' in loss_df.columns:
                    loss_df['market_value'] = loss_df['market_value'].apply(lambda x: f'{x:,.0f}')
                loss_df = loss_df.rename(columns=_rn)
                st.dataframe(loss_df, use_container_width=True, hide_index=True, height=300)

        # Full-width distributions (vertical stack, right legend)
        st.markdown("---")
        if 'gl_ratio' in security_df.columns and _ac_col in security_df.columns:
            fig = go.Figure()
            for ac in order_asset_classes(security_df[_ac_col].unique().tolist()):
                acd = security_df[security_df[_ac_col] == ac]
                vals = acd['gl_ratio'].dropna() * 100
                if len(vals) > 0:
                    fig.add_trace(go.Histogram(x=vals, name=ac, marker_color=get_asset_color(ac), opacity=0.7, nbinsx=30))
            _lo = {k:v for k,v in PLOTLY_LAYOUT.items() if k not in ('margin', 'yaxis', 'xaxis')}
            fig.update_layout(**_lo, height=350, barmode='stack',
                title=dict(text='\u8a55\u4fa1\u640d\u76ca\u7387\u5206\u5e03(%)', font=dict(size=14, color='#0f172a')),
                legend=dict(orientation='v', yanchor='top', y=1, xanchor='left', x=1.02, font=dict(size=9)),
                margin=dict(l=40, r=150, t=50, b=40))
            fig.add_vline(x=0, line_dash='dash', line_color='#cbd5e1')
            st.plotly_chart(fig, use_container_width=True)

        if 'unrealized_gl' in security_df.columns and _ac_col in security_df.columns:
            fig_amt = go.Figure()
            for ac in order_asset_classes(security_df[_ac_col].unique().tolist()):
                acd = security_df[security_df[_ac_col] == ac]
                vals = acd['unrealized_gl'].dropna()
                if len(vals) > 0:
                    fig_amt.add_trace(go.Histogram(x=vals, name=ac, marker_color=get_asset_color(ac), opacity=0.7, nbinsx=30))
            _lo = {k:v for k,v in PLOTLY_LAYOUT.items() if k not in ('margin', 'yaxis', 'xaxis')}
            fig_amt.update_layout(**_lo, height=350, barmode='stack',
                title=dict(text='\u8a55\u4fa1\u640d\u76ca\u91d1\u984d\u5206\u5e03', font=dict(size=14, color='#0f172a')),
                legend=dict(orientation='v', yanchor='top', y=1, xanchor='left', x=1.02, font=dict(size=9)),
                margin=dict(l=40, r=150, t=50, b=40))
            fig_amt.add_vline(x=0, line_dash='dash', line_color='#cbd5e1')
            st.plotly_chart(fig_amt, use_container_width=True)

    # Risk insights at BOTTOM
    rs = ra.generate_risk_summary(security_df)
    if rs:
        st.markdown('<div class="section-header">💡 リスクインサイト</div>', unsafe_allow_html=True)
        render_insight_cards(rs[:5], show_evidence=show_evidence)