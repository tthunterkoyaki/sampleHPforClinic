﻿"""
data_loader.py - マルチレベルExcelデータ読み込み

列名ベースの柔軟なマッピングでExcelファイルを読み込み、
データ粒度（Level 1/2/3）を自動判定する。

設計方針:
  - 列の順番には依存しない（名前でマッチング）
  - 欠損列は許容し、利用可能な列のみで分析
  - 自動レベル判定でUIの表示内容を動的に切り替え
"""
import pandas as pd
import numpy as np
import logging
from typing import Optional, Tuple, Dict, List, Any
from portfolio_dashboard.data_models import (
    PortfolioData, DataLevel, match_column_name,
    LEVEL1_REQUIRED_COLUMNS, LEVEL2_COLUMN_MAP, LEVEL3_COLUMN_MAP
)

logger = logging.getLogger(__name__)


def load_portfolio_excel(file_bytes) -> Tuple[Optional[PortfolioData], Optional[str]]:
    """
    Excelファイルからポートフォリオデータを読み込む。

    処理フロー:
      1. 全シートを読み込み
      2. 各シートの列名からデータ種別を判定
      3. Level 1（月次）データを構築
      4. Level 2（銘柄）データがあれば追加
      5. Level 3（取引明細）データがあれば追加
      6. データレベルを判定して返す

    Args:
        file_bytes: Excelファイルのバイトデータ

    Returns:
        (PortfolioData, None) 成功時
        (None, error_message) 失敗時
    """
    try:
        # 全シートを読み込み
        import io
        if isinstance(file_bytes, bytes):
            file_bytes = io.BytesIO(file_bytes)
        xls = pd.ExcelFile(file_bytes)
        sheets = {}
        for name in xls.sheet_names:
            df = pd.read_excel(xls, sheet_name=name)
            if len(df) > 0:
                sheets[name] = df
                logger.info(f"シート '{name}': {len(df)}行 × {len(df.columns)}列")

        if not sheets:
            return None, "有効なデータシートが見つかりませんでした。"

        # 各シートを分類
        monthly_sheets = []   # Level 1 候補
        security_sheets = []  # Level 2 候補
        transaction_sheets = [] # Level 3 候補

        for name, df in sheets.items():
            sheet_type = _classify_sheet(df)
            if sheet_type == 'monthly':
                monthly_sheets.append((name, df))
            elif sheet_type == 'security':
                security_sheets.append((name, df))
            elif sheet_type == 'transaction':
                transaction_sheets.append((name, df))
            else:
                logger.info(f"シート '{name}' は分類不能 → スキップ")

        # Level 1 データ構築
        monthly_df, col_map_l1 = _build_monthly_data(monthly_sheets, sheets)
        if monthly_df is None or len(monthly_df) == 0:
            return None, ("月次データ（年月・資産クラス・簿価・時価）を含むシートが見つかりませんでした。\n"
                         "必要な列: 年月, 資産クラス, 簿価, 時価, インカム収益額, キャピタル収益額")

        # Level 2 データ構築
        security_df, col_map_l2 = _build_security_data(security_sheets)

        # Level 3 データ構築
        transaction_df, col_map_l3 = _build_transaction_data(transaction_sheets)

        # レベル判定
        level = DataLevel.LEVEL1
        if security_df is not None:
            level = DataLevel.LEVEL2
        if transaction_df is not None:
            level = DataLevel.LEVEL3

        # メタデータ構築
        metadata = {
            'sheet_names': list(sheets.keys()),
            'monthly_sheets': [s[0] for s in monthly_sheets],
            'security_sheets': [s[0] for s in security_sheets],
            'transaction_sheets': [s[0] for s in transaction_sheets],
        }

        # 列マッピング統合
        col_mapping = {**col_map_l1, **col_map_l2, **col_map_l3}

        # Add asset_class column to security_df for consistent coloring
        if security_df is not None and 'asset_class' not in security_df.columns:
            if 'category' in security_df.columns:
                _cat_map = {
                    '国債': '国内債券（固定）',
                    '地方債': '国内債券（固定）',
                    '社債': '国内債券（固定）',
                    '国内株式': '国内株式',
                    'J-REIT': 'J-REIT',
                    'その他投信': 'その他投信',
                }
                def _map_ac(row):
                    cat = row.get('category', '')
                    sub = str(row.get('sub_category', ''))
                    if cat == '国債' and '変動' in sub:
                        return '国内債券（変動）'
                    if '外国' in cat and '債' in cat:  # 外国債/外国債券
                        return '外国債券（ヘッジ無）' if 'ヘッジ無' in sub else '外国債券（ヘッジ有）'
                    return _cat_map.get(cat, cat)
                security_df['asset_class'] = security_df.apply(_map_ac, axis=1)

        portfolio = PortfolioData(
            level=level,
            monthly_data=monthly_df,
            security_data=security_df,
            transaction_data=transaction_df,
            metadata=metadata,
            column_mapping=col_mapping,
        )

        logger.info(f"データレベル: {level.name}, 期間数: {portfolio.n_periods}, "
                    f"資産クラス数: {len(portfolio.asset_classes)}")
        return portfolio, None

    except Exception as e:
        logger.error(f"Excel読み込みエラー: {e}", exc_info=True)
        return None, f"ファイル読み込みエラー: {str(e)}"


def _classify_sheet(df: pd.DataFrame) -> str:
    """
    シートの列名パターンからデータ種別を判定する。

    判定ロジック:
      1. 月次データ: 年月 + 資産クラス + 簿価/時価 の組み合わせ
      2. 取引明細: 取引日 + 売買区分 + 金額
      3. 銘柄データ: 銘柄名/コード + 簿価/時価
    """
    cols = df.columns.tolist()

    # 月次データ判定: 日付列 + 資産クラス列 + 金額列
    has_date = match_column_name(cols, LEVEL1_REQUIRED_COLUMNS['date']) is not None
    has_asset = match_column_name(cols, LEVEL1_REQUIRED_COLUMNS['asset_class']) is not None
    has_book = match_column_name(cols, LEVEL1_REQUIRED_COLUMNS['book_value']) is not None
    has_market = match_column_name(cols, LEVEL1_REQUIRED_COLUMNS['market_value']) is not None

    if has_date and has_asset and (has_book or has_market):
        return 'monthly'

    # 取引明細判定
    has_trade_date = match_column_name(cols, LEVEL3_COLUMN_MAP.get('trade_date', [])) is not None
    has_trade_type = match_column_name(cols, LEVEL3_COLUMN_MAP.get('trade_type', [])) is not None
    has_amount = match_column_name(cols, LEVEL3_COLUMN_MAP.get('amount', [])) is not None

    if has_trade_date and (has_trade_type or has_amount):
        return 'transaction'

    # 銘柄データ判定
    has_sec_name = match_column_name(cols, LEVEL2_COLUMN_MAP.get('security_name', [])) is not None
    has_sec_code = match_column_name(cols, LEVEL2_COLUMN_MAP.get('security_code', [])) is not None
    has_l2_book = match_column_name(cols, LEVEL2_COLUMN_MAP.get('book_value', [])) is not None
    has_l2_market = match_column_name(cols, LEVEL2_COLUMN_MAP.get('market_value', [])) is not None

    if (has_sec_name or has_sec_code) and (has_l2_book or has_l2_market):
        return 'security'

    return 'unknown'


def _build_monthly_data(monthly_sheets, all_sheets) -> Tuple[Optional[pd.DataFrame], Dict]:
    """
    月次資産クラスデータを構築する。

    列名マッピング:
      - 元の列名 → 正規化された内部列名
      - 不足列はNaN埋め
    """
    col_map = {}

    if not monthly_sheets:
        # 月次シートが見つからない場合、全シートから探す
        for name, df in all_sheets.items():
            if _classify_sheet(df) == 'monthly':
                monthly_sheets = [(name, df)]
                break

    if not monthly_sheets:
        return None, col_map

    # 最初の月次シートを使用
    sheet_name, raw_df = monthly_sheets[0]
    cols = raw_df.columns.tolist()
    df = raw_df.copy()

    # 列マッピング
    mapping = {}
    for internal_name, candidates in LEVEL1_REQUIRED_COLUMNS.items():
        matched = match_column_name(cols, candidates)
        if matched:
            mapping[matched] = internal_name
            col_map[f'L1:{internal_name}'] = matched

    # リネーム
    df = df.rename(columns=mapping)

    # 必須列チェック
    required = ['date', 'asset_class']
    for r in required:
        if r not in df.columns:
            logger.warning(f"必須列 '{r}' が見つかりません")
            return None, col_map

    # 数値列の型変換
    for col in ['book_value', 'market_value', 'income', 'capital']:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors='coerce').fillna(0)

    # 欠損列を0埋め
    for col in ['book_value', 'market_value', 'income', 'capital']:
        if col not in df.columns:
            df[col] = 0.0

    # 評価損益を計算（時価 - 簿価）
    df['unrealized_gl'] = df['market_value'] - df['book_value']

    # 日付の正規化
    df['date'] = pd.to_datetime(df['date']).dt.strftime('%Y-%m')

    # ソート
    df = df.sort_values(['date', 'asset_class']).reset_index(drop=True)

    return df, col_map


def _build_security_data(security_sheets) -> Tuple[Optional[pd.DataFrame], Dict]:
    """
    銘柄レベルデータを構築する。

    列名ベースの柔軟なマッピングにより、列順に依存しない読み込みを実現。
    認識できた列のみを内部名に正規化する。
    """
    col_map = {}
    if not security_sheets:
        return None, col_map

    sheet_name, raw_df = security_sheets[0]
    cols = raw_df.columns.tolist()
    df = raw_df.copy()

    # 列マッピング（重複マッチ防止: 先にマッチした列を優先）
    mapping = {}
    used_cols = set()
    for internal_name, candidates in LEVEL2_COLUMN_MAP.items():
        remaining_cols = [c for c in cols if c not in used_cols]
        matched = match_column_name(remaining_cols, candidates)
        if matched:
            mapping[matched] = internal_name
            used_cols.add(matched)
            col_map[f'L2:{internal_name}'] = matched

    df = df.rename(columns=mapping)

    # 数値列の型変換
    numeric_cols = [
        'face_value', 'book_value', 'book_value_raw', 'market_value', 'market_value_raw',
        'unrealized_gl', 'amortization', 'period_amort', 'fx_gl',
        'book_value_fc', 'market_value_fc',
        'book_fx_rate', 'market_fx_rate', 'amort_fx_rate',
        'book_price', 'market_price',
        'coupon_rate', 'avg_remaining', 'book_yield', 'market_yield',
        'book_compound', 'market_compound', 'gl_ratio',
        'risk_weight', 'risk_asset', 'var_1y', 'var_5y',
        'jpy_bpv_10', 'jpy_bpv_100', 'fc_bpv_10', 'fc_bpv_100',
        'delta_fx', 'delta_equity', 'delta_commodity', 'delta_reit',
        'eve_parallel_up', 'eve_parallel_down', 'eve_steepening',
        'nii_1y', 'nii_parallel_up', 'nii_parallel_down',
    ]
    for col in numeric_cols:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors='coerce')

    # 日付列の変換
    date_cols = ['issue_date', 'maturity_date', 'next_call_date', 'trade_date', 'settle_date']
    for col in date_cols:
        if col in df.columns:
            df[col] = pd.to_datetime(df[col], errors='coerce')

    # 評価損益が無ければ計算
    if 'unrealized_gl' not in df.columns and 'market_value' in df.columns and 'book_value' in df.columns:
        df['unrealized_gl'] = df['market_value'] - df['book_value']

    # 評価損益率が無ければ計算
    if 'gl_ratio' not in df.columns and 'unrealized_gl' in df.columns and 'book_value' in df.columns:
        df['gl_ratio'] = np.where(df['book_value'] != 0,
                                   df['unrealized_gl'] / df['book_value'], 0)

    logger.info(f"銘柄データ: {len(df)}行, 認識列数: {len(mapping)}/{len(LEVEL2_COLUMN_MAP)}")
    return df, col_map


def _build_transaction_data(transaction_sheets) -> Tuple[Optional[pd.DataFrame], Dict]:
    """取引明細データを構築する。"""
    col_map = {}
    if not transaction_sheets:
        return None, col_map

    sheet_name, raw_df = transaction_sheets[0]
    cols = raw_df.columns.tolist()
    df = raw_df.copy()

    mapping = {}
    used_cols = set()
    for internal_name, candidates in LEVEL3_COLUMN_MAP.items():
        remaining_cols = [c for c in cols if c not in used_cols]
        matched = match_column_name(remaining_cols, candidates)
        if matched:
            mapping[matched] = internal_name
            used_cols.add(matched)
            col_map[f'L3:{internal_name}'] = matched

    df = df.rename(columns=mapping)

    # 数値列
    for col in ['quantity', 'price', 'amount', 'cost', 'income_amount']:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors='coerce')

    # 日付列
    for col in ['trade_date', 'settle_date']:
        if col in df.columns:
            df[col] = pd.to_datetime(df[col], errors='coerce')

    if 'trade_date' in df.columns:
        df = df.sort_values('trade_date').reset_index(drop=True)

    logger.info(f"取引データ: {len(df)}行, 認識列数: {len(mapping)}/{len(LEVEL3_COLUMN_MAP)}")
    return df, col_map


