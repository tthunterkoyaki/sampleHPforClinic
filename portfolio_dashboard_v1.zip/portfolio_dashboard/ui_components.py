"""ui_components.py - Premium UI / Streamlit Components (Light Mode)"""
import streamlit as st
import plotly.graph_objects as go
from typing import Dict, List, Any, Optional
import pandas as pd
import numpy as np

DASHBOARD_CSS = '''
<style>
    @import url('https://fonts.googleapis.com/css2?family=Noto+Sans+JP:wght@400;500;600;700;800&display=swap');
    .stApp { background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 50%, #e8edf5 100%) !important; font-family: 'Noto Sans JP', sans-serif !important; }
    .section-header { font-size: 1.1rem; font-weight: 700; color: #1e293b; margin: 1.5rem 0 0.8rem 0; padding-bottom: 0.4rem; border-bottom: 2px solid #cbd5e1; }
    .kpi-card { padding: 1.2rem; background: #ffffff; border-radius: 14px; border: 1px solid #e2e8f0; box-shadow: 0 2px 8px rgba(0,0,0,0.04); transition: transform 0.2s ease, box-shadow 0.2s ease; }
    .kpi-card:hover { transform: translateY(-3px); box-shadow: 0 8px 24px rgba(59,130,246,0.1); }
    .kpi-label { font-size: 0.72rem; color: #64748b; text-transform: uppercase; letter-spacing: 0.08em; margin-bottom: 0.3rem; font-weight: 600; }
    .kpi-value { font-size: 1.5rem; font-weight: 800; color: #0f172a; }
    .kpi-positive { color: #059669 !important; }
    .kpi-negative { color: #dc2626 !important; }
    .kpi-sub { font-size: 0.75rem; color: #94a3b8; margin-top: 0.2rem; font-weight: 500; }
    .insight-card { padding: 1rem 1.2rem; border-radius: 12px; margin-bottom: 0.8rem; border-left: 4px solid #94a3b8; background: #ffffff; border-top: 1px solid #e2e8f0; border-right: 1px solid #e2e8f0; border-bottom: 1px solid #e2e8f0; box-shadow: 0 1px 3px rgba(0,0,0,0.04); transition: transform 0.15s ease; }
    .insight-card:hover { transform: translateX(4px); }
    .insight-card.high { border-left-color: #dc2626; background: linear-gradient(135deg, #fef2f2, #fff5f5); }
    .insight-card.medium { border-left-color: #d97706; background: linear-gradient(135deg, #fffbeb, #fefce8); }
    .insight-card.low { border-left-color: #059669; background: linear-gradient(135deg, #f0fdf4, #ecfdf5); }
    .insight-card.info { border-left-color: #2563eb; background: linear-gradient(135deg, #eff6ff, #f0f9ff); }
    .insight-title { font-weight: 700; font-size: 0.95rem; color: #0f172a; margin-bottom: 0.3rem; }
    .insight-desc { font-size: 0.85rem; color: #475569; line-height: 1.6; }
    .evidence-box { margin-top: 0.5rem; padding: 0.6rem 0.8rem; background: #f1f5f9; border-radius: 8px; font-size: 0.78rem; color: #475569; border: 1px solid #e2e8f0; }
    .ev-label { font-weight: 600; color: #334155; }
    .level-badge { display: inline-flex; align-items: center; gap: 0.4rem; padding: 0.3rem 0.8rem; border-radius: 20px; font-size: 0.78rem; font-weight: 600; }
    .level-badge.level-1 { background: #dbeafe; color: #1e40af; }
    .level-badge.level-2 { background: #d1fae5; color: #065f46; }
    .level-badge.level-3 { background: #fce7f3; color: #9d174d; }
    .status-dot { width: 6px; height: 6px; border-radius: 50%; background: #22c55e; display: inline-block; animation: pulse 2s infinite; }
    @keyframes pulse { 0%,100%{opacity:1;} 50%{opacity:0.4;} }
    section[data-testid="stSidebar"] { background: linear-gradient(180deg, #ffffff 0%, #f8fafc 100%) !important; border-right: 1px solid #e2e8f0 !important; }
    section[data-testid="stSidebar"] * { color: #334155 !important; }
    .stTabs [data-baseweb="tab-list"] { gap: 0.3rem; border-bottom: 2px solid #e2e8f0; background: transparent; }
    .stTabs [data-baseweb="tab"] { padding: 0.5rem 1rem; border-radius: 8px 8px 0 0; font-weight: 600; font-size: 0.85rem; color: #64748b; }
    .stTabs [data-baseweb="tab"]:hover { color: #3b82f6; background: #eff6ff; }
    .stDataFrame { border-radius: 10px; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,0.06); }
    .stButton > button { border-radius: 8px; font-weight: 600; transition: all 0.2s ease; }
    .stButton > button:hover { transform: translateY(-1px); box-shadow: 0 4px 12px rgba(59,130,246,0.2); }
    [data-testid="stMetricValue"] { color: #0f172a !important; font-weight: 700; }
    [data-testid="stMetricLabel"] { color: #64748b !important; }
    .month-card { padding: 0.8rem 1rem; background: #ffffff; border-radius: 10px; border: 1px solid #e2e8f0; margin-bottom: 0.4rem; }
    .month-card .mc-label { font-size: 0.72rem; color: #64748b; font-weight: 600; }
    .month-card .mc-value { font-size: 1.1rem; font-weight: 700; color: #0f172a; }
    .month-card .mc-change { font-size: 0.78rem; font-weight: 500; }
</style>
'''
ASSET_CLASS_ORDER = ['国内債券（固定）','国内債券（変動）','外国債券（ヘッジ有）','外国債券（ヘッジ無）','国内株式','J-REIT','その他投信']
COLORS = ['#3b82f6','#60a5fa','#8b5cf6','#a78bfa','#10b981','#f59e0b','#06b6d4','#ec4899']
ASSET_COLORS = {'国内債券（固定）':'#3b82f6','国内債券（変動）':'#60a5fa','外国債券（ヘッジ有）':'#8b5cf6','外国債券（ヘッジ無）':'#a78bfa','国内株式':'#10b981','J-REIT':'#f59e0b','その他投信':'#06b6d4'}
PLOTLY_LAYOUT = dict(template='plotly_white', paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)',
    font=dict(color='#334155', size=11, family='Noto Sans JP, sans-serif'),
    margin=dict(l=40, r=20, t=40, b=40),
    
    xaxis=dict(gridcolor='#e2e8f0', zerolinecolor='#cbd5e1'), yaxis=dict(gridcolor='#e2e8f0', zerolinecolor='#cbd5e1'))

def inject_css(): st.markdown(DASHBOARD_CSS, unsafe_allow_html=True)
def get_asset_color(ac): return ASSET_COLORS.get(ac, '#94a3b8')
def order_asset_classes(classes):
    om = {c: i for i, c in enumerate(ASSET_CLASS_ORDER)}
    return sorted(classes, key=lambda c: om.get(c, 999))

def _jp_month_format(dates):
    r = []
    for d in dates:
        try:
            dt = pd.Timestamp(d)
            r.append(f"{dt.year}/{dt.month}月")
        except Exception:
            r.append(str(d))
    return r

def apply_jp_xaxis(fig, dates):
    dl = list(dates); n = len(dl); jl = _jp_month_format(dl)
    step = 3 if n > 18 else 2 if n > 12 else 1
    tv = [dl[i] for i in range(0, n, step)]
    tt = [jl[i] for i in range(0, n, step)]
    fig.update_xaxes(ticktext=tt, tickvals=tv, tickangle=-30)
    return fig

def render_kpi_cards(metrics):
    cols = st.columns(len(metrics))
    for i, m in enumerate(metrics):
        with cols[i]:
            vc = ''
            if 'positive' in m: vc = 'kpi-positive' if m['positive'] else 'kpi-negative'
            sh = f'<div class="kpi-sub {vc}">{m.get("sub","")}</div>' if m.get("sub") else ''
            st.markdown(f'<div class="kpi-card"><div class="kpi-label">{m["label"]}</div><div class="kpi-value">{m["value"]}</div>{sh}</div>', unsafe_allow_html=True)

def render_level_badge(level):
    labels = {1:'Level 1: 基本データ', 2:'Level 2: 詳細データ', 3:'Level 3: 全データ'}
    st.markdown(f'<span class="level-badge level-{level}"><span class="status-dot"></span> {labels.get(level,"")}</span>', unsafe_allow_html=True)

def render_insight_cards(insights, show_evidence=False, max_display=10):
    for ins in insights[:max_display]:
        sev = ins.get('severity','info'); icon = ins.get('icon','💡')
        title = ins.get('title',''); desc = ins.get('description','')
        eh = ''
        if show_evidence:
            reasoning = ins.get('reasoning',''); evidence = ins.get('evidence',{})
            if reasoning or evidence:
                ep = []
                if reasoning: ep.append(f'<span class="ev-label">🧠 根拠:</span> {reasoning}')
                if evidence and isinstance(evidence, dict):
                    method = evidence.get('method','')
                    if method: ep.append(f'<span class="ev-label">📐 手法:</span> {method}')
                    di = {k:v for k,v in evidence.items() if k not in ('method',) and not isinstance(v,(dict,list))}
                    if di: ep.append(_format_evidence_table(di))
                elif evidence and isinstance(evidence, str):
                    ep.append(f'<span class="ev-label">📊 根拠:</span> {evidence}')
                eh = f'<div class="evidence-box">{"<br>".join(ep)}</div>'
        st.markdown(f'<div class="insight-card {sev}"><div class="insight-title">{icon} {title}</div><div class="insight-desc">{desc}</div>{eh}</div>', unsafe_allow_html=True)

LABEL_MAP = {'data_points':'データ数','start_value':'開始値','end_value':'終了値','slope_per_month':'月次傾き',
    'r_squared':'決定係数(R²)','threshold':'閾値','z_score':'Zスコア','value':'値','mean':'平均','std':'標準偏差',
    'interpretation':'解釈','n_securities':'銘柄数','total_market_value':'時価合計','before':'前半','after':'後半',
    'change':'変化','income_ratio':'インカム比率','total_income':'インカム計','total_capital':'キャピタル計',
    'total_return':'トータル収益','avg_book_value':'平均簿価','n_months':'月数','annual_return_pct':'年率リターン(%)',
    'calculation':'計算方法','security':'銘柄','unrealized_gl':'評価損益','market_value':'時価'}

def _format_evidence_table(di):
    rows = []
    for k, v in di.items():
        label = LABEL_MAP.get(k, k)
        if isinstance(v, float):
            vs = f'{v/1e8:,.2f}億円' if abs(v) >= 1e6 else f'{v:,.1f}' if abs(v) >= 100 else f'{v:.4f}' if abs(v) < 0.01 else f'{v:.2f}'
        elif isinstance(v, int): vs = f'{v:,}'
        else: vs = str(v)
        rows.append(f'<tr><td style="padding:2px 8px;color:#64748b;font-weight:500;">{label}</td><td style="padding:2px 8px;color:#334155;">{vs}</td></tr>')
    return f'<table style="border-collapse:collapse;margin-top:4px;font-size:0.78rem;">{"".join(rows)}</table>'

def create_time_series_chart(df, x_col, y_cols, title='', height=380):
    fig = go.Figure()
    for i, (col, label) in enumerate(y_cols.items()):
        if col in df.columns:
            fig.add_trace(go.Scatter(x=df[x_col], y=df[col], mode='lines+markers', name=label,
                line=dict(color=COLORS[i % len(COLORS)], width=2.5), marker=dict(size=5),
                hovertemplate=f'{label}: %{{y:,.1f}}<extra></extra>'))
    fig.update_layout(**PLOTLY_LAYOUT, height=height, title=dict(text=title, font=dict(size=14, color='#0f172a')))
    apply_jp_xaxis(fig, df[x_col])
    return fig

def create_stacked_bar_chart(df, x_col, categories, value_col, category_col, title='', height=380):
    fig = go.Figure()
    ordered = order_asset_classes(categories)
    for cat in ordered:
        cd = df[df[category_col] == cat].copy()
        fig.add_trace(go.Bar(x=cd[x_col], y=cd[value_col], name=cat, marker_color=get_asset_color(cat),
            hovertemplate=f'{cat}: %{{y:,.1f}}<extra></extra>'))
    fig.update_layout(**PLOTLY_LAYOUT, height=height, title=dict(text=title, font=dict(size=14, color='#0f172a')), barmode='stack')
    apply_jp_xaxis(fig, sorted(df[x_col].unique()))
    return fig

def create_stacked_area_chart(df, x_col, categories, value_col, category_col, title='', height=380):
    return create_stacked_bar_chart(df, x_col, categories, value_col, category_col, title, height)

def create_pie_chart(labels, values, title='', height=350):
    op = sorted(zip(labels, values), key=lambda x: ASSET_CLASS_ORDER.index(x[0]) if x[0] in ASSET_CLASS_ORDER else 999)
    lo = [p[0] for p in op]; vo = [p[1] for p in op]
    colors = [get_asset_color(l) for l in lo]
    fig = go.Figure(go.Pie(labels=lo, values=vo, hole=0.55, marker=dict(colors=colors, line=dict(color='#ffffff', width=2)),
        textinfo='label+percent', textposition='outside',
        textfont=dict(size=10, color='#334155'),
        insidetextorientation='horizontal',
        hovertemplate='%{label}: %{value:,.1f}<br>構成: %{percent}<extra></extra>', sort=False))
    fig.update_layout(**PLOTLY_LAYOUT, height=height, title=dict(text=title, font=dict(size=14, color='#0f172a')),
        showlegend=False, uniformtext_minsize=8, uniformtext_mode='hide')
    return fig

def create_bar_chart(df, x_col, y_col, color_col=None, title='', height=350, orientation='v'):
    if color_col and color_col in df.columns: colors = [get_asset_color(v) for v in df[color_col]]
    else: colors = COLORS[0]
    if orientation == 'h':
        fig = go.Figure(go.Bar(y=df[x_col], x=df[y_col], marker_color=colors, orientation='h',
            text=df[y_col].apply(lambda x: f'{x:,.0f}'), textposition='auto',
            textfont=dict(color='#334155', size=10),
            insidetextfont=dict(color='#ffffff', size=10)))
    else:
        fig = go.Figure(go.Bar(x=df[x_col], y=df[y_col], marker_color=colors,
            text=df[y_col].apply(lambda x: f'{x:,.0f}'), textposition='outside',
            textfont=dict(color='#334155', size=10), cliponaxis=False))
    fig.update_layout(**PLOTLY_LAYOUT, height=height, title=dict(text=title, font=dict(size=14, color='#0f172a')))
    return fig

def create_waterfall_chart(categories, values, title='', height=380):
    measures = ['relative'] * (len(categories) - 1) + ['total']
    fig = go.Figure(go.Waterfall(name='', orientation='v', measure=measures, x=categories, y=values,
        connector=dict(line=dict(color='#cbd5e1', width=1)),
        decreasing=dict(marker=dict(color='#ef4444')), increasing=dict(marker=dict(color='#10b981')),
        totals=dict(marker=dict(color='#3b82f6')),
        text=[f'{v:+,.1f}' if i < len(values)-1 else f'{v:,.1f}' for i, v in enumerate(values)],
        textposition='outside', textfont=dict(color='#334155', size=10)))
    fig.update_layout(**PLOTLY_LAYOUT, height=height, title=dict(text=title, font=dict(size=14, color='#0f172a')), showlegend=False)
    return fig

def hex_to_rgba(hc, alpha=1.0):
    hc = hc.lstrip('#')
    if len(hc)==8: hc=hc[:6]
    return f'rgba({int(hc[0:2],16)},{int(hc[2:4],16)},{int(hc[4:6],16)},{alpha})'

def fmt_oku(val, precision=1, sign=False):
    """Format as 億円 (monthly/portfolio level data)."""
    if pd.isna(val): return '-'
    if sign:
        return f'{val:+,.{precision}f}億円'
    return f'{val:,.{precision}f}億円'

def fmt_hyakuman(val, precision=1):
    """Format as 億円 (always). Values are in 百万円 units internally."""
    if pd.isna(val): return '-'
    oku = val / 1e4
    if abs(oku) >= 0.01:
        return f'{oku:,.{precision}f}億円'
    else:
        return f'{val:,.{precision}f}百万円'

def fmt_pct(val, precision=2):
    if pd.isna(val): return '-'
    return f'{val*100 if abs(val) < 1 else val:+.{precision}f}%'